# Bazaar Tracker

## Self-hosting at sky-tracker.net

The production stack uses Docker Compose. Nginx serves the frontend on the
PC's loopback interface at `http://localhost:8088` and proxies `/api` to the
private Spring Boot container. Runtime database files remain in
`backend/data/`.

Start or update the application:

```powershell
docker compose up -d --build
```

Confirm it locally at `http://localhost:8088` before publishing it.

For public access without opening router ports, create a remotely managed
Cloudflare Tunnel and publish these routes:

| Public hostname | Service URL |
| --- | --- |
| `sky-tracker.net` | `http://localhost:8088` |
| `www.sky-tracker.net` | `http://localhost:8088` |

Install the tunnel as a Windows service using the command Cloudflare provides.
Cloudflare creates the required tunnel DNS route and supplies the public HTTPS
certificate. Keep the tunnel token secret.

The site is reachable only while this PC, Docker Desktop, the application
containers, and the `cloudflared` service are running. Configure Docker Desktop
to start at sign-in if the site should return automatically after a reboot.

Live Bazaar prices come from the official Hypixel API. Previously imported
long-range Coflnet history remains available to the prediction model, but the
automatic Coflnet backfill is disabled to avoid API rate limits.

## Public release notes

The backend is configured for local-only binding by default
(`server.address=127.0.0.1`) and only allows CORS requests from local
development origins. If you deploy it publicly, override
`server.address` and set `app.cors.allowed-origins` to the exact frontend
domain you control.

Runtime data is intentionally ignored by Git, including `backend/data/`,
`logs/`, SQLite databases, and Maven `target/` output. If any of those files
were committed before this ignore file existed, remove them from Git tracking
before publishing the repository.

Predictions combine:

- five-minute local price, spread, volume, volatility, and trend data;
- four-year momentum and recurring seasonal behavior;
- the active mayor, minister, and leading next-mayor candidate from Hypixel.

Fusion recipe combinations in `fusion-recipes.json` are derived from the
public [SkyShards](https://github.com/Campionnn/SkyShards) fusion dataset.
The compact dataset is expanded and cached once when the backend starts.

Long-term investments also receive accumulation tokens. Tokens are awarded for
a price discount, consecutive declining daily closes, a historical seven-day
rebound, and known mayor catalysts. Examples include gemstones during Cole,
gold before a likely Diana term, and Stock of Stonks during Diaz. A falling
price alone is not enough; the item must also have a recovery signal or event
catalyst, usable liquidity, and an acceptable spread.

The token model applies negative tokens too. Items with less than roughly four
months of history that are still collapsing from an early launch peak are
treated as being in price discovery, so their launch price is not assumed to
be a fair rebound target. Markets that remain nearly flat for two weeks also
lose trend credit. Persistent growth receives credit only while both the
seven-day and thirty-day trends remain positive.

Investment rows use a stock-style thesis: valuation, momentum, catalyst,
liquidity, and risk. They display a Value, Momentum, Catalyst, or Speculative
style plus an Accumulate rating and expected-upside/downside risk ratio.
Overextended items trading well above their baseline lose tokens unless a
strong catalyst remains, and investments must pass a minimum risk/reward test.

Qualified predictions are journaled automatically. One-hour signals are saved
at most once per item per hour, while seven-day investments are saved once per
item per day. After the horizon passes, the tracker compares the forecast with
the closest retained market price and records direction accuracy and whether
the exact target was reached.

The prediction journal is rolling rather than permanent. It keeps at most the
100 newest evaluated predictions and no more than 30 days of results. Older
results are deleted as new evaluations arrive. Pending predictions are kept
until evaluation, with unevaluable entries removed two days after their due
time.

Coflnet data remains attributed to Coflnet and is stored in the separate
`bazaar_daily_history` table. New long-range history will be built from the
tracker's own observations.

Local chart history uses tiered retention to keep the database compact:

- 1 day: five-minute observations;
- 1 week: hourly averages;
- 1 month: daily averages;
- 1 year: weekly averages.

The compactor runs hourly. It creates the coarser average before deleting the
older detailed samples, and data older than one year is discarded.

The Item Flipper scans Hypixel's live sell offers for prices at least 3% below
their 24-hour fair value. It requires at least 5,000 coins of estimated profit
after Bazaar tax, conservative trade flow of at least 25 items per hour, and
limits the suggested purchase to roughly 30 minutes of normal demand.
