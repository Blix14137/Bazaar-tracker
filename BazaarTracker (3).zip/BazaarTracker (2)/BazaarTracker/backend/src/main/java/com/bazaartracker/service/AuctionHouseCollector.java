package com.bazaartracker.service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.json.JSONArray;
import org.json.JSONObject;

import com.bazaartracker.service.DatabaseService.AuctionListing;
import com.bazaartracker.service.DatabaseService.SoldAuction;

public class AuctionHouseCollector {

    private static final long ENDED_POLL_SECONDS =
            10;

    private static final long MAX_ENDED_BACKOFF_SECONDS =
            60;

    private static final long ERROR_LOG_INTERVAL_MS =
            TimeUnit.MINUTES.toMillis(5);

    private static final String AUCTIONS_URL =
            "https://api.hypixel.net/v2/skyblock/auctions?page=";

    private static final String ENDED_AUCTIONS_URL =
            "https://api.hypixel.net/v2/skyblock/auctions_ended";

    private final DatabaseService database =
            new DatabaseService();

    private final HttpClient client =
            HttpClient.newBuilder()
                    .connectTimeout(Duration.ofSeconds(5))
                    .version(HttpClient.Version.HTTP_1_1)
                    .build();

    private volatile int endedAuctionFailures;

    private volatile long lastEndedAuctionErrorLog;

    public void start() {

        ScheduledExecutorService auctionScheduler =
                Executors.newSingleThreadScheduledExecutor(
                        runnable -> {
                            Thread thread =
                                    new Thread(
                                            runnable,
                                            "active-auction-collector"
                                    );
                            thread.setDaemon(true);
                            thread.setPriority(Thread.MIN_PRIORITY);
                            return thread;
                        }
                );

        auctionScheduler.scheduleWithFixedDelay(
                this::collect,
                0,
                5,
                TimeUnit.MINUTES
        );

        ScheduledExecutorService endedAuctionScheduler =
                Executors.newSingleThreadScheduledExecutor(
                        runnable -> {
                            Thread thread =
                                    new Thread(
                                            runnable,
                                            "ended-auction-collector"
                                    );
                            thread.setDaemon(true);
                            thread.setPriority(Thread.MIN_PRIORITY);
                            return thread;
                        }
                );

        scheduleEndedAuctionCollection(
                endedAuctionScheduler,
                0
        );
    }

    private void scheduleEndedAuctionCollection(
            ScheduledExecutorService scheduler,
            long delaySeconds
    ) {

        scheduler.schedule(
                () -> {
                    boolean succeeded =
                            collectEndedAuctions();

                    long nextDelay =
                            succeeded
                                    ? ENDED_POLL_SECONDS
                                    : endedAuctionBackoffSeconds();

                    scheduleEndedAuctionCollection(
                            scheduler,
                            nextDelay
                    );
                },
                delaySeconds,
                TimeUnit.SECONDS
        );
    }

    private boolean collectEndedAuctions() {

        try {

            HttpRequest request =
                    HttpRequest.newBuilder(
                                    URI.create(ENDED_AUCTIONS_URL)
                            )
                            .header(
                                    "User-Agent",
                                    "BazaarTracker/1.0"
                            )
                            .timeout(Duration.ofSeconds(8))
                            .build();

            HttpResponse<String> response =
                    client.send(
                            request,
                            HttpResponse.BodyHandlers.ofString()
                    );

            if (response.statusCode() != 200) {

                throw new IllegalStateException(
                        "Hypixel returned " +
                        response.statusCode() +
                        " for ended auctions"
                );
            }

            JSONArray auctions =
                    new JSONObject(response.body())
                            .getJSONArray("auctions");

            List<SoldAuction> soldAuctions =
                    new ArrayList<>();

            for (int i = 0; i < auctions.length(); i++) {

                JSONObject auction =
                        auctions.getJSONObject(i);

                if (
                        auction.optBoolean("bin") &&
                        !auction.optString("buyer").isBlank()
                ) {

                    soldAuctions.add(
                            new SoldAuction(
                                    auction.getString("auction_id"),
                                    auction.getLong("timestamp"),
                                    auction.optDouble("price")
                            )
                    );
                }
            }

            database.recordSoldAuctions(soldAuctions);

            endedAuctionFailures = 0;

            return true;

        } catch (Exception e) {

            endedAuctionFailures++;
            logEndedAuctionFailure(e);
            return false;
        }
    }

    private long endedAuctionBackoffSeconds() {

        int exponent =
                Math.min(endedAuctionFailures - 1, 4);

        return Math.min(
                MAX_ENDED_BACKOFF_SECONDS,
                ENDED_POLL_SECONDS * (1L << exponent)
        );
    }

    private void logEndedAuctionFailure(Exception error) {

        long now =
                System.currentTimeMillis();

        if (
                endedAuctionFailures == 1 ||
                now - lastEndedAuctionErrorLog >=
                        ERROR_LOG_INTERVAL_MS
        ) {

            System.err.println(
                    "Ended auction status temporarily unavailable; " +
                    "retrying with backoff (" +
                    error.getMessage() +
                    ")."
            );

            lastEndedAuctionErrorLog = now;
        }
    }

    private void collect() {

        try {

            JSONObject firstPage =
                    fetchPage(0);

            int totalPages =
                    firstPage.getInt("totalPages");

            List<AuctionListing> listings =
                    new ArrayList<>();

            addListings(
                    firstPage.getJSONArray("auctions"),
                    listings
            );

            for (int page = 1; page < totalPages; page++) {

                addListings(
                        fetchPage(page)
                                .getJSONArray("auctions"),
                        listings
                );

                Thread.sleep(25);
            }

            database.replaceActiveAuctions(listings);

            System.out.println(
                    "Saved " +
                    listings.size() +
                    " active Auction House BIN listings."
            );

        } catch (Exception e) {

            System.err.println(
                    "Auction House collection failed: " +
                    e.getMessage()
            );
        }
    }

    private JSONObject fetchPage(int page) throws Exception {

        HttpRequest request =
                HttpRequest.newBuilder(
                                URI.create(AUCTIONS_URL + page)
                        )
                        .header(
                                "User-Agent",
                                "BazaarTracker/1.0"
                        )
                        .timeout(Duration.ofSeconds(20))
                        .build();

        HttpResponse<String> response =
                client.send(
                        request,
                        HttpResponse.BodyHandlers.ofString()
                );

        if (response.statusCode() != 200) {

            throw new IllegalStateException(
                    "Hypixel returned " +
                    response.statusCode() +
                    " for page " +
                    page
            );
        }

        return new JSONObject(response.body());
    }

    private void addListings(
            JSONArray auctions,
            List<AuctionListing> listings
    ) {

        for (int i = 0; i < auctions.length(); i++) {

            JSONObject auction =
                    auctions.getJSONObject(i);

            if (
                    !auction.optBoolean("bin") ||
                    auction.optBoolean("claimed") ||
                    auction.optDouble("starting_bid") <= 0
            ) {

                continue;
            }

            String itemName =
                    cleanFormatting(
                            auction.optString(
                                    "item_name",
                                    "Unknown Item"
                            )
                    );

            if (isExcludedCosmetic(itemName)) {

                continue;
            }

            String tier =
                    auction.optString("tier");

            String category =
                    auction.optString("category");

            String itemLore =
                    cleanFormatting(
                            auction.optString("item_lore")
                    )
                            .replaceAll("\\s+", " ")
                            .trim();

            String variantFingerprint =
                    (
                        itemName +
                        "|" +
                        tier +
                        "|" +
                        category +
                        "|" +
                        itemLore
                    ).toLowerCase(Locale.ROOT);

            String itemKey =
                    "ah_" +
                    UUID.nameUUIDFromBytes(
                            variantFingerprint.getBytes(
                                    StandardCharsets.UTF_8
                            )
                    );

            listings.add(
                    new AuctionListing(
                            auction.getString("uuid"),
                            itemKey,
                            itemName,
                            tier,
                            category,
                            auction.getDouble("starting_bid"),
                            auction.optLong("start"),
                            auction.optLong("end")
                    )
            );
        }
    }

    private String cleanFormatting(String value) {

        return value.replaceAll(
                "§[0-9a-fk-or]",
                ""
        ).replaceAll(
                "\\u00a7[0-9a-fk-or]",
                ""
        );
    }

    private boolean isExcludedCosmetic(String itemName) {

        String normalized =
                itemName.toLowerCase(Locale.ROOT);

        return normalized.matches(
                ".*\\b(skin|skins|dye|dyes)\\b.*"
        );
    }
}
