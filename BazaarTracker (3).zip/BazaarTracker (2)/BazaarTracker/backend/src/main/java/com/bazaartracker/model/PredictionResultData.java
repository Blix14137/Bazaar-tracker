package com.bazaartracker.model;

public record PredictionResultData(
        long id,
        String itemId,
        String recommendation,
        double startPrice,
        double predictedPrice,
        double expectedChangePercent,
        double actualPrice,
        double actualChangePercent,
        boolean successful,
        boolean targetHit,
        String createdAt,
        String dueAt,
        String evaluatedAt,
        int horizonMinutes,
        String investmentStyle,
        int investmentTokens
) {
}
