package com.bazaartracker.service;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.bazaartracker.model.MarketContextData;

public class MarketContextService {

    private static final String API_URL =
            "https://sky.coflnet.com/api/mayor?from=%s&to=%s";

    private static final DateTimeFormatter COFL_DATE =
            DateTimeFormatter.ofPattern(
                    "MM/dd/yyyy HH:mm:ss"
            );

    private final HttpClient client =
            HttpClient.newBuilder()
                    .connectTimeout(Duration.ofSeconds(10))
                    .build();

    public List<MarketContextData> getTimeline(
            Instant from,
            Instant to
    ) {

        try {

            String url =
                    API_URL.formatted(
                            encode(from.toString()),
                            encode(to.toString())
                    );

            HttpRequest request =
                    HttpRequest.newBuilder(URI.create(url))
                            .header(
                                    "User-Agent",
                                    "BazaarTracker/1.0"
                            )
                            .timeout(Duration.ofSeconds(20))
                            .build();

            HttpResponse<String> response =
                    client.send(
                            request,
                            HttpResponse.BodyHandlers.ofString()
                    );

            if (response.statusCode() != 200) {

                return List.of();
            }

            JSONArray periods =
                    new JSONArray(response.body());

            List<MarketContextData> timeline =
                    new ArrayList<>();

            for (int i = 0; i < periods.length(); i++) {

                JSONObject period =
                        periods.getJSONObject(i);

                JSONObject winner =
                        period.optJSONObject("winner");

                if (winner == null) {

                    continue;
                }

                List<String> perks =
                        perkNames(
                                winner.optJSONArray("perks")
                        );

                JSONObject minister =
                        winner.optJSONObject("minister");

                String ministerName =
                        minister == null
                                ? null
                                : minister.optString(
                                        "name",
                                        null
                                );

                if (minister != null) {

                    JSONObject ministerPerk =
                            minister.optJSONObject("perk");

                    if (ministerPerk != null) {

                        perks.add(
                                "Minister: " +
                                ministerPerk.optString("name")
                        );
                    }
                }

                timeline.add(
                        new MarketContextData(
                                parseDate(
                                        period.getString("start")
                                ).toString(),
                                parseDate(
                                        period.getString("end")
                                ).toString(),
                                winner.getString("name"),
                                ministerName,
                                List.copyOf(perks),
                                eventName(perks)
                        )
                );
            }

            return timeline;

        } catch (Exception e) {

            System.err.println(
                    "Could not load historical mayor context: " +
                    e.getMessage()
            );

            return List.of();
        }
    }

    private List<String> perkNames(JSONArray perksJson) {

        List<String> perks =
                new ArrayList<>();

        if (perksJson == null) {

            return perks;
        }

        for (int i = 0; i < perksJson.length(); i++) {

            perks.add(
                    perksJson.getJSONObject(i)
                            .optString("name")
            );
        }

        return perks;
    }

    private String eventName(List<String> perks) {

        return perks.stream()
                .filter(perk -> {

                    String name =
                            perk.toLowerCase();

                    return name.contains("fiesta") ||
                           name.contains("festival") ||
                           name.contains("ritual") ||
                           name.contains("carnival") ||
                           name.contains("perkpocalypse") ||
                           name.contains("stock exchange");
                })
                .findFirst()
                .orElse(null);
    }

    private Instant parseDate(String value) {

        String trimmed =
                value.trim();

        try {

            return OffsetDateTime.parse(
                            trimmed,
                            DateTimeFormatter.ofPattern(
                                    "MM/dd/yyyy HH:mm:ss XXX"
                            )
                    )
                    .toInstant();

        } catch (Exception ignored) {

            return LocalDateTime.parse(
                            trimmed,
                            COFL_DATE
                    )
                    .toInstant(ZoneOffset.UTC);
        }
    }

    private String encode(String value) {

        return URLEncoder.encode(
                value,
                StandardCharsets.UTF_8
        );
    }
}
