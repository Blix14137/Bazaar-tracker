package com.bazaartracker.controller;

import java.util.List;
import java.time.Instant;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bazaartracker.model.PriceData;
import com.bazaartracker.model.MarketContextData;
import com.bazaartracker.service.DatabaseService;
import com.bazaartracker.service.MarketContextService;

@RestController
@RequestMapping("/api")
public class HistoryController {

    private final DatabaseService database =
            new DatabaseService();

    private final MarketContextService marketContext =
            new MarketContextService();

    @GetMapping("/history/{itemId}")
    public List<PriceData> getHistory(
            @PathVariable String itemId,
            @RequestParam(defaultValue = "1d") String range
    ) {

        return database.getHistory(itemId, range);
    }

    @GetMapping("/market-context")
    public List<MarketContextData> getMarketContext(
            @RequestParam String from,
            @RequestParam String to
    ) {

        return marketContext.getTimeline(
                Instant.parse(from),
                Instant.parse(to)
        );
    }
}
