package com.bazaartracker.model;

import java.util.List;

public record FusionFlipData(
        String outputItemId,
        List<FusionStepData> steps,
        double inputCost,
        double outputValue,
        int outputCount,
        double profit,
        double profitPercent,
        double dailyVolume,
        int levels
) {

    public record FusionStepData(
            String firstItemId,
            int firstCount,
            String secondItemId,
            int secondCount,
            String outputItemId,
            int outputCount,
            double inputCost,
            double outputValue,
            double profit
    ) {
    }
}
