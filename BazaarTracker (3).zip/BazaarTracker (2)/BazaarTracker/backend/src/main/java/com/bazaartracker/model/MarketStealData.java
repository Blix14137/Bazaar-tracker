package com.bazaartracker.model;

public record MarketStealData(
        String itemId,
        String auctionUuid,
        String itemName,
        double offerPrice,
        double fairValue,
        double discountPercent,
        double estimatedTax,
        double netProfitPerItem,
        double availableAmount,
        double suggestedAmount,
        double totalProfit,
        double tradesPerHour,
        double estimatedSellHours,
        double confidence,
        long expiresAt,
        boolean sold,
        long soldAt
) {
}
