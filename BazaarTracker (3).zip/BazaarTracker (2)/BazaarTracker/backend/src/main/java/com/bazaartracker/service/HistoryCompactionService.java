package com.bazaartracker.service;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class HistoryCompactionService {

    private final DatabaseService database =
            new DatabaseService();

    public void start() {

        ScheduledExecutorService scheduler =
                Executors.newSingleThreadScheduledExecutor(
                        runnable -> {

                            Thread thread =
                                    new Thread(
                                            runnable,
                                            "bazaar-history-compactor"
                                    );

                            thread.setDaemon(true);
                            thread.setPriority(Thread.MIN_PRIORITY);

                            return thread;
                        }
                );

        scheduler.scheduleWithFixedDelay(
                this::compact,
                30,
                60 * 60,
                TimeUnit.SECONDS
        );
    }

    private void compact() {

        database.compactHistory();

        System.out.println(
                "Compacted Bazaar history into hourly, daily, and weekly tiers."
        );
    }
}
