package com.bazaartracker.model;

import java.util.List;

public record MayorData(
        String name,
        List<PerkData> perks,
        MinisterData minister,
        CandidateData leadingCandidate,
        List<CandidateData> electionCandidates,
        int currentYear,
        List<SpecialMayorData> specialMayors,
        long lastUpdated
) {

    public record PerkData(
            String name,
            String description
    ) {
    }

    public record MinisterData(
            String name,
            PerkData perk
    ) {
    }

    public record CandidateData(
            String name,
            List<PerkData> perks,
            int votes,
            double voteShare,
            PerkData ministerPerk
    ) {
    }

    public record SpecialMayorData(
            String name,
            int nextYear,
            int estimatedDays
    ) {
    }
}
