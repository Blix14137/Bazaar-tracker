package com.bazaartracker.service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.bazaartracker.model.MayorData;
import com.bazaartracker.model.MayorData.CandidateData;
import com.bazaartracker.model.MayorData.MinisterData;
import com.bazaartracker.model.MayorData.PerkData;
import com.bazaartracker.model.MayorData.SpecialMayorData;

public class MayorService {

    private static final long SKYBLOCK_EPOCH_MS =
            1_560_275_700_000L;

    private static final long SKYBLOCK_YEAR_MS =
            372L * 20L * 60L * 1000L;

    private static final URI ELECTION_URI =
            URI.create(
                    "https://api.hypixel.net/v2/resources/skyblock/election"
            );

    private static final Duration CACHE_DURATION =
            Duration.ofMinutes(10);

    private final HttpClient client =
            HttpClient.newHttpClient();

    private MayorData cachedMayor;
    private Instant cacheTime =
            Instant.EPOCH;

    public synchronized MayorData getCurrentMayor() {

        if (
                cachedMayor != null &&
                Instant.now().isBefore(
                        cacheTime.plus(CACHE_DURATION)
                )
        ) {

            return cachedMayor;
        }

        try {

            HttpRequest request =
                    HttpRequest.newBuilder(ELECTION_URI)
                            .header(
                                    "User-Agent",
                                    "BazaarTracker/1.0"
                            )
                            .timeout(Duration.ofSeconds(10))
                            .build();

            HttpResponse<String> response =
                    client.send(
                            request,
                            HttpResponse.BodyHandlers.ofString()
                    );

            if (response.statusCode() != 200) {

                throw new IllegalStateException(
                        "Hypixel returned " +
                        response.statusCode()
                );
            }

            JSONObject root =
                    new JSONObject(response.body());

            if (!root.optBoolean("success", true)) {

                throw new IllegalStateException(
                        "Hypixel did not return a successful election payload"
                );
            }

            JSONObject mayor =
                    root.getJSONObject("mayor");

            JSONArray perksJson =
                    mayor.getJSONArray("perks");

            List<PerkData> perks =
                    new ArrayList<>();

            for (int i = 0; i < perksJson.length(); i++) {

                JSONObject perk =
                        perksJson.getJSONObject(i);

                perks.add(
                        new PerkData(
                                perk.getString("name"),
                                perk.getString("description")
                        )
                );
            }

            int currentYear =
                    currentYear(root, mayor);

            MinisterData minister =
                    getMinister(mayor);

            List<CandidateData> electionCandidates =
                    getElectionCandidates(root);

            cachedMayor =
                    new MayorData(
                            mayor.getString("name"),
                            List.copyOf(perks),
                            minister,
                            electionCandidates.isEmpty()
                                    ? null
                                    : electionCandidates.get(0),
                            electionCandidates,
                            currentYear,
                            getSpecialMayorSchedule(currentYear),
                            root.getLong("lastUpdated")
                    );

            cacheTime =
                    Instant.now();

            return cachedMayor;

        } catch (Exception e) {

            if (cachedMayor != null) {

                return cachedMayor;
            }

            System.err.println(
                    "Failed to load the current mayor: " +
                    e.getMessage()
            );

            return unavailableMayor();
        }
    }

    private MayorData unavailableMayor() {

        int currentYear =
                estimatedCurrentYear();

        return new MayorData(
                "Election unavailable",
                List.of(
                        new PerkData(
                                "Hypixel unavailable",
                                "The backend could not reach the Hypixel election API. Try again once the API or network connection is available."
                        )
                ),
                null,
                null,
                List.of(),
                currentYear,
                getSpecialMayorSchedule(currentYear),
                System.currentTimeMillis()
        );
    }

    private int currentYear(
            JSONObject root,
            JSONObject mayor
    ) {

        JSONObject current =
                root.optJSONObject("current");

        if (current != null && current.has("year")) {

            return current.optInt(
                    "year",
                    estimatedCurrentYear()
            );
        }

        JSONObject election =
                mayor.optJSONObject("election");

        if (election != null && election.has("year")) {

            return election.optInt(
                    "year",
                    estimatedCurrentYear()
            ) + 1;
        }

        return estimatedCurrentYear();
    }

    private int estimatedCurrentYear() {

        return Math.max(
                0,
                (int) (
                        (System.currentTimeMillis() -
                        SKYBLOCK_EPOCH_MS) /
                        SKYBLOCK_YEAR_MS
                )
        );
    }

    private List<CandidateData> getElectionCandidates(
            JSONObject root
    ) {

        JSONObject current =
                root.optJSONObject("current");

        if (current == null) {

            return List.of();
        }

        JSONArray candidates =
                current.optJSONArray("candidates");

        if (candidates == null || candidates.isEmpty()) {

            return List.of();
        }

        int totalVotes = 0;

        for (int i = 0; i < candidates.length(); i++) {

            totalVotes +=
                    candidates.getJSONObject(i)
                            .optInt("votes");
        }

        List<CandidateData> results =
                new ArrayList<>();

        for (int i = 0; i < candidates.length(); i++) {

            JSONObject candidate =
                    candidates.getJSONObject(i);

            List<PerkData> perks =
                    new ArrayList<>();

            PerkData ministerPerk = null;

            JSONArray perksJson =
                    candidate.optJSONArray("perks");

            if (perksJson != null) {

                for (int perkIndex = 0;
                     perkIndex < perksJson.length();
                     perkIndex++) {

                    JSONObject perk =
                            perksJson.getJSONObject(perkIndex);

                    PerkData perkData =
                            new PerkData(
                                    perk.getString("name"),
                                    perk.getString("description")
                            );

                    perks.add(perkData);

                    if (perk.optBoolean("minister")) {

                        ministerPerk = perkData;
                    }
                }
            }

            int votes =
                    candidate.optInt("votes");

            results.add(
                    new CandidateData(
                            candidate.getString("name"),
                            List.copyOf(perks),
                            votes,
                            totalVotes <= 0
                                    ? 0
                                    : votes / (double) totalVotes,
                            ministerPerk
                    )
            );
        }

        results.sort(
                (left, right) ->
                        Integer.compare(
                                right.votes(),
                                left.votes()
                        )
        );

        return List.copyOf(results);
    }

    private MinisterData getMinister(JSONObject mayor) {

        if (isSpecialMayor(mayor.getString("name"))) {

            return null;
        }

        JSONObject election =
                mayor.optJSONObject("election");

        if (election == null) {

            return null;
        }

        JSONArray candidates =
                election.optJSONArray("candidates");

        if (candidates == null || candidates.length() < 2) {

            return null;
        }

        List<JSONObject> rankedCandidates =
                new ArrayList<>();

        for (int i = 0; i < candidates.length(); i++) {

            rankedCandidates.add(
                    candidates.getJSONObject(i)
            );
        }

        rankedCandidates.sort(
                (left, right) ->
                        Integer.compare(
                                right.optInt("votes"),
                                left.optInt("votes")
                        )
        );

        JSONObject minister =
                rankedCandidates.get(1);

        JSONArray perks =
                minister.optJSONArray("perks");

        if (perks == null) {

            return null;
        }

        for (int i = 0; i < perks.length(); i++) {

            JSONObject perk =
                    perks.getJSONObject(i);

            if (perk.optBoolean("minister")) {

                return new MinisterData(
                        minister.getString("name"),
                        new PerkData(
                                perk.getString("name"),
                                perk.getString("description")
                        )
                );
            }
        }

        return null;
    }

    private List<SpecialMayorData> getSpecialMayorSchedule(
            int currentYear
    ) {

        return List.of(
                createSpecialMayor("Scorpius", 504, currentYear),
                createSpecialMayor("Derpy", 512, currentYear),
                createSpecialMayor("Jerry", 520, currentYear)
        );
    }

    private SpecialMayorData createSpecialMayor(
            String name,
            int anchorYear,
            int currentYear
    ) {

        int nextYear =
                anchorYear;

        while (nextYear < currentYear) {

            nextYear += 24;
        }

        int estimatedDays =
                Math.max(
                        0,
                        (int) Math.round(
                                (nextYear - currentYear) *
                                124.0 / 24.0
                        )
                );

        return new SpecialMayorData(
                name,
                nextYear,
                estimatedDays
        );
    }

    private boolean isSpecialMayor(String name) {

        return name.equals("Jerry") ||
               name.equals("Derpy") ||
               name.equals("Scorpius");
    }
}
