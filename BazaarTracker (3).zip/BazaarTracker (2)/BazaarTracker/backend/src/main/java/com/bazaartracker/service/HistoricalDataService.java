package com.bazaartracker.service;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.json.JSONArray;
import org.json.JSONObject;

import com.bazaartracker.service.DatabaseService.HistoricalObservation;

public class HistoricalDataService {

    private static final String HISTORY_URL =
            "https://sky.coflnet.com/api/bazaar/%s/history" +
            "?start=%s&end=%s";

    private static final String SOURCE =
            "Coflnet";

    private static final int YEARS =
            4;

    private static final int MAX_ITEMS =
            100;

    private final DatabaseService database =
            new DatabaseService();

    private final HttpClient client =
            HttpClient.newBuilder()
                    .connectTimeout(Duration.ofSeconds(15))
                    .build();

    public void start() {

        ScheduledExecutorService scheduler =
                Executors.newSingleThreadScheduledExecutor(
                        runnable -> {

                            Thread thread =
                                    new Thread(
                                            runnable,
                                            "historical-bazaar-backfill"
                                    );

                            thread.setDaemon(true);

                            return thread;
                        }
                );

        scheduler.scheduleWithFixedDelay(
                this::backfillMostLiquidItems,
                1,
                24 * 60,
                TimeUnit.MINUTES
        );
    }

    private void backfillMostLiquidItems() {

        LocalDate today =
                LocalDate.now(ZoneOffset.UTC);

        LocalDate start =
                today.minusYears(YEARS);

        List<String> items =
                database.getHistoricalBackfillCandidates(
                        MAX_ITEMS
                );

        int imported = 0;

        for (String itemId : items) {

            if (
                    database.hasHistoricalCoverage(
                            itemId,
                            start.atStartOfDay()
                    )
            ) {

                continue;
            }

            try {

                imported +=
                        backfillItem(
                                itemId,
                                start,
                                today
                        );

                Thread.sleep(150);

            } catch (InterruptedException e) {

                Thread.currentThread().interrupt();
                return;

            } catch (Exception e) {

                System.err.println(
                        "Historical backfill failed for " +
                        itemId +
                        ": " +
                        e.getMessage()
                );
            }
        }

        System.out.println(
                "Historical Bazaar backfill saved " +
                imported +
                " daily points from Coflnet."
        );
    }

    private int backfillItem(
            String itemId,
            LocalDate start,
            LocalDate end
    ) throws Exception {

        int imported = 0;
        LocalDate windowStart =
                start;

        while (windowStart.isBefore(end)) {

            LocalDate windowEnd =
                    windowStart.plusYears(1)
                            .minusDays(1);

            if (windowEnd.isAfter(end)) {

                windowEnd = end;
            }

            List<HistoricalObservation> observations =
                    fetchWindow(
                            itemId,
                            windowStart,
                            windowEnd
                    );

            database.saveHistoricalObservations(
                    observations
            );

            imported +=
                    observations.size();

            windowStart =
                    windowEnd.plusDays(1);
        }

        return imported;
    }

    private List<HistoricalObservation> fetchWindow(
            String itemId,
            LocalDate start,
            LocalDate end
    ) throws Exception {

        String encodedItem =
                URLEncoder.encode(
                        itemId,
                        StandardCharsets.UTF_8
                );

        String url =
                HISTORY_URL.formatted(
                        encodedItem,
                        start + "T00:00:00Z",
                        end + "T23:59:59Z"
                );

        HttpRequest request =
                HttpRequest.newBuilder(
                                URI.create(url)
                        )
                        .header(
                                "User-Agent",
                                "BazaarTracker/1.0"
                        )
                        .timeout(Duration.ofSeconds(30))
                        .build();

        HttpResponse<String> response =
                client.send(
                        request,
                        HttpResponse.BodyHandlers.ofString()
                );

        if (response.statusCode() != 200) {

            throw new IllegalStateException(
                    "Coflnet returned " +
                    response.statusCode()
            );
        }

        JSONArray points =
                new JSONArray(response.body());

        List<HistoricalObservation> observations =
                new ArrayList<>();

        for (int i = 0; i < points.length(); i++) {

            JSONObject point =
                    points.getJSONObject(i);

            double buy =
                    point.optDouble("buy");

            double sell =
                    point.optDouble("sell");

            String timestamp =
                    normalizeTimestamp(
                            point.getString("timestamp")
                    );

            if (
                    buy <= 0 ||
                    sell <= 0 ||
                    timestamp == null
            ) {

                continue;
            }

            observations.add(
                    new HistoricalObservation(
                            itemId,
                            buy,
                            sell,
                            point.optDouble("buyVolume"),
                            point.optDouble("sellVolume"),
                            point.optDouble("buyMovingWeek"),
                            point.optDouble("sellMovingWeek"),
                            timestamp,
                            SOURCE
                    )
            );
        }

        return observations;
    }

    private String normalizeTimestamp(String value) {

        try {

            return LocalDateTime.parse(
                            value,
                            DateTimeFormatter.ISO_LOCAL_DATE_TIME
                    )
                    .format(
                            DateTimeFormatter.ISO_LOCAL_DATE_TIME
                    );

        } catch (Exception ignored) {

            return null;
        }
    }
}
