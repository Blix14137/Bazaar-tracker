package com.bazaartracker.model;

public record PredictionData(
        String itemId,
        String recommendation,
        double currentPrice,
        double predictedPrice,
        double expectedChangePercent,
        double confidence,
        double volatilityPercent,
        double hourlyVolume,
        double spreadPercent,
        double score,
        int horizonMinutes,
        int samples,
        double longTermChangePercent,
        int historicalSamples,
        String mayor,
        double mayorImpactPercent,
        String mayorReason,
        double discountToBaselinePercent,
        String forecastReason,
        int investmentTokens,
        String tokenReason,
        double riskRewardRatio,
        String investmentStyle,
        String investmentRating
) {
}
