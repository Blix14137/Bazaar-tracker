package com.bazaartracker.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bazaartracker.model.CraftRecipeData;
import com.bazaartracker.model.FlipData;
import com.bazaartracker.model.FusionFlipData;
import com.bazaartracker.model.MarketStealData;
import com.bazaartracker.model.PredictionData;
import com.bazaartracker.model.PredictionResultData;
import com.bazaartracker.service.DatabaseService;

@RestController
@RequestMapping("/api")
public class SearchController {

    private final DatabaseService database =
            new DatabaseService();

    @GetMapping("/items")
    public List<String> getItems() {

        return database.getAllItems();
    }

    @GetMapping("/search")
    public List<String> searchItems(
            @RequestParam String query
    ) {

        return database.searchItems(query);
    }

    @GetMapping("/auction-search")
    public List<String> searchAuctionItems(
            @RequestParam String query
    ) {

        return database.searchAuctionItems(query);
    }

    @GetMapping("/flips")
    public List<FlipData> getCraftFlips() {

        return database.getCraftFlips();
    }

    @GetMapping("/craft-recipes")
    public List<FlipData> getCraftRecipeValues() {

        return database.getCraftRecipeValues();
    }

    @GetMapping("/forge-flips")
    public List<FlipData> getForgeFlips() {

        return database.getForgeFlips();
    }

    @GetMapping("/forge-recipes")
    public List<FlipData> getForgeRecipeValues() {

        return database.getForgeRecipeValues();
    }

    @GetMapping("/bazaar-flips")
    public List<FlipData> getBazaarFlips() {

        return database.getBazaarFlips();
    }

    @GetMapping("/fusion-flips")
    public List<FusionFlipData> getFusionFlips(
            @RequestParam(defaultValue = "false") boolean multiStep
    ) {

        return database.getFusionFlips(multiStep);
    }

    @GetMapping("/item-flips")
    public List<MarketStealData> getItemFlips() {

        return database.getMarketSteals();
    }

    @GetMapping("/predictions")
    public List<PredictionData> getPredictions() {

        return database.getPredictions();
    }

    @GetMapping("/mayor-flips")
    public List<PredictionData> getMayorFlips() {

        return database.getMayorFlips();
    }

    @GetMapping("/prediction-history")
    public List<PredictionResultData> getPredictionHistory(
            @RequestParam(defaultValue = "50") int limit
    ) {

        return database.getPredictionHistory(limit);
    }

    @GetMapping("/craft/{itemId}")
    public CraftRecipeData getCraftRecipe(
            @PathVariable String itemId
    ) {

        return database.getCraftRecipe(itemId);
    }

    @GetMapping("/search/{itemId}")
    public String searchItem(
            @PathVariable String itemId
    ) {

        return database.searchItem(itemId);
    }
}
