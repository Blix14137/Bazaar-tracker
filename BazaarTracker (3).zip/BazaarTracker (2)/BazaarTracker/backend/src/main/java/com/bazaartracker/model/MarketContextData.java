package com.bazaartracker.model;

import java.util.List;

public record MarketContextData(
        String start,
        String end,
        String mayor,
        String minister,
        List<String> perks,
        String event
) {
}
