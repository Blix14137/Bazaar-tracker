package com.bazaartracker.service;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Locale;

import com.bazaartracker.model.MayorData;

public final class MayorMarketAnalyzer {

    private static final long SKYBLOCK_EPOCH_MS =
            1_560_275_700_000L;

    private static final long SKYBLOCK_DAY_MS =
            20L * 60L * 1000L;

    private static final long SKYBLOCK_MONTH_MS =
            31L * SKYBLOCK_DAY_MS;

    private static final long SKYBLOCK_YEAR_MS =
            372L * SKYBLOCK_DAY_MS;

    private MayorMarketAnalyzer() {
    }

    public static MayorSignal analyze(
            String itemId,
            MayorData mayor
    ) {

        if (mayor == null) {

            return MayorSignal.NONE;
        }

        String category =
                categoryFor(itemId);

        EventCatalyst eventCatalyst =
                eventCatalyst(itemId, mayor);

        if (category == null) {

            return new MayorSignal(
                    mayor.name(),
                    eventCatalyst.impactPercent(),
                    combinedReason(
                            "No direct mayor-sensitive market category",
                            eventCatalyst.reason()
                    ),
                    eventCatalyst.tokens(),
                    eventCatalyst.reason()
            );
        }

        double impact = 0;
        String reason = "";

        impact +=
                eventCatalyst.impactPercent();

        if (affects(mayor.name(), category)) {

            impact -= 0.8;
            reason =
                    mayor.name() +
                    " is active; extra " +
                    category +
                    " supply can pressure prices";
        }

        MayorData.CandidateData candidate =
                mayor.leadingCandidate();

        if (
                candidate != null &&
                pollStrength(mayor) >= 0.25 &&
                affects(candidate.name(), category)
        ) {

            double anticipation =
                    1.4 *
                    pollStrength(mayor);

            impact += anticipation;
            reason =
                    candidate.name() +
                    " leads the election (" +
                    Math.round(candidate.voteShare() * 100) +
                    "%, " +
                    Math.round(pollLeadMargin(mayor) * 100) +
                    "-point lead); related " +
                    category +
                    " markets may move before the term";
        }

        MayorData.CandidateData minister =
                projectedMinister(mayor);

        if (
                minister != null &&
                minister.ministerPerk() != null &&
                affects(minister.name(), category)
        ) {

            double ministerImpact =
                    0.45 *
                    pollStrength(mayor);

            impact += ministerImpact;

            String ministerReason =
                    minister.name() +
                    " projects as minister with " +
                    minister.ministerPerk().name();

            reason =
                    reason.isBlank()
                            ? ministerReason
                            : reason + "; " + ministerReason;
        }

        return new MayorSignal(
                mayor.name(),
                impact,
                combinedReason(
                        reason,
                        eventCatalyst.reason()
                ),
                catalystTokens(itemId, mayor),
                catalystReason(itemId, mayor)
        );
    }

    public static boolean isMiningItem(String itemId) {

        return "mining".equals(
                categoryFor(itemId)
        );
    }

    private static int catalystTokens(
            String itemId,
            MayorData mayor
    ) {

        String id =
                itemId.toUpperCase(Locale.ROOT);

        EventCatalyst namedFlipCatalyst =
                namedFlipCatalyst(
                        id,
                        mayor,
                        currentSkyBlockDate(mayor)
                );

        if (namedFlipCatalyst.tokens() > 0) {

            return namedFlipCatalyst.tokens();
        }

        if (
                mayor.name().equalsIgnoreCase("Cole") &&
                isGemstoneItem(id)
        ) {

            return afterLastMiningFiesta(mayor)
                    ? 5
                    : 0;
        }

        if (
                mayor.name().equalsIgnoreCase("Diaz") &&
                isDiazItem(id)
        ) {

            return 4;
        }

        MayorData.CandidateData candidate =
                mayor.leadingCandidate();

        if (
                candidate != null &&
                pollStrength(mayor) >= 0.25
        ) {

            int specialTokens =
                    projectedSpecialMayorTokens(
                            candidate.name(),
                            id,
                            mayor
                    );

            if (specialTokens > 0) {

                return specialTokens;
            }
        }

        if (
                candidate != null &&
                pollStrength(mayor) >= 0.25 &&
                candidate.name().equalsIgnoreCase("Diana") &&
                isGoldItem(id)
        ) {

            return Math.max(
                    4,
                    pollTokens(mayor) + 2
            );
        }

        String category =
                categoryFor(itemId);

        if (category != null) {

            int activeTokens =
                    activeMayorTokens(
                            mayor.name(),
                            category,
                            id,
                            mayor
                    );

            if (activeTokens > 0) {

                return activeTokens;
            }
        }

        if (
                candidate != null &&
                category != null &&
                affects(candidate.name(), category)
        ) {

            return Math.max(
                    pollTokens(mayor),
                    projectedMayorTokens(
                            candidate.name(),
                            category,
                            id,
                            mayor
                    )
            );
        }

        MayorData.CandidateData minister =
                projectedMinister(mayor);

        if (
                minister != null &&
                minister.ministerPerk() != null &&
                category != null &&
                affects(minister.name(), category)
        ) {

            return 1;
        }

        return eventCatalyst(itemId, mayor).tokens();
    }

    private static String catalystReason(
            String itemId,
            MayorData mayor
    ) {

        String id =
                itemId.toUpperCase(Locale.ROOT);

        EventCatalyst namedFlipCatalyst =
                namedFlipCatalyst(
                        id,
                        mayor,
                        currentSkyBlockDate(mayor)
                );

        if (namedFlipCatalyst.tokens() > 0) {

            return namedFlipCatalyst.reason();
        }

        if (
                mayor.name().equalsIgnoreCase("Cole") &&
                isGemstoneItem(id)
        ) {

            return afterLastMiningFiesta(mayor)
                    ? "Cole's last Mining Fiesta has passed; gemstone supply is usually deepest, so strong ruby, jasper, jade, sapphire, amber, amethyst, and topaz discounts can be accumulation entries"
                    : "Cole is active but the final Mining Fiesta has not passed yet; gemstone prices can still get cheaper before the best accumulation window";
        }

        if (
                mayor.name().equalsIgnoreCase("Diaz") &&
                isDiazItem(id)
        ) {

            return "Diaz can create coin-flow and Stock of Stonks attention; invest only when the added supply leaves a clear discount";
        }

        MayorData.CandidateData candidate =
                mayor.leadingCandidate();

        if (
                candidate != null &&
                pollStrength(mayor) >= 0.25
        ) {

            String specialReason =
                    projectedSpecialMayorReason(
                            candidate.name(),
                            id,
                            mayor
                    );

            if (!specialReason.isBlank()) {

                return specialReason;
            }
        }

        if (
                candidate != null &&
                pollStrength(mayor) >= 0.25 &&
                candidate.name().equalsIgnoreCase("Diana") &&
                isGoldItem(id)
        ) {

            return "Diana leads the election before being elected; Enchanted Gold Blocks and other gold items can gain demand into the Mythological Ritual";
        }

        String category =
                categoryFor(itemId);

        if (category != null) {

            String activeReason =
                    activeMayorReason(
                            mayor.name(),
                            category,
                            id,
                            mayor
                    );

            if (!activeReason.isBlank()) {

                return activeReason;
            }
        }

        if (
                candidate != null &&
                category != null &&
                affects(candidate.name(), category)
        ) {

            String reason =
                    candidate.name() +
                    " is projected mayor at " +
                    Math.round(candidate.voteShare() * 100) +
                    "% with a " +
                    Math.round(pollLeadMargin(mayor) * 100) +
                    "-point lead; this is a poll-driven " +
                    category +
                    " catalyst";

            String mayorSpecific =
                    projectedMayorReason(
                            candidate.name(),
                            category,
                            id,
                            mayor
                    );

            return mayorSpecific.isBlank()
                    ? reason
                    : reason + "; " + mayorSpecific;
        }

        MayorData.CandidateData minister =
                projectedMinister(mayor);

        if (
                minister != null &&
                minister.ministerPerk() != null &&
                category != null &&
                affects(minister.name(), category)
        ) {

            return minister.name() +
                    " projects as minister with " +
                    minister.ministerPerk().name() +
                    ", creating a smaller " +
                    category +
                    " catalyst";
        }

        return eventCatalyst(itemId, mayor).reason();
    }

    private static String combinedReason(
            String mayorReason,
            String eventReason
    ) {

        if (mayorReason.isBlank()) {

            return eventReason.isBlank()
                    ? "Mayor and event effects are currently neutral"
                    : eventReason;
        }

        return eventReason.isBlank()
                ? mayorReason
                : mayorReason + "; " + eventReason;
    }

    private static EventCatalyst eventCatalyst(
            String itemId,
            MayorData mayor
    ) {

        String id =
                itemId.toUpperCase(Locale.ROOT);

        SkyBlockDate skyBlockDate =
                currentSkyBlockDate(mayor);

        EventCatalyst namedFlipCatalyst =
                namedFlipCatalyst(
                        id,
                        mayor,
                        skyBlockDate
                );

        if (namedFlipCatalyst.tokens() > 0) {

            return namedFlipCatalyst;
        }

        if (
                mayor.name().equalsIgnoreCase("Cole") &&
                isGemstoneItem(id)
        ) {

            return afterLastMiningFiesta(mayor)
                    ? new EventCatalyst(
                            5,
                            2.8,
                            "Cole's final Mining Fiesta has passed; gemstone markets often have their best supply-driven discount after the last fiesta"
                    )
                    : new EventCatalyst(
                            0,
                            -1.2,
                            "Cole's final Mining Fiesta is still ahead, so gemstone supply risk remains high"
                    );
        }

        EventCatalyst activeMayorCatalyst =
                activeMayorCatalyst(id, mayor);

        EventCatalyst calendar =
                strongest(
                        strongest(
                                strongest(
                                        calendarEventCatalyst(id, skyBlockDate),
                                        skyBlockYearCatalyst(id, skyBlockDate)
                                ),
                                realLifeEventCatalyst(id)
                        ),
                        activeMayorCatalyst
                );

        if (calendar.tokens() > 0) {

            return calendar;
        }

        return EventCatalyst.NONE;
    }

    private static EventCatalyst namedFlipCatalyst(
            String id,
            MayorData mayor,
            SkyBlockDate date
    ) {

        MayorData.CandidateData candidate =
                mayor.leadingCandidate();

        if (
                candidate != null &&
                pollStrength(mayor) >= 0.25 &&
                candidate.name().equalsIgnoreCase("Diana") &&
                id.equals("ENCHANTED_GOLD_BLOCK")
        ) {

            return new EventCatalyst(
                    Math.max(4, pollTokens(mayor) + 2),
                    2.4,
                    "Diana is projected to win; Enchanted Gold Blocks are a focused pre-Ritual accumulation play"
            );
        }

        if (
                mayor.name().equalsIgnoreCase("Diana") &&
                id.equals("ENCHANTED_GOLD_BLOCK")
        ) {

            return new EventCatalyst(
                    4,
                    2.2,
                    "Diana is active; Enchanted Gold Blocks can spike during Mythological Ritual demand, so mid-event exits are worth watching"
            );
        }

        if (
                mayor.name().equalsIgnoreCase("Foxy") &&
                isPartyGiftItem(id)
        ) {

            return new EventCatalyst(
                    4,
                    2.0,
                    "Foxy is active; Party Gifts are a focused event-supply flip when extra festival activity pulls attention"
            );
        }

        if (
                mayor.name().equalsIgnoreCase("Cole") &&
                categoryFor(id) != null &&
                categoryFor(id).equals("mining") &&
                afterLastMiningFiesta(mayor)
        ) {

            return new EventCatalyst(
                    3,
                    1.7,
                    "Cole's fiestas are over; mining items near their post-fiesta low can become rebound entries"
            );
        }

        if (
                mayor.name().equalsIgnoreCase("Marina") &&
                isWhiteSharkToothItem(id)
        ) {

            return new EventCatalyst(
                    4,
                    2.0,
                    "Marina is active; White Shark Teeth can get Fishing Festival demand, then sell pressure after the event"
            );
        }

        if (
                mayor.name().equalsIgnoreCase("Jerry") &&
                isJerryRotationFlipItem(id)
        ) {

            return new EventCatalyst(
                    3,
                    1.8,
                    "Jerry is active; Marina, Cole, and Diana-style rotation demand can move shark teeth, mining materials, mythological items, and gold"
            );
        }

        if (
                isSeasonOfJerryItem(id) &&
                isSeasonOfJerryWindow(date)
        ) {

            return new EventCatalyst(
                    isVolcanicRockItem(id) ? 4 : 3,
                    isVolcanicRockItem(id) ? 2.1 : 1.6,
                    isVolcanicRockItem(id)
                            ? "Season of Jerry is in its eruption window; Volcanic Rocks can be accumulated late and sold after the event"
                            : "Season of Jerry is on the calendar; Enchanted Ice and Enchanted Snow Blocks can build winter-event demand"
            );
        }

        return EventCatalyst.NONE;
    }

    private static EventCatalyst activeMayorCatalyst(
            String id,
            MayorData mayor
    ) {

        String category =
                categoryFor(id);

        if (category == null) {

            if (
                    mayor.name().equalsIgnoreCase("Diaz") &&
                    isDiazItem(id)
            ) {

                return new EventCatalyst(
                        4,
                        2.1,
                        "Diaz is active; Stock of Stonks and coin-flow markets can get mayor-driven demand"
                );
            }

            if (
                    mayor.name().equalsIgnoreCase("Jerry") &&
                    isJerryItem(id)
            ) {

                return new EventCatalyst(
                        3,
                        1.6,
                        "Jerry is active; Jerry Box and gift markets can move around mayor perk rotation"
                );
            }

            if (
                    mayor.name().equalsIgnoreCase("Scorpius") &&
                    isScorpiusItem(id)
            ) {

                return new EventCatalyst(
                        3,
                        1.5,
                        "Scorpius is active; Dark Auction-adjacent items can see extra demand from bonus coins"
                );
            }

            return EventCatalyst.NONE;
        }

        int tokens =
                activeMayorTokens(
                        mayor.name(),
                        category,
                        id,
                        mayor
                );

        if (tokens <= 0) {

            return EventCatalyst.NONE;
        }

        return new EventCatalyst(
                tokens,
                Math.min(2.4, tokens * 0.45),
                activeMayorReason(
                        mayor.name(),
                        category,
                        id,
                        mayor
                )
        );
    }

    private static EventCatalyst calendarEventCatalyst(
            String id,
            SkyBlockDate date
    ) {

        List<EventRule> rules =
                List.of(
                        new EventRule(
                                "Hoppity's Hunt",
                                0,
                                1,
                                7,
                                "hoppity"
                        ),
                        new EventRule(
                                "Traveling Zoo",
                                3,
                                1,
                                4,
                                "zoo"
                        ),
                        new EventRule(
                                "Spooky Festival",
                                7,
                                26,
                                5,
                                "spooky"
                        ),
                        new EventRule(
                                "Traveling Zoo",
                                9,
                                1,
                                4,
                                "zoo"
                        ),
                        new EventRule(
                                "Season of Jerry",
                                11,
                                24,
                                5,
                                "winter"
                        ),
                        new EventRule(
                                "New Year Celebration",
                                11,
                                29,
                                4,
                                "new_year"
                        )
                );

        EventCatalyst best =
                EventCatalyst.NONE;

        for (EventRule rule : rules) {

            if (!eventAffects(id, rule.category())) {

                continue;
            }

            int daysUntil =
                    daysUntil(date, rule.month(), rule.day());

            if (daysUntil <= 2) {

                best =
                        strongest(
                                best,
                                new EventCatalyst(
                                        3,
                                        1.6,
                                        rule.name() +
                                        " starts soon; related " +
                                        rule.category() +
                                        " items can see pre-event demand"
                                )
                        );

            } else if (daysUntil <= 10) {

                best =
                        strongest(
                                best,
                                new EventCatalyst(
                                        2,
                                        0.9,
                                        rule.name() +
                                        " is within " +
                                        daysUntil +
                                        " SkyBlock days; event flip demand is building"
                                )
                        );

            } else if (daysSince(date, rule.month(), rule.day()) <=
                    rule.supplyDays()) {

                best =
                        strongest(
                                best,
                                new EventCatalyst(
                                        1,
                                        0.35,
                                        rule.name() +
                                        " recently added supply; discounted items may rebound after the event"
                                )
                        );
            }
        }

        if (
                eventAffects(id, "century") &&
                date.year() % 100 >= 96
        ) {

            best =
                    strongest(
                            best,
                            new EventCatalyst(
                                    2,
                                    1.0,
                                    "A 100th SkyBlock year is approaching; century and cake items get extra event attention"
                            )
                    );
        }

        return best;
    }

    private static EventCatalyst skyBlockYearCatalyst(
            String id,
            SkyBlockDate date
    ) {

        EventCatalyst best =
                EventCatalyst.NONE;

        if (
                eventAffects(id, "seal") &&
                date.year() % 100 >= 96
        ) {

            best =
                    strongest(
                            best,
                            new EventCatalyst(
                                    3,
                                    1.4,
                                    "Year of the Seal is approaching; Enchanted Clay Blocks and Enchanted Cooked Fish can gain calendar demand"
                            )
                    );
        }

        if (
                eventAffects(id, "pig") &&
                date.year() % 100 >= 96
        ) {

            best =
                    strongest(
                            best,
                            new EventCatalyst(
                                    3,
                                    1.4,
                                    "Year of the Pig is approaching; Enchanted Pork and Enchanted Grilled Pork can gain calendar demand"
                            )
                    );
        }

        return best;
    }

    private static EventCatalyst realLifeEventCatalyst(String id) {

        LocalDate today =
                LocalDate.now(ZoneOffset.UTC);

        EventCatalyst best =
                EventCatalyst.NONE;

        if (
                eventAffects(id, "pig") &&
                daysUntilDate(today, 6, 11) <= 14
        ) {

            best =
                    strongest(
                            best,
                            new EventCatalyst(
                                    2,
                                    1.0,
                                    "SkyBlock Anniversary and Shiny Pig rewards are close; pig-shop and orb markets can move"
                            )
                    );
        }

        if (
                eventAffects(id, "witch") &&
                daysUntilDate(today, 10, 1) <= 21
        ) {

            best =
                    strongest(
                            best,
                            new EventCatalyst(
                                    2,
                                    1.0,
                                    "Great Spook season is close; spooky and alchemy-adjacent items can gain event demand"
                            )
                    );
        }

        return best;
    }

    private static boolean eventAffects(
            String id,
            String category
    ) {

        return switch (category) {
            case "hoppity" -> containsAny(
                    id,
                    "CHOCOLATE",
                    "RABBIT",
                    "EGGLOCATOR",
                    "HOPPITY"
            );
            case "zoo" -> containsAny(
                    id,
                    "PET",
                    "BLUE_WHALE",
                    "TIGER",
                    "LION",
                    "MONKEY",
                    "ELEPHANT",
                    "GIRAFFE"
            );
            case "spooky" -> containsAny(
                    id,
                    "CANDY",
                    "PUMPKIN",
                    "BAT",
                    "SOUL_FRAGMENT",
                    "VAMPIRE",
                    "WEREWOLF",
                    "SPOOKY",
                    "ECTOPLASM"
            );
            case "winter" -> containsAny(
                    id,
                    "GIFT",
                    "PARTY_GIFT",
                    "SNOW",
                    "ICE",
                    "VOLCANIC_ROCK",
                    "FROSTY",
                    "JERRY"
            );
            case "new_year" -> containsAny(
                    id,
                    "NEW_YEAR",
                    "CAKE"
            );
            case "century", "seal" -> containsAny(
                    id,
                    "CENTURY",
                    "RAFFLE",
                    "CAKE",
                    "SEAL",
                    "ENCHANTED_CLAY_BLOCK",
                    "ENCHANTED_COOKED_FISH"
            );
            case "pig" -> containsAny(
                    id,
                    "PIG",
                    "ENCHANTED_PORK",
                    "ENCHANTED_GRILLED_PORK",
                    "ENCHANTED_COOKED_PORKCHOP",
                    "SHINY_ORB",
                    "POTATO"
            );
            case "witch" -> containsAny(
                    id,
                    "GREAT_SPOOK",
                    "SPOOKY",
                    "WITCH",
                    "ALCHEMIST",
                    "EERIE",
                    "DARK_CANDY"
            );
            default -> false;
        };
    }

    private static EventCatalyst strongest(
            EventCatalyst left,
            EventCatalyst right
    ) {

        return right.tokens() > left.tokens()
                ? right
                : left;
    }

    private static SkyBlockDate currentSkyBlockDate(
            MayorData mayor
    ) {

        long now =
                System.currentTimeMillis();

        long elapsed =
                Math.max(0, now - SKYBLOCK_EPOCH_MS);

        int estimatedYear =
                (int) (elapsed / SKYBLOCK_YEAR_MS);

        int year =
                Math.max(
                        estimatedYear,
                        mayor == null ? 0 : mayor.currentYear()
                );

        long yearElapsed =
                elapsed % SKYBLOCK_YEAR_MS;

        return new SkyBlockDate(
                year,
                (int) (yearElapsed / SKYBLOCK_MONTH_MS),
                (int) ((yearElapsed % SKYBLOCK_MONTH_MS) /
                        SKYBLOCK_DAY_MS) + 1
        );
    }

    private static int daysUntil(
            SkyBlockDate date,
            int month,
            int day
    ) {

        int currentDay =
                date.month() * 31 + date.day();

        int targetDay =
                month * 31 + day;

        int delta =
                targetDay - currentDay;

        return delta >= 0
                ? delta
                : delta + 372;
    }

    private static int daysSince(
            SkyBlockDate date,
            int month,
            int day
    ) {

        int currentDay =
                date.month() * 31 + date.day();

        int targetDay =
                month * 31 + day;

        int delta =
                currentDay - targetDay;

        return delta >= 0
                ? delta
                : delta + 372;
    }

    private static int daysUntilDate(
            LocalDate today,
            int month,
            int day
    ) {

        LocalDate target =
                LocalDate.of(
                        today.getYear(),
                        month,
                        day
                );

        if (target.isBefore(today)) {

            target =
                    target.plusYears(1);
        }

        return (int) java.time.Duration.between(
                today.atStartOfDay(),
                target.atStartOfDay()
        ).toDays();
    }

    private static int pollTokens(MayorData mayor) {

        double strength =
                pollStrength(mayor);

        if (strength >= 0.75) {

            return 3;
        }

        if (strength >= 0.5) {

            return 2;
        }

        return strength >= 0.25
                ? 1
                : 0;
    }

    private static double pollStrength(MayorData mayor) {

        MayorData.CandidateData leader =
                mayor.leadingCandidate();

        if (leader == null) {

            return 0;
        }

        double shareStrength =
                Math.max(
                        0,
                        Math.min(
                                1,
                                (leader.voteShare() - 0.25) / 0.5
                        )
                );

        double marginStrength =
                Math.max(
                        0,
                        Math.min(
                                1,
                                pollLeadMargin(mayor) / 0.35
                        )
                );

        return shareStrength * 0.6 +
               marginStrength * 0.4;
    }

    private static double pollLeadMargin(
            MayorData mayor
    ) {

        List<MayorData.CandidateData> candidates =
                mayor.electionCandidates();

        if (
                candidates == null ||
                candidates.isEmpty()
        ) {

            return mayor.leadingCandidate() == null
                    ? 0
                    : mayor.leadingCandidate().voteShare();
        }

        double secondPlace =
                candidates.size() < 2
                        ? 0
                        : candidates.get(1).voteShare();

        return Math.max(
                0,
                candidates.get(0).voteShare() -
                secondPlace
        );
    }

    private static MayorData.CandidateData projectedMinister(
            MayorData mayor
    ) {

        List<MayorData.CandidateData> candidates =
                mayor.electionCandidates();

        return candidates != null &&
               candidates.size() >= 2
                ? candidates.get(1)
                : null;
    }

    private static int activeMayorTokens(
            String mayor,
            String category,
            String id,
            MayorData mayorData
    ) {

        String normalized =
                mayor.toLowerCase(Locale.ROOT);

        return switch (normalized) {
            case "aatrox" -> category.equals("slayer")
                    ? 3
                    : 0;
            case "cole" -> {
                if (isGemstoneItem(id)) {
                    yield afterLastMiningFiesta(mayorData)
                            ? 5
                            : 0;
                }

                yield category.equals("mining") &&
                      afterLastMiningFiesta(mayorData)
                        ? 3
                        : 0;
            }
            case "diana" -> category.equals("mythological") ||
                             isGoldItem(id)
                    ? 3
                    : 0;
            case "diaz" -> isDiazItem(id)
                    ? 4
                    : 0;
            case "derpy" -> List.of(
                    "mining",
                    "fishing",
                    "farming"
            ).contains(category)
                    ? 2
                    : 0;
            case "finnegan" -> category.equals("farming")
                    ? 3
                    : 0;
            case "foxy" -> category.equals("event") ||
                            eventAffects(id, "spooky") ||
                            eventAffects(id, "winter")
                    ? 3
                    : 0;
            case "jerry" -> category.equals("event") ||
                             isJerryItem(id) ||
                             isJerryRotationFlipItem(id)
                    ? 3
                    : 0;
            case "marina" -> category.equals("fishing")
                    ? 3
                    : 0;
            case "paul" -> category.equals("dungeon")
                    ? 3
                    : 0;
            case "scorpius" -> isScorpiusItem(id)
                    ? 3
                    : 0;
            default -> 0;
        };
    }

    private static int projectedMayorTokens(
            String mayor,
            String category,
            String id,
            MayorData mayorData
    ) {

        int activeEquivalent =
                activeMayorTokens(
                        mayor,
                        category,
                        id,
                        mayorData
                );

        return activeEquivalent <= 0
                ? 0
                : Math.max(
                        1,
                        Math.min(3, activeEquivalent - 1)
                );
    }

    private static String activeMayorReason(
            String mayor,
            String category,
            String id,
            MayorData mayorData
    ) {

        String normalized =
                mayor.toLowerCase(Locale.ROOT);

        return switch (normalized) {
            case "aatrox" -> category.equals("slayer")
                    ? "Aatrox is active; cheaper slayer grinding can increase slayer-material supply, so discounted drops can become rebound entries after the rush"
                    : "";
            case "cole" -> category.equals("mining")
                    ? afterLastMiningFiesta(mayorData)
                            ? "Cole's final Mining Fiesta has passed; mining materials can be near peak supply and may rebound after the term"
                            : "Cole is active but mining supply pressure can continue until the final Mining Fiesta has passed"
                    : "";
            case "diana" -> category.equals("mythological") ||
                             isGoldItem(id)
                    ? "Diana is active; Mythological Ritual demand supports griffin, claw, Minos, and gold-related markets"
                    : "";
            case "diaz" -> isDiazItem(id)
                    ? "Diaz is active; Stock of Stonks and coin-flow markets can get mayor-driven attention"
                    : "";
            case "derpy" -> List.of(
                    "mining",
                    "fishing",
                    "farming"
            ).contains(category)
                    ? "Derpy is active; boosted minion and skill activity can distort raw-material supply, making deep discounts worth watching"
                    : "";
            case "finnegan" -> category.equals("farming")
                    ? "Finnegan is active; farming-contest and crop supply can create post-event rebound entries in discounted crops"
                    : "";
            case "foxy" -> category.equals("event") ||
                            eventAffects(id, "spooky") ||
                            eventAffects(id, "winter")
                    ? "Foxy is active; extra event activity can boost demand and supply for spooky, winter, zoo, and other event markets"
                    : "";
            case "jerry" -> category.equals("event") ||
                             isJerryItem(id) ||
                             isJerryRotationFlipItem(id)
                    ? "Jerry is active; perk rotation and Jerry Box attention can move gift, Marina, Cole, and Diana-adjacent markets"
                    : "";
            case "marina" -> category.equals("fishing")
                    ? "Marina is active; Fishing Festival activity can pressure fish and shark materials before a rebound window"
                    : "";
            case "paul" -> category.equals("dungeon")
                    ? "Paul is active; dungeon traffic can move essence and dungeon-material markets during and after the term"
                    : "";
            case "scorpius" -> isScorpiusItem(id)
                    ? "Scorpius is active; bonus coins can push demand into Dark Auction-adjacent markets"
                    : "";
            default -> "";
        };
    }

    private static String projectedMayorReason(
            String mayor,
            String category,
            String id,
            MayorData mayorData
    ) {

        String activeReason =
                activeMayorReason(
                        mayor,
                        category,
                        id,
                        mayorData
                );

        if (activeReason.isBlank()) {

            return "";
        }

        return activeReason.replace(
                " is active",
                " is likely next"
        );
    }

    private static int projectedSpecialMayorTokens(
            String mayor,
            String id,
            MayorData mayorData
    ) {

        double strength =
                pollStrength(mayorData);

        if (strength < 0.25) {

            return 0;
        }

        if (
                mayor.equalsIgnoreCase("Diaz") &&
                isDiazItem(id)
        ) {

            return Math.max(2, pollTokens(mayorData) + 1);
        }

        if (
                mayor.equalsIgnoreCase("Jerry") &&
                isJerryItem(id)
        ) {

            return Math.max(2, pollTokens(mayorData));
        }

        if (
                mayor.equalsIgnoreCase("Scorpius") &&
                isScorpiusItem(id)
        ) {

            return Math.max(2, pollTokens(mayorData));
        }

        if (
                mayor.equalsIgnoreCase("Foxy") &&
                (isEventItem(id) || isPartyGiftItem(id))
        ) {

            return Math.max(2, pollTokens(mayorData));
        }

        return 0;
    }

    private static String projectedSpecialMayorReason(
            String mayor,
            String id,
            MayorData mayorData
    ) {

        if (projectedSpecialMayorTokens(mayor, id, mayorData) <= 0) {

            return "";
        }

        if (mayor.equalsIgnoreCase("Diaz")) {

            return "Diaz leads the election; Stock of Stonks and coin-flow markets can move before the term";
        }

        if (mayor.equalsIgnoreCase("Jerry")) {

            return "Jerry leads the election; Jerry Box, gift, and perk-rotation markets can move before the term";
        }

        if (mayor.equalsIgnoreCase("Scorpius")) {

            return "Scorpius leads the election; Dark Auction-adjacent markets can move before bonus coins arrive";
        }

        if (mayor.equalsIgnoreCase("Foxy")) {

            return isPartyGiftItem(id)
                    ? "Foxy leads the election; Party Gifts can price in extra festival activity before the term"
                    : "Foxy leads the election; event items can price in extra festival activity before the term";
        }

        return "";
    }

    private static boolean isGoldItem(String id) {

        return id.contains("GOLD") ||
               id.equals("ENCHANTED_GOLD_BLOCK");
    }

    private static boolean isDiazItem(String id) {

        return id.equals("STOCK_OF_STONKS") ||
               id.contains("STONKS") ||
               id.contains("SHEN");
    }

    private static boolean isJerryItem(String id) {

        return containsAny(
                id,
                "JERRY",
                "GREEN_GIFT",
                "WHITE_GIFT",
                "RED_GIFT"
        );
    }

    private static boolean isPartyGiftItem(String id) {

        return id.contains("PARTY_GIFT");
    }

    private static boolean isWhiteSharkToothItem(String id) {

        return id.equals("GREAT_WHITE_SHARK_TOOTH") ||
               id.equals("WHITE_SHARK_TOOTH") ||
               id.contains("WHITE_SHARK_TOOTH");
    }

    private static boolean isSeasonOfJerryItem(String id) {

        return id.equals("ENCHANTED_ICE") ||
               id.equals("ENCHANTED_SNOW_BLOCK") ||
               isVolcanicRockItem(id);
    }

    private static boolean isVolcanicRockItem(String id) {

        return id.equals("VOLCANIC_ROCK") ||
               id.equals("VOLCANIC_ROCKS") ||
               id.contains("VOLCANIC_ROCK");
    }

    private static boolean isJerryRotationFlipItem(String id) {

        return isWhiteSharkToothItem(id) ||
               isGemstoneItem(id) ||
               isGoldItem(id) ||
               categoryFor(id) != null &&
               (
                   categoryFor(id).equals("mining") ||
                   categoryFor(id).equals("fishing") ||
                   categoryFor(id).equals("mythological")
               );
    }

    private static boolean isScorpiusItem(String id) {

        return containsAny(
                id,
                "DARK_AUCTION",
                "MIDAS",
                "SHADOW_ASSASSIN",
                "PLASMA_NUCLEUS",
                "DARK_CANDY",
                "WITHER_ARTIFACT"
        );
    }

    private static boolean isEventItem(String id) {

        return eventAffects(id, "hoppity") ||
               eventAffects(id, "zoo") ||
               eventAffects(id, "spooky") ||
               eventAffects(id, "winter") ||
               eventAffects(id, "new_year") ||
               eventAffects(id, "pig") ||
               eventAffects(id, "witch");
    }

    private static boolean isGemstoneItem(String id) {

        return containsAny(
                id,
                "GEMSTONE",
                "RUBY",
                "JASPER",
                "JADE",
                "SAPPHIRE",
                "AMBER",
                "AMETHYST",
                "TOPAZ",
                "OPAL",
                "ONYX",
                "AQUAMARINE",
                "CITRINE",
                "PERIDOT"
        );
    }

    private static boolean afterLastMiningFiesta(MayorData mayor) {

        SkyBlockDate date =
                currentSkyBlockDate(mayor);

        return date.month() > 6 ||
               (
                   date.month() == 6 &&
                   date.day() > 5
               );
    }

    private static boolean isSeasonOfJerryWindow(SkyBlockDate date) {

        return daysUntil(date, 11, 24) <= 10 ||
               daysSince(date, 11, 24) <= 5;
    }

    private static boolean affects(
            String mayor,
            String category
    ) {

        return switch (mayor.toLowerCase(Locale.ROOT)) {
            case "cole" -> category.equals("mining");
            case "marina" -> category.equals("fishing");
            case "finnegan" -> category.equals("farming");
            case "aatrox" -> category.equals("slayer");
            case "paul" -> category.equals("dungeon");
            case "diana" -> category.equals("mythological");
            case "derpy" -> List.of(
                    "mining",
                    "fishing",
                    "farming"
            ).contains(category);
            case "foxy", "jerry" -> category.equals("event");
            default -> false;
        };
    }

    private static String categoryFor(String itemId) {

        String id =
                itemId.toUpperCase(Locale.ROOT);

        if (containsAny(
                id,
                "GEM",
                "MITHRIL",
                "TITANIUM",
                "COAL",
                "IRON",
                "GOLD",
                "DIAMOND",
                "EMERALD",
                "REDSTONE",
                "LAPIS",
                "QUARTZ",
                "COBBLESTONE",
                "OBSIDIAN",
                "GLOWSTONE"
        )) {

            return "mining";
        }

        if (containsAny(
                id,
                "FISH",
                "SHARK",
                "INK_SACK",
                "LILY_PAD",
                "SPONGE",
                "PRISMARINE",
                "MAGMAFISH"
        )) {

            return "fishing";
        }

        if (containsAny(
                id,
                "WHEAT",
                "CARROT",
                "POTATO",
                "MELON",
                "PUMPKIN",
                "CACTUS",
                "SUGAR_CANE",
                "COCOA",
                "MUSHROOM",
                "NETHER_STALK"
        )) {

            return "farming";
        }

        if (containsAny(
                id,
                "REVENANT",
                "TARANTULA",
                "SVEN",
                "VOIDLING",
                "NULL_SPHERE",
                "DERELICT_ASHE",
                "CRUDE_GABAGOOL"
        )) {

            return "slayer";
        }

        if (containsAny(
                id,
                "ESSENCE",
                "DUNGEON",
                "LIVID",
                "BONZO",
                "SCARF",
                "SADAN",
                "WITHER"
        )) {

            return "dungeon";
        }

        if (containsAny(
                id,
                "ANCIENT_CLAW",
                "GRIFFIN_FEATHER",
                "DAEDALUS",
                "MINOS"
        )) {

            return "mythological";
        }

        if (isEventItem(id)) {

            return "event";
        }

        return null;
    }

    private static boolean containsAny(
            String value,
            String... needles
    ) {

        for (String needle : needles) {

            if (value.contains(needle)) {

                return true;
            }
        }

        return false;
    }

    private record SkyBlockDate(
            int year,
            int month,
            int day
    ) {
    }

    private record EventRule(
            String name,
            int month,
            int day,
            int supplyDays,
            String category
    ) {
    }

    private record EventCatalyst(
            int tokens,
            double impactPercent,
            String reason
    ) {

        private static final EventCatalyst NONE =
                new EventCatalyst(
                        0,
                        0,
                        ""
                );
    }

    public record MayorSignal(
            String mayor,
            double impactPercent,
            String reason,
            int catalystTokens,
            String catalystReason
    ) {

        private static final MayorSignal NONE =
                new MayorSignal(
                        "Unavailable",
                        0,
                        "Mayor data unavailable",
                        0,
                        ""
                );
    }
}
