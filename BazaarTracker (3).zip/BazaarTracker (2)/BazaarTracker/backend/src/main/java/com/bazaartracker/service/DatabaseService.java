package com.bazaartracker.service;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

import com.bazaartracker.model.CraftIngredientData;
import com.bazaartracker.model.CraftRecipeData;
import com.bazaartracker.model.FlipData;
import com.bazaartracker.model.FusionFlipData;
import com.bazaartracker.model.FusionFlipData.FusionStepData;
import com.bazaartracker.model.MayorData;
import com.bazaartracker.model.MarketStealData;
import com.bazaartracker.model.PriceData;
import com.bazaartracker.model.PredictionData;
import com.bazaartracker.model.PredictionResultData;
import com.bazaartracker.service.MayorMarketAnalyzer.MayorSignal;

public class DatabaseService {

    private static final String DB_URL =
            "jdbc:sqlite:data/bazaar.db";

    private static final double TARGET_PREDICTION_SUCCESS_RATE =
            0.70;

    private static final double MINIMUM_CRAFT_FLIP_PROFIT =
            5_000;

    private static final int AUCTION_SALE_HISTORY_DAYS =
            3;

    private static final int MINIMUM_AUCTION_SALES_FOR_AVERAGE =
            5;

    private static final DateTimeFormatter SQLITE_TIMESTAMP_FORMAT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private static final Object MARKET_STEAL_CACHE_LOCK =
            new Object();

    private static volatile List<MarketStealData>
            marketStealCache =
                    List.of();

    private static volatile boolean marketStealCacheDirty =
            true;

    private static final List<CraftingRecipe> CRAFTING_RECIPES =
            loadCraftingRecipes();

    private static final List<CraftingRecipe> FORGE_RECIPES =
            loadForgeRecipes();

    private static final List<FusionRecipe> FUSION_RECIPES =
            loadFusionRecipes();

    private final MayorService mayorService =
            new MayorService();

    public DatabaseService() {

        createTable();
    }

    private void createTable() {

        try (
            Connection conn =
                    DriverManager.getConnection(DB_URL);

            Statement stmt =
                    conn.createStatement()
        ) {

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS bazaar_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    item_id TEXT,
                    buy_price REAL,
                    sell_price REAL,
                    buy_volume REAL,
                    sell_volume REAL,
                    buy_moving_week REAL DEFAULT 0,
                    sell_moving_week REAL DEFAULT 0,
                    best_sell_offer REAL DEFAULT 0,
                    best_sell_offer_amount REAL DEFAULT 0,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """);

            addColumnIfMissing(
                    conn,
                    "buy_moving_week",
                    "REAL DEFAULT 0"
            );

            addColumnIfMissing(
                    conn,
                    "sell_moving_week",
                    "REAL DEFAULT 0"
            );

            addColumnIfMissing(
                    conn,
                    "best_sell_offer",
                    "REAL DEFAULT 0"
            );

            addColumnIfMissing(
                    conn,
                    "best_sell_offer_amount",
                    "REAL DEFAULT 0"
            );

            stmt.execute("""
                CREATE INDEX IF NOT EXISTS
                    idx_bazaar_history_item_id_id
                ON bazaar_history (item_id, id DESC)
            """);

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS ah_listings (
                    auction_uuid TEXT PRIMARY KEY,
                    item_key TEXT NOT NULL,
                    item_name TEXT NOT NULL,
                    tier TEXT,
                    category TEXT,
                    price REAL NOT NULL,
                    start_time INTEGER NOT NULL,
                    end_time INTEGER NOT NULL,
                    first_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    active INTEGER NOT NULL DEFAULT 1
                )
            """);

            stmt.execute("""
                CREATE INDEX IF NOT EXISTS
                    idx_ah_listings_market
                ON ah_listings (active, item_key, price)
            """);

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS ah_sold_auctions (
                    auction_uuid TEXT PRIMARY KEY,
                    item_key TEXT,
                    item_name TEXT,
                    sold_at INTEGER NOT NULL,
                    sold_price REAL NOT NULL
                )
            """);

            addColumnIfMissing(
                    conn,
                    "ah_sold_auctions",
                    "item_key",
                    "TEXT"
            );

            addColumnIfMissing(
                    conn,
                    "ah_sold_auctions",
                    "item_name",
                    "TEXT"
            );

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS prediction_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    item_id TEXT NOT NULL,
                    recommendation TEXT NOT NULL,
                    start_price REAL NOT NULL,
                    predicted_price REAL NOT NULL,
                    expected_change_percent REAL NOT NULL,
                    confidence REAL NOT NULL,
                    horizon_minutes INTEGER NOT NULL,
                    investment_style TEXT,
                    investment_tokens INTEGER DEFAULT 0,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    due_at TEXT NOT NULL,
                    snapshot_bucket TEXT NOT NULL,
                    actual_price REAL,
                    actual_change_percent REAL,
                    successful INTEGER,
                    target_hit INTEGER,
                    evaluated_at TEXT,
                    UNIQUE (
                        item_id,
                        recommendation,
                        horizon_minutes,
                        snapshot_bucket
                    )
                )
            """);

            stmt.execute("""
                CREATE INDEX IF NOT EXISTS
                    idx_prediction_history_due
                ON prediction_history (evaluated_at, due_at)
            """);

            stmt.execute("""
                CREATE INDEX IF NOT EXISTS
                    idx_bazaar_history_timestamp
                ON bazaar_history (timestamp)
            """);

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS bazaar_history_rollup (
                    item_id TEXT NOT NULL,
                    bucket_start TEXT NOT NULL,
                    granularity TEXT NOT NULL,
                    buy_price REAL NOT NULL,
                    sell_price REAL NOT NULL,
                    sample_count INTEGER NOT NULL,
                    PRIMARY KEY (
                        item_id,
                        bucket_start,
                        granularity
                    )
                )
            """);

            stmt.execute("""
                CREATE INDEX IF NOT EXISTS
                    idx_history_rollup_range
                ON bazaar_history_rollup (
                    granularity,
                    bucket_start,
                    item_id
                )
            """);

            stmt.execute("""
                CREATE TABLE IF NOT EXISTS bazaar_daily_history (
                    item_id TEXT NOT NULL,
                    buy_price REAL NOT NULL,
                    sell_price REAL NOT NULL,
                    buy_volume REAL DEFAULT 0,
                    sell_volume REAL DEFAULT 0,
                    buy_moving_week REAL DEFAULT 0,
                    sell_moving_week REAL DEFAULT 0,
                    timestamp TEXT NOT NULL,
                    source TEXT NOT NULL,
                    PRIMARY KEY (item_id, timestamp, source)
                )
            """);

            stmt.execute("""
                CREATE INDEX IF NOT EXISTS
                    idx_daily_history_item_timestamp
                ON bazaar_daily_history (item_id, timestamp)
            """);

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    private void addColumnIfMissing(
            Connection conn,
            String columnName,
            String definition
    ) {

        addColumnIfMissing(
                conn,
                "bazaar_history",
                columnName,
                definition
        );
    }

    private void addColumnIfMissing(
            Connection conn,
            String tableName,
            String columnName,
            String definition
    ) {

        try (
            Statement stmt =
                    conn.createStatement()
        ) {

            stmt.execute(
                    "ALTER TABLE " + tableName + " ADD COLUMN " +
                    columnName + " " + definition
            );

        } catch (Exception ignored) {

            // The column already exists.
        }
    }

    public void saveItem(
            String itemId,
            double buyPrice,
            double sellPrice,
            double buyVolume,
            double sellVolume,
            double buyMovingWeek,
            double sellMovingWeek,
            double bestSellOffer,
            double bestSellOfferAmount
    ) {

        try (
            Connection conn =
                    DriverManager.getConnection(DB_URL)
        ) {

            conn.setAutoCommit(false);

            String timestamp =
                    fiveMinuteBucketTimestamp();

            try (
                    PreparedStatement deleteCurrentBucket =
                            conn.prepareStatement(
                                    """
                                    DELETE FROM bazaar_history
                                    WHERE item_id = ?
                                      AND timestamp = ?
                                    """
                            )
            ) {

                deleteCurrentBucket.setString(1, itemId);
                deleteCurrentBucket.setString(2, timestamp);
                deleteCurrentBucket.executeUpdate();
            }

            String sql = """
                INSERT INTO bazaar_history
                (
                    item_id,
                    buy_price,
                    sell_price,
                    buy_volume,
                    sell_volume,
                    buy_moving_week,
                    sell_moving_week,
                    best_sell_offer,
                    best_sell_offer_amount,
                    timestamp
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """;

            try (
                    PreparedStatement ps =
                            conn.prepareStatement(sql)
            ) {

                ps.setString(1, itemId);
                ps.setDouble(2, buyPrice);
                ps.setDouble(3, sellPrice);
                ps.setDouble(4, buyVolume);
                ps.setDouble(5, sellVolume);
                ps.setDouble(6, buyMovingWeek);
                ps.setDouble(7, sellMovingWeek);
                ps.setDouble(8, bestSellOffer);
                ps.setDouble(9, bestSellOfferAmount);
                ps.setString(10, timestamp);

                ps.executeUpdate();
            }

            conn.commit();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    private String fiveMinuteBucketTimestamp() {

        LocalDateTime now =
                LocalDateTime.now(ZoneOffset.UTC);

        int bucketMinute =
                now.getMinute() -
                now.getMinute() % 5;

        return now
                .withMinute(bucketMinute)
                .withSecond(0)
                .withNano(0)
                .format(SQLITE_TIMESTAMP_FORMAT);
    }

    public String searchItem(String itemId) {

        StringBuilder result =
                new StringBuilder();

        try (
            Connection conn =
                    DriverManager.getConnection(DB_URL);

            PreparedStatement ps =
                    conn.prepareStatement(
                            """
                            SELECT *
                            FROM bazaar_history
                            WHERE item_id = ?
                            ORDER BY timestamp DESC
                            LIMIT 1
                            """
                    )
        ) {

            ps.setString(1, itemId);

            ResultSet rs =
                    ps.executeQuery();

            if (rs.next()) {

                result.append("Item: ");
                result.append(rs.getString("item_id"));

                result.append(" | Buy: ");
                result.append(rs.getDouble("buy_price"));

                result.append(" | Sell: ");
                result.append(rs.getDouble("sell_price"));

                result.append(" | Buy Volume: ");
                result.append(rs.getDouble("buy_volume"));

                result.append(" | Sell Volume: ");
                result.append(rs.getDouble("sell_volume"));
            }

        } catch (Exception e) {

            e.printStackTrace();
        }

        return result.toString();
    }

public List<PriceData> getHistory(
        String itemId,
        String requestedRange
) {

    List<PriceData> history =
            new ArrayList<>();

    HistoryRange range =
            HistoryRange.from(requestedRange);

    String bucketExpression =
            switch (range.granularity()) {
                case "raw" ->
                        "strftime('%Y-%m-%d %H:00:00', timestamp)";
                case "hour" ->
                        "strftime('%Y-%m-%d %H:00:00', timestamp)";
                case "day" ->
                        "strftime('%Y-%m-%d 00:00:00', timestamp)";
                case "week" ->
                        "date(timestamp, '-' || " +
                        "((CAST(strftime('%w', timestamp) AS INTEGER) + 6) % 7) " +
                        "|| ' days')";
                default ->
                        throw new IllegalStateException(
                                "Unsupported history granularity"
                        );
            };

    String sql =
            """
            WITH retained_points AS (
                SELECT
                    item_id,
                    timestamp,
                    buy_price,
                    sell_price,
                    1 AS weight
                FROM bazaar_history
                WHERE item_id = ?
                  AND timestamp >= datetime('now', ?)

                UNION ALL

                SELECT
                    item_id,
                    bucket_start AS timestamp,
                    buy_price,
                    sell_price,
                    sample_count AS weight
                FROM bazaar_history_rollup
                WHERE item_id = ?
                  AND bucket_start >= datetime('now', ?)
            )
            SELECT
                %s AS bucket,
                SUM(buy_price * weight) / SUM(weight) AS buy_price,
                SUM(sell_price * weight) / SUM(weight) AS sell_price
            FROM retained_points
            GROUP BY bucket
            ORDER BY bucket
            """.formatted(bucketExpression);

    try (
        Connection conn =
                DriverManager.getConnection(DB_URL);

        PreparedStatement ps =
                conn.prepareStatement(sql)
    ) {

        ps.setString(1, itemId);
        ps.setString(2, range.sqliteModifier());
        ps.setString(3, itemId);
        ps.setString(4, range.sqliteModifier());

        ResultSet rs =
                ps.executeQuery();

        while (rs.next()) {

            history.add(
                    new PriceData(
                            rs.getString("bucket"),
                            rs.getDouble("buy_price"),
                            rs.getDouble("sell_price")
                    )
            );
        }

    } catch (Exception e) {

        e.printStackTrace();
    }

    return history;
}

public void compactHistory() {

    try (
        Connection conn =
                DriverManager.getConnection(DB_URL);

        Statement stmt =
                conn.createStatement()
    ) {

        conn.setAutoCommit(false);

        rollUp(
                stmt,
                "bazaar_history",
                "hour",
                "strftime('%Y-%m-%d %H:00:00', timestamp)",
                "timestamp < datetime('now', '-1 day')",
                "1"
        );

        rollUp(
                stmt,
                "bazaar_history_rollup",
                "day",
                "strftime('%Y-%m-%d 00:00:00', bucket_start)",
                "granularity = 'hour' " +
                "AND bucket_start < datetime('now', '-7 days')",
                "sample_count"
        );

        rollUp(
                stmt,
                "bazaar_history_rollup",
                "week",
                "date(bucket_start, '-' || " +
                "((CAST(strftime('%w', bucket_start) AS INTEGER) + 6) % 7) " +
                "|| ' days')",
                "granularity = 'day' " +
                "AND bucket_start < datetime('now', '-30 days')",
                "sample_count"
        );

        stmt.executeUpdate(
                """
                INSERT OR REPLACE INTO bazaar_daily_history
                (
                    item_id,
                    buy_price,
                    sell_price,
                    buy_volume,
                    sell_volume,
                    buy_moving_week,
                    sell_moving_week,
                    timestamp,
                    source
                )
                SELECT
                    item_id,
                    buy_price,
                    sell_price,
                    0,
                    0,
                    0,
                    0,
                    bucket_start,
                    'BazaarTracker'
                FROM bazaar_history_rollup
                WHERE granularity = 'day'
                """
        );

        stmt.executeUpdate(
                """
                DELETE FROM bazaar_history
                WHERE timestamp < datetime('now', '-1 day')
                """
        );

        stmt.executeUpdate(
                """
                DELETE FROM bazaar_history_rollup
                WHERE granularity = 'hour'
                  AND bucket_start < datetime('now', '-7 days')
                """
        );

        stmt.executeUpdate(
                """
                DELETE FROM bazaar_history_rollup
                WHERE granularity = 'day'
                  AND bucket_start < datetime('now', '-30 days')
                """
        );

        stmt.executeUpdate(
                """
                DELETE FROM bazaar_history_rollup
                WHERE granularity = 'week'
                  AND bucket_start < datetime('now', '-1 year')
                """
        );

        conn.commit();

        marketStealCacheDirty = true;

    } catch (Exception e) {

        e.printStackTrace();
    }
}

private void rollUp(
        Statement stmt,
        String sourceTable,
        String granularity,
        String bucketExpression,
        String whereClause,
        String weightExpression
) throws Exception {

    stmt.executeUpdate(
            """
            INSERT OR REPLACE INTO bazaar_history_rollup
            (
                item_id,
                bucket_start,
                granularity,
                buy_price,
                sell_price,
                sample_count
            )
            SELECT
                item_id,
                %s,
                '%s',
                SUM(buy_price * %s) / SUM(%s),
                SUM(sell_price * %s) / SUM(%s),
                SUM(%s)
            FROM %s
            WHERE %s
            GROUP BY item_id, %s
            """.formatted(
                    bucketExpression,
                    granularity,
                    weightExpression,
                    weightExpression,
                    weightExpression,
                    weightExpression,
                    weightExpression,
                    sourceTable,
                    whereClause,
                    bucketExpression
            )
    );
}
    
    
public List<String> getAllItems() {

    List<String> items =
            new ArrayList<>();

    try (
        Connection conn =
                DriverManager.getConnection(DB_URL);

        Statement stmt =
                conn.createStatement()
    ) {

        ResultSet rs =
                stmt.executeQuery(
                        """
                        SELECT DISTINCT item_id
                        FROM bazaar_history
                        ORDER BY item_id
                        """
                );

        while (rs.next()) {

            items.add(
                    rs.getString("item_id")
            );
        }

    } catch (Exception e) {

        e.printStackTrace();
    }

    return items;
}
public List<String> searchItems(String query) {

    List<String> results = new ArrayList<>();
    String normalizedQuery =
            query == null
                    ? ""
                    : query.trim().toLowerCase();

    if (normalizedQuery.isEmpty()) {

        return results;
    }

    try (
        Connection conn =
                DriverManager.getConnection(DB_URL);

        PreparedStatement ps =
                conn.prepareStatement(
                        """
                        SELECT DISTINCT item_id
                        FROM bazaar_history
                        WHERE LOWER(item_id) LIKE ?
                           OR LOWER(REPLACE(item_id, '_', ' ')) LIKE ?
                        ORDER BY item_id
                        LIMIT 10
                        """
                )
    ) {

        ps.setString(
                1,
                "%" + normalizedQuery.replace(" ", "_") + "%"
        );

        ps.setString(
                2,
                "%" + normalizedQuery.replace("_", " ") + "%"
        );

        ResultSet rs =
                ps.executeQuery();

        while (rs.next()) {

            results.add(
                    rs.getString("item_id")
            );
        }

    } catch (Exception e) {

        e.printStackTrace();
    }

    return results;
}

public List<String> searchAuctionItems(String query) {

    List<String> results =
            new ArrayList<>();
    String normalizedQuery =
            query == null
                    ? ""
                    : query.trim().toLowerCase(Locale.ROOT);
    boolean petSearch =
            normalizedQuery.matches(".*\\bpet\\b.*");

    if (petSearch) {
        normalizedQuery =
                normalizedQuery
                        .replaceAll("\\bpet\\b", " ")
                        .replaceAll("\\s+", " ")
                        .trim();
    }

    if (normalizedQuery.length() < 2 && !petSearch) {
        return results;
    }

    try (
        Connection conn =
                DriverManager.getConnection(DB_URL);
        PreparedStatement ps =
                conn.prepareStatement(
                        """
                        SELECT item_name, COUNT(*) AS listing_count
                        FROM (
                            SELECT item_name
                            FROM ah_listings
                            WHERE active = 1
                              AND end_time > unixepoch('now') * 1000

                            UNION ALL

                            SELECT item_name
                            FROM ah_sold_auctions
                            WHERE sold_at >=
                                (unixepoch('now', '-3 days') * 1000)
                        ) auction_items
                        WHERE (? = 0 OR LOWER(item_name) LIKE '[lvl %')
                          AND LOWER(item_name) LIKE ?
                        GROUP BY LOWER(item_name)
                        ORDER BY listing_count DESC, item_name
                        LIMIT 10
                        """
                )
    ) {

        ps.setInt(1, petSearch ? 1 : 0);
        ps.setString(2, "%" + normalizedQuery + "%");
        ResultSet rs =
                ps.executeQuery();

        while (rs.next()) {
            results.add(rs.getString("item_name"));
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    return results;
}

public void replaceActiveAuctions(
        List<AuctionListing> listings
) {

    try (
        Connection conn =
                DriverManager.getConnection(DB_URL);

        Statement deactivate =
                conn.createStatement();

        PreparedStatement upsert =
                conn.prepareStatement(
                        """
                        INSERT INTO ah_listings
                        (
                            auction_uuid,
                            item_key,
                            item_name,
                            tier,
                            category,
                            price,
                            start_time,
                            end_time,
                            active
                        )
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
                        ON CONFLICT(auction_uuid) DO UPDATE SET
                            item_key = excluded.item_key,
                            item_name = excluded.item_name,
                            tier = excluded.tier,
                            category = excluded.category,
                            price = excluded.price,
                            start_time = excluded.start_time,
                            end_time = excluded.end_time,
                            last_seen = CURRENT_TIMESTAMP,
                            active = 1
                        """
                )
    ) {

        conn.setAutoCommit(false);

        deactivate.executeUpdate(
                "UPDATE ah_listings SET active = 0"
        );

        for (AuctionListing listing : listings) {

            upsert.setString(1, listing.auctionUuid());
            upsert.setString(2, listing.itemKey());
            upsert.setString(3, listing.itemName());
            upsert.setString(4, listing.tier());
            upsert.setString(5, listing.category());
            upsert.setDouble(6, listing.price());
            upsert.setLong(7, listing.startTime());
            upsert.setLong(8, listing.endTime());
            upsert.addBatch();
        }

        upsert.executeBatch();

        deactivate.executeUpdate(
                """
                DELETE FROM ah_listings
                WHERE active = 0
                """
        );

        conn.commit();

        marketStealCacheDirty = true;

    } catch (Exception e) {

        e.printStackTrace();
    }
}

public void recordSoldAuctions(
        List<SoldAuction> soldAuctions
) {

    try (
        Connection conn =
                DriverManager.getConnection(DB_URL);

        PreparedStatement recordSale =
                conn.prepareStatement(
                        """
                        INSERT OR REPLACE INTO ah_sold_auctions
                        (
                            auction_uuid,
                            item_key,
                            item_name,
                            sold_at,
                            sold_price
                        )
                        SELECT
                            ?,
                            item_key,
                            item_name,
                            ?,
                            ?
                        FROM ah_listings
                        WHERE auction_uuid = ?
                        """
                );

        PreparedStatement deleteListing =
                conn.prepareStatement(
                        "DELETE FROM ah_listings WHERE auction_uuid = ?"
                );

        Statement cleanup =
                conn.createStatement()
    ) {

        conn.setAutoCommit(false);

        for (SoldAuction auction : soldAuctions) {

            recordSale.setString(1, auction.auctionUuid());
            recordSale.setLong(2, auction.soldAt());
            recordSale.setDouble(3, auction.soldPrice());
            recordSale.setString(4, auction.auctionUuid());
            recordSale.addBatch();
        }

        recordSale.executeBatch();

        for (SoldAuction auction : soldAuctions) {

            deleteListing.setString(
                    1,
                    auction.auctionUuid()
            );
            deleteListing.addBatch();
        }

        deleteListing.executeBatch();

        cleanup.executeUpdate(
                """
                DELETE FROM ah_sold_auctions
                WHERE sold_at <
                    (unixepoch('now', '-3 days') * 1000)
                   OR item_key IS NULL
                """
        );

        conn.commit();

        marketStealCacheDirty = true;


        if (!soldAuctions.isEmpty()) {

            var soldIds =
                    soldAuctions.stream()
                            .map(SoldAuction::auctionUuid)
                            .collect(
                                    java.util.stream.Collectors.toSet()
                            );

            synchronized (MARKET_STEAL_CACHE_LOCK) {

                marketStealCache =
                        marketStealCache.stream()
                                .filter(steal ->
                                        !soldIds.contains(
                                                steal.auctionUuid()
                                        )
                                )
                                .toList();
            }
        }

    } catch (Exception e) {

        e.printStackTrace();
    }
}

public List<MarketStealData> getMarketSteals() {

    if (!marketStealCacheDirty) {

        return marketStealCache;
    }

    synchronized (MARKET_STEAL_CACHE_LOCK) {

        if (marketStealCacheDirty) {

            marketStealCache =
                    calculateMarketSteals();

            marketStealCacheDirty = false;
        }

        return marketStealCache;
    }
}

private List<MarketStealData> calculateMarketSteals() {

    Map<String, List<AuctionListing>> activeByItem =
            new HashMap<>();

    Map<String, Integer> turnoverByItem =
            new HashMap<>();

    Map<String, List<Double>> soldPricesByItem =
            new HashMap<>();

    Map<String, Long> soldAuctions =
            new HashMap<>();

    try (
        Connection conn =
                DriverManager.getConnection(DB_URL);

        Statement stmt =
                conn.createStatement()
    ) {

        ResultSet active =
                stmt.executeQuery(
                        """
                        SELECT *
                        FROM ah_listings
                        WHERE active = 1
                          AND end_time > unixepoch('now') * 1000
                        ORDER BY item_key, price
                        """
                );

        while (active.next()) {

            AuctionListing listing =
                    auctionListing(active);

            activeByItem.computeIfAbsent(
                    listing.itemKey(),
                    ignored -> new ArrayList<>()
            ).add(listing);
        }

        ResultSet turnover =
                stmt.executeQuery(
                        """
                        SELECT
                            item_key,
                            COUNT(*) AS turnover
                        FROM ah_sold_auctions sold
                        WHERE sold.sold_at >=
                            (unixepoch('now', '-3 days') * 1000)
                          AND item_key IS NOT NULL
                        GROUP BY item_key
                        """
                );

        while (turnover.next()) {

            turnoverByItem.put(
                    turnover.getString("item_key"),
                    turnover.getInt("turnover")
            );
        }

        ResultSet sold =
                stmt.executeQuery(
                        """
                        SELECT auction_uuid, item_key, sold_at, sold_price
                        FROM ah_sold_auctions
                        WHERE sold_at >=
                            (unixepoch('now', '-3 days') * 1000)
                          AND item_key IS NOT NULL
                        """
                );

        while (sold.next()) {

            soldAuctions.put(
                    sold.getString("auction_uuid"),
                    sold.getLong("sold_at")
            );

            soldPricesByItem.computeIfAbsent(
                    sold.getString("item_key"),
                    ignored -> new ArrayList<>()
            ).add(
                    sold.getDouble("sold_price")
            );
        }

    } catch (Exception e) {

        e.printStackTrace();
    }

    List<MarketStealData> steals =
            new ArrayList<>();

    for (Map.Entry<String, List<AuctionListing>> entry :
            activeByItem.entrySet()) {

        List<AuctionListing> comparables =
                entry.getValue();

        List<Double> recentSalePrices =
                soldPricesByItem.getOrDefault(
                        entry.getKey(),
                        List.of()
                );

        AuctionSaleStats saleStats =
                threeDayAuctionAverage(recentSalePrices);

        if (saleStats == null) {

            continue;
        }

        comparables.sort(
                Comparator.comparingDouble(
                        AuctionListing::price
                )
        );

        AuctionListing cheapest =
                comparables.get(0);

        if (isExcludedAuctionCosmetic(cheapest.itemName())) {

            continue;
        }

        double fairValue =
                saleStats.averagePrice();

        if (fairValue <= 0) {

            continue;
        }

        double discountPercent =
                (fairValue - cheapest.price()) /
                fairValue * 100;

        double estimatedTax =
                auctionHouseTax(fairValue);

        double resaleAfterFees =
                fairValue - estimatedTax;

        double netProfit =
                resaleAfterFees - cheapest.price();

        double salesPerHour =
                turnoverByItem.getOrDefault(
                        entry.getKey(),
                        0
                ) / (AUCTION_SALE_HISTORY_DAYS * 24.0);

        double estimatedSellHours =
                salesPerHour > 0
                        ? 1.0 / salesPerHour
                        : Math.max(
                                1,
                                24.0 / comparables.size()
                        );

        if (
                discountPercent < 10 ||
                netProfit < 5_000 ||
                estimatedSellHours > 48
        ) {

            continue;
        }

        double confidence =
                Math.min(1, saleStats.sampleSize() / 20.0) *
                (
                    salesPerHour > 0
                            ? Math.min(1, salesPerHour / 2.0)
                            : 0.35
                );

        steals.add(
                new MarketStealData(
                        cheapest.itemKey(),
                        cheapest.auctionUuid(),
                        cheapest.itemName(),
                        cheapest.price(),
                        fairValue,
                        discountPercent,
                        estimatedTax,
                        netProfit,
                        1,
                        1,
                        netProfit,
                        salesPerHour,
                        estimatedSellHours,
                        confidence,
                        cheapest.endTime(),
                        soldAuctions.containsKey(
                                cheapest.auctionUuid()
                        ),
                        soldAuctions.getOrDefault(
                                cheapest.auctionUuid(),
                                0L
                        )
                )
        );
    }

    steals.sort(
            Comparator.comparingDouble(
                    (MarketStealData steal) ->
                            steal.totalProfit() *
                            steal.confidence()
            )
                    .reversed()
    );

    return steals.stream()
            .limit(500)
            .toList();
}

private boolean isExcludedAuctionCosmetic(String itemName) {

    String normalized =
            itemName.toLowerCase(Locale.ROOT);

    return normalized.matches(
            ".*\\b(skin|skins|dye|dyes)\\b.*"
    );
}

private AuctionSaleStats threeDayAuctionAverage(List<Double> prices) {

    if (prices.size() < MINIMUM_AUCTION_SALES_FOR_AVERAGE) {

        return null;
    }

    List<Double> sortedPrices =
            prices.stream()
                    .sorted()
                    .toList();

    double lowerQuartile =
            medianOfRange(
                    sortedPrices,
                    0,
                    sortedPrices.size() / 2
            );

    double upperQuartile =
            medianOfRange(
                    sortedPrices,
                    (sortedPrices.size() + 1) / 2,
                    sortedPrices.size()
            );

    double interquartileRange =
            upperQuartile - lowerQuartile;

    double lowerBound =
            lowerQuartile - interquartileRange * 1.5;

    double upperBound =
            upperQuartile + interquartileRange * 1.5;

    List<Double> filteredPrices =
            sortedPrices.stream()
                    .filter(price ->
                            price >= lowerBound &&
                            price <= upperBound
                    )
                    .toList();

    if (
            filteredPrices.size() <
                    MINIMUM_AUCTION_SALES_FOR_AVERAGE
    ) {

        return null;
    }

    double averagePrice =
            filteredPrices.stream()
                    .mapToDouble(Double::doubleValue)
                    .average()
                    .orElse(0);

    return new AuctionSaleStats(
            averagePrice,
            filteredPrices.size()
    );
}

private double medianOfRange(
        List<Double> sortedValues,
        int fromIndex,
        int toIndex
) {

    int size =
            toIndex - fromIndex;

    if (size <= 0) {

        return 0;
    }

    int middle =
            fromIndex + size / 2;

    if (size % 2 == 1) {

        return sortedValues.get(middle);
    }

    return (
            sortedValues.get(middle - 1) +
            sortedValues.get(middle)
    ) / 2.0;
}

private double auctionHouseTax(double salePrice) {

    double listingRate;

    if (salePrice >= 100_000_000) {

        listingRate = 0.025;

    } else if (salePrice >= 10_000_000) {

        listingRate = 0.02;

    } else {

        listingRate = 0.01;
    }

    double collectionTax =
            salePrice * 0.01;

    // The official wiki lists a 350-coin duration fee for 24 hours.
    double durationFee =
            350;

    return salePrice * listingRate +
            collectionTax +
            durationFee;
}

private AuctionListing auctionListing(
        ResultSet rs
) throws Exception {

    return new AuctionListing(
            rs.getString("auction_uuid"),
            rs.getString("item_key"),
            rs.getString("item_name"),
            rs.getString("tier"),
            rs.getString("category"),
            rs.getDouble("price"),
            rs.getLong("start_time"),
            rs.getLong("end_time")
    );
}

public List<FlipData> getCraftFlips() {

    Map<String, FlipData> bestFlipByItem =
            new HashMap<>();

    Map<String, double[]> latestPrices =
            getLatestPrices();

    for (CraftingRecipe recipe : CRAFTING_RECIPES) {

        if (isPerfectGemstone(recipe.outputItemId())) {
            continue;
        }

        addCraftFlip(
                bestFlipByItem,
                latestPrices,
                recipe
        );
    }

    List<FlipData> flips =
            new ArrayList<>(bestFlipByItem.values());

    flips.sort(
            Comparator.comparingDouble(
                    FlipData::getProfitPerHour
            )
                    .thenComparingDouble(
                            FlipData::getSellsPerHour
                    )
                    .thenComparingDouble(
                            FlipData::getProfit
                    )
                    .reversed()
    );

    return flips;
}

public List<FlipData> getCraftRecipeValues() {

    Map<String, FlipData> bestRecipeByItem =
            new HashMap<>();

    Map<String, double[]> latestPrices =
            getLatestPrices();

    for (CraftingRecipe recipe : CRAFTING_RECIPES) {

        if (isPerfectGemstone(recipe.outputItemId())) {
            continue;
        }

        CraftRecipeData pricedRecipe =
                priceCraftRecipe(recipe, latestPrices);

        if (pricedRecipe == null) {

            continue;
        }

        FlipData recipeValue =
                craftFlipData(
                        recipe,
                        pricedRecipe,
                        latestPrices
                );

        bestRecipeByItem.merge(
                recipe.outputItemId(),
                recipeValue,
                (current, candidate) ->
                        candidate.getProfit() > current.getProfit()
                                ? candidate
                                : current
        );
    }

    List<FlipData> recipes =
            new ArrayList<>(bestRecipeByItem.values());

    recipes.sort(
            Comparator.comparingDouble(FlipData::getProfit)
                    .reversed()
    );

    return recipes;
}

public List<FlipData> getForgeFlips() {

    Map<String, FlipData> bestFlipByItem =
            new HashMap<>();

    Map<String, double[]> latestPrices =
            getLatestPrices();
    Map<String, AuctionPrice> auctionPrices =
            getAuctionPrices();

    for (CraftingRecipe recipe : FORGE_RECIPES) {
        addForgeFlip(
                bestFlipByItem,
                latestPrices,
                auctionPrices,
                recipe
        );
    }

    List<FlipData> flips =
            new ArrayList<>(bestFlipByItem.values());

    flips.sort(
            Comparator.comparingDouble(FlipData::getProfitPerHour)
                    .thenComparingDouble(FlipData::getSellsPerHour)
                    .thenComparingDouble(FlipData::getProfit)
                    .reversed()
    );

    return flips.stream()
            .limit(15)
            .toList();
}

public List<FlipData> getForgeRecipeValues() {

    Map<String, FlipData> bestRecipeByItem =
            new HashMap<>();

    Map<String, double[]> latestPrices =
            getLatestPrices();
    Map<String, AuctionPrice> auctionPrices =
            getAuctionPrices();

    for (CraftingRecipe recipe : FORGE_RECIPES) {

        CraftRecipeData pricedRecipe =
                priceForgeRecipe(
                        recipe,
                        latestPrices,
                        auctionPrices
                );

        if (pricedRecipe == null) {
            continue;
        }

        FlipData recipeValue =
                forgeFlipData(
                        recipe,
                        pricedRecipe,
                        latestPrices,
                        auctionPrices
                );

        bestRecipeByItem.merge(
                recipe.outputItemId(),
                recipeValue,
                (current, candidate) ->
                        candidate.getProfit() > current.getProfit()
                                ? candidate
                                : current
        );
    }

    List<FlipData> recipes =
            new ArrayList<>(bestRecipeByItem.values());

    recipes.sort(
            Comparator.comparingDouble(FlipData::getProfit)
                    .reversed()
    );

    return recipes;
}

public List<FlipData> getBazaarFlips() {

    List<FlipData> flips =
            new ArrayList<>();

    Map<String, double[]> latestPrices =
            getLatestPrices();

    for (Map.Entry<String, double[]> entry :
            latestPrices.entrySet()) {

        double buyOrderPrice =
                entry.getValue()[1];

        double sellOrderPrice =
                entry.getValue()[0];

        if (
                buyOrderPrice <= 0 ||
                sellOrderPrice <= buyOrderPrice
        ) {

            continue;
        }

        double profit =
                sellOrderPrice - buyOrderPrice;

        double sellsPerHour =
                Math.min(
                        entry.getValue()[2],
                        entry.getValue()[3]
                ) / 168.0;

        double netProfit =
                profit - sellOrderPrice * 0.0125;

        double profitPerHour =
                Math.max(0, netProfit) *
                sellsPerHour;

        if (netProfit <= 0 || sellsPerHour <= 0) {

            continue;
        }

        flips.add(
                new FlipData(
                        entry.getKey(),
                        buyOrderPrice,
                        sellOrderPrice,
                        profit,
                        profit / buyOrderPrice * 100,
                        sellsPerHour,
                        profitPerHour
                )
        );
    }

    flips.sort(
            Comparator.comparingDouble(FlipData::getProfitPerHour)
                    .reversed()
    );

    return flips;
}

public List<FusionFlipData> getFusionFlips(
        boolean multiStep
) {

    Map<String, double[]> latestPrices =
            getLatestPrices();

    Map<String, FusionRoute> bestRouteByOutput =
            new HashMap<>();

    for (FusionRecipe recipe : FUSION_RECIPES) {

        FusionRoute route =
                priceFusionRecipe(
                        recipe,
                        latestPrices,
                        null
                );

        if (route != null) {

            mergeFusionRoute(bestRouteByOutput, route);
        }
    }

    if (multiStep) {

        for (int level = 2; level <= 3; level++) {

            List<FusionRoute> previousRoutes =
                    new ArrayList<>(bestRouteByOutput.values());

            for (FusionRecipe recipe : FUSION_RECIPES) {

                for (FusionRoute inputRoute : previousRoutes) {

                    if (
                            !recipe.firstItemId()
                                    .equals(inputRoute.outputItemId()) &&
                            !recipe.secondItemId()
                                    .equals(inputRoute.outputItemId())
                    ) {

                        continue;
                    }

                    FusionRoute route =
                            priceFusionRecipe(
                                    recipe,
                                    latestPrices,
                                    inputRoute
                            );

                    if (
                            route != null &&
                            route.levels() == level
                    ) {

                        mergeFusionRoute(bestRouteByOutput, route);
                    }
                }
            }
        }
    }

    List<FusionFlipData> flips =
            bestRouteByOutput.values()
                    .stream()
                    .filter(route -> route.profit() > 0)
                    .map(FusionRoute::data)
                    .sorted(
                            Comparator.comparingDouble(
                                    FusionFlipData::profit
                            ).reversed()
                    )
                    .limit(60)
                    .toList();

    return flips;
}

private void mergeFusionRoute(
        Map<String, FusionRoute> bestRouteByOutput,
        FusionRoute route
) {

    bestRouteByOutput.merge(
            route.outputItemId(),
            route,
            (current, candidate) ->
                    candidate.profit() > current.profit()
                            ? candidate
                            : current
    );
}

private FusionRoute priceFusionRecipe(
        FusionRecipe recipe,
        Map<String, double[]> latestPrices,
        FusionRoute inputRoute
) {

    double[] firstPrices =
            latestPrices.get(recipe.firstItemId());

    double[] secondPrices =
            latestPrices.get(recipe.secondItemId());

    double[] outputPrices =
            latestPrices.get(recipe.outputItemId());

    if (
            firstPrices == null ||
            secondPrices == null ||
            outputPrices == null ||
            outputPrices[0] <= 0
    ) {

        return null;
    }

    double firstCost =
            firstPrices[1] *
            recipe.firstCount();

    double secondCost =
            secondPrices[1] *
            recipe.secondCount();

    List<FusionStepData> steps =
            new ArrayList<>();

    int levels = 1;

    if (inputRoute != null) {

        if (recipe.firstItemId().equals(inputRoute.outputItemId())) {

            firstCost =
                    inputRoute.inputCost() *
                    recipe.firstCount();

        } else {

            secondCost =
                    inputRoute.inputCost() *
                    recipe.secondCount();
        }

        steps.addAll(inputRoute.steps());
        levels =
                inputRoute.levels() + 1;
    }

    if (firstCost <= 0 || secondCost <= 0) {

        return null;
    }

    double inputCost =
            firstCost + secondCost;

    double outputValue =
            outputPrices[0] *
            recipe.outputCount();

    double profit =
            outputValue - inputCost;

    steps.add(
            new FusionStepData(
                    recipe.firstItemId(),
                    recipe.firstCount(),
                    recipe.secondItemId(),
                    recipe.secondCount(),
                    recipe.outputItemId(),
                    recipe.outputCount(),
                    firstCost + secondCost,
                    outputValue,
                    profit
            )
    );

    double dailyVolume =
            Math.min(
                    outputPrices[2],
                    outputPrices[3]
            ) / 7.0;

    FusionFlipData data =
            new FusionFlipData(
                    recipe.outputItemId(),
                    List.copyOf(steps),
                    inputCost,
                    outputValue,
                    recipe.outputCount(),
                    profit,
                    inputCost <= 0
                            ? 0
                            : profit / inputCost * 100,
                    dailyVolume,
                    levels
            );

    return new FusionRoute(
            recipe.outputItemId(),
            List.copyOf(steps),
            inputCost,
            profit,
            levels,
            data
    );
}

public List<String> getHistoricalBackfillCandidates(
        int limit
) {

    List<String> items =
            new ArrayList<>();

    try (
        Connection conn =
                DriverManager.getConnection(DB_URL);

        PreparedStatement ps =
                conn.prepareStatement(
                        """
                        SELECT
                            latest.item_id,
                            MIN(
                                latest.buy_moving_week,
                                latest.sell_moving_week
                            ) AS liquidity
                        FROM bazaar_history latest
                        INNER JOIN (
                            SELECT item_id, MAX(id) AS latest_id
                            FROM bazaar_history
                            GROUP BY item_id
                        ) newest
                            ON latest.id = newest.latest_id
                        WHERE latest.buy_price > 0
                          AND latest.sell_price > 0
                        ORDER BY liquidity DESC
                        LIMIT ?
                        """
                )
    ) {

        ps.setInt(1, limit);

        ResultSet rs =
                ps.executeQuery();

        while (rs.next()) {

            items.add(
                    rs.getString("item_id")
            );
        }

    } catch (Exception e) {

        e.printStackTrace();
    }

    return items;
}

public boolean hasHistoricalCoverage(
        String itemId,
        LocalDateTime requiredStart
) {

    try (
        Connection conn =
                DriverManager.getConnection(DB_URL);

        PreparedStatement ps =
                conn.prepareStatement(
                        """
                        SELECT MIN(timestamp) AS oldest, COUNT(*) AS samples
                        FROM bazaar_daily_history
                        WHERE item_id = ?
                        """
                )
    ) {

        ps.setString(1, itemId);

        ResultSet rs =
                ps.executeQuery();

        if (
                rs.next() &&
                rs.getInt("samples") >= 365
        ) {

            String oldest =
                    rs.getString("oldest");

            return oldest != null &&
                    !parseTimestamp(oldest)
                            .isAfter(
                                    requiredStart.plusDays(14)
                            );
        }

    } catch (Exception e) {

        e.printStackTrace();
    }

    return false;
}

public void saveHistoricalObservations(
        List<HistoricalObservation> observations
) {

    if (observations.isEmpty()) {

        return;
    }

    try (
        Connection conn =
                DriverManager.getConnection(DB_URL);

        PreparedStatement ps =
                conn.prepareStatement(
                        """
                        INSERT OR REPLACE INTO bazaar_daily_history
                        (
                            item_id,
                            buy_price,
                            sell_price,
                            buy_volume,
                            sell_volume,
                            buy_moving_week,
                            sell_moving_week,
                            timestamp,
                            source
                        )
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """
                )
    ) {

        conn.setAutoCommit(false);

        for (HistoricalObservation observation :
                observations) {

            ps.setString(1, observation.itemId());
            ps.setDouble(2, observation.buyPrice());
            ps.setDouble(3, observation.sellPrice());
            ps.setDouble(4, observation.buyVolume());
            ps.setDouble(5, observation.sellVolume());
            ps.setDouble(6, observation.buyMovingWeek());
            ps.setDouble(7, observation.sellMovingWeek());
            ps.setString(8, observation.timestamp());
            ps.setString(9, observation.source());
            ps.addBatch();
        }

        ps.executeBatch();
        conn.commit();

    } catch (Exception e) {

        e.printStackTrace();
    }
}

public List<PredictionData> getPredictions() {

    final int samplesPerItem = 288;
    final int minimumSamples = 24;
    final int horizonSamples = 12;
    final int horizonMinutes = 60;

    Map<String, List<MarketObservation>> history =
            new LinkedHashMap<>();

    try (
        Connection conn =
                DriverManager.getConnection(DB_URL);

        PreparedStatement ps =
                conn.prepareStatement(
                        """
                        SELECT
                            item_id,
                            buy_price,
                            sell_price,
                            buy_moving_week,
                            sell_moving_week
                        FROM (
                            SELECT
                                item_id,
                                buy_price,
                                sell_price,
                                buy_moving_week,
                                sell_moving_week,
                                ROW_NUMBER() OVER (
                                    PARTITION BY item_id
                                    ORDER BY id DESC
                                ) AS row_number
                            FROM bazaar_history
                            WHERE buy_price > 0
                              AND sell_price > 0
                        )
                        WHERE row_number <= ?
                        ORDER BY item_id, row_number DESC
                        """
                )
    ) {

        ps.setInt(1, samplesPerItem);

        ResultSet rs =
                ps.executeQuery();

        while (rs.next()) {

            history.computeIfAbsent(
                    rs.getString("item_id"),
                    ignored -> new ArrayList<>()
            ).add(
                    new MarketObservation(
                            rs.getDouble("buy_price"),
                            rs.getDouble("sell_price"),
                            rs.getDouble("buy_moving_week"),
                            rs.getDouble("sell_moving_week")
                    )
            );
        }

    } catch (Exception e) {

        e.printStackTrace();
    }

    List<PredictionData> predictions =
            new ArrayList<>();

    List<PredictionData> fallbackPredictions =
            new ArrayList<>();

    MayorData mayor = null;

    try {

        mayor =
                mayorService.getCurrentMayor();

    } catch (Exception ignored) {

        // Predictions remain available if Hypixel is temporarily down.
    }

    for (Map.Entry<String, List<MarketObservation>> entry :
            history.entrySet()) {

        List<MarketObservation> observations =
                entry.getValue();

        if (observations.size() < minimumSamples) {

            continue;
        }

        LongTermSignal longTerm =
                getLongTermSignal(entry.getKey());

        MayorSignal mayorSignal =
                MayorMarketAnalyzer.analyze(
                        entry.getKey(),
                        mayor
                );

        PredictionData prediction =
                predictItem(
                        entry.getKey(),
                        observations,
                        horizonSamples,
                        horizonMinutes,
                        longTerm,
                        mayorSignal
                );

        if (
                prediction != null &&
                !prediction.recommendation().equals("WATCH")
        ) {

            predictions.add(prediction);

        } else {

            PredictionData fallback =
                    fallbackPrediction(
                            entry.getKey(),
                            observations,
                            horizonMinutes,
                            longTerm,
                            mayorSignal
                    );

            if (fallback != null) {

                fallbackPredictions.add(fallback);
            }
        }
    }

    if (predictions.isEmpty()) {

        fallbackPredictions.sort(
                Comparator.comparingDouble(PredictionData::score)
                        .reversed()
        );

        fallbackPredictions.stream()
                .limit(12)
                .forEach(predictions::add);
    }

    predictions.sort(
            Comparator.comparingDouble(PredictionData::score)
                    .reversed()
    );

    List<PredictionData> investments =
            new ArrayList<>();

    predictions.stream()
            .filter(prediction ->
                    prediction.recommendation()
                            .equals("INVEST"))
            .filter(prediction ->
                    MayorMarketAnalyzer.isMiningItem(
                            prediction.itemId()
                    ))
            .filter(prediction ->
                    prediction.discountToBaselinePercent() > 0)
            .limit(2)
            .forEach(investments::add);

    predictions.stream()
            .filter(prediction ->
                    prediction.recommendation()
                            .equals("INVEST"))
            .filter(prediction ->
                    !investments.contains(prediction))
            .limit(10 - investments.size())
            .forEach(investments::add);

    List<PredictionData> flips =
            predictions.stream()
                    .filter(prediction ->
                            prediction.recommendation()
                                    .equals("FLIP"))
                    .limit(10)
                    .toList();

    List<PredictionData> balanced =
            new ArrayList<>();

    for (
        int i = 0;
        i < Math.max(investments.size(), flips.size());
        i++
    ) {

        if (i < investments.size()) {

            balanced.add(investments.get(i));
        }

        if (i < flips.size()) {

            balanced.add(flips.get(i));
        }
    }

    savePredictionSnapshots(balanced);
    evaluateMaturePredictions();
    prunePredictionHistory();

    return balanced;
}

public List<PredictionData> getMayorFlips() {

    return getPredictions().stream()
            .filter(this::hasMayorFlipSignal)
            .sorted(
                    Comparator.comparingDouble(
                            this::mayorFlipScore
                    ).reversed()
            )
            .limit(15)
            .toList();
}

private boolean hasMayorFlipSignal(PredictionData prediction) {

    String tokenReason =
            prediction.tokenReason().toLowerCase(Locale.ROOT);

    String investmentStyle =
            prediction.investmentStyle().toLowerCase(Locale.ROOT);

    return Math.abs(prediction.mayorImpactPercent()) >= 0.1 ||
           investmentStyle.contains("catalyst") ||
           tokenReason.contains("mayor/event token");
}

private double mayorFlipScore(PredictionData prediction) {

    double catalystWeight =
            Math.abs(prediction.mayorImpactPercent()) * 1.2;

    if (
            prediction.investmentStyle()
                    .toLowerCase(Locale.ROOT)
                    .contains("catalyst")
    ) {

        catalystWeight += 4;
    }

    return prediction.score() +
           catalystWeight +
           prediction.investmentTokens() * 0.5 +
           prediction.confidence() * 2;
}

public List<PredictionResultData> getPredictionHistory(
        int limit
) {

    evaluateMaturePredictions();
    prunePredictionHistory();

    List<PredictionResultData> results =
            new ArrayList<>();

    try (
        Connection conn =
                DriverManager.getConnection(DB_URL);

        PreparedStatement ps =
                conn.prepareStatement(
                        """
                        SELECT *
                        FROM prediction_history
                        WHERE evaluated_at IS NOT NULL
                        ORDER BY evaluated_at DESC
                        LIMIT ?
                        """
                )
    ) {

        ps.setInt(
                1,
                Math.max(1, Math.min(200, limit))
        );

        ResultSet rs =
                ps.executeQuery();

        while (rs.next()) {

            results.add(
                    new PredictionResultData(
                            rs.getLong("id"),
                            rs.getString("item_id"),
                            rs.getString("recommendation"),
                            rs.getDouble("start_price"),
                            rs.getDouble("predicted_price"),
                            rs.getDouble("expected_change_percent"),
                            rs.getDouble("actual_price"),
                            rs.getDouble("actual_change_percent"),
                            rs.getInt("successful") == 1,
                            rs.getInt("target_hit") == 1,
                            rs.getString("created_at"),
                            rs.getString("due_at"),
                            rs.getString("evaluated_at"),
                            rs.getInt("horizon_minutes"),
                            rs.getString("investment_style"),
                            rs.getInt("investment_tokens")
                    )
            );
        }

    } catch (Exception e) {

        e.printStackTrace();
    }

    return results;
}

private void savePredictionSnapshots(
        List<PredictionData> predictions
) {

    if (predictions.isEmpty()) {

        return;
    }

    try (
        Connection conn =
                DriverManager.getConnection(DB_URL);

        PreparedStatement ps =
                conn.prepareStatement(
                        """
                        INSERT OR IGNORE INTO prediction_history
                        (
                            item_id,
                            recommendation,
                            start_price,
                            predicted_price,
                            expected_change_percent,
                            confidence,
                            horizon_minutes,
                            investment_style,
                            investment_tokens,
                            due_at,
                            snapshot_bucket
                        )
                        VALUES (
                            ?, ?, ?, ?, ?, ?, ?, ?, ?,
                            datetime('now', '+' || ? || ' minutes'),
                            CASE
                                WHEN ? >= 1440
                                THEN date('now')
                                ELSE strftime('%Y-%m-%d %H:00:00', 'now')
                            END
                        )
                        """
                )
    ) {

        conn.setAutoCommit(false);

        for (PredictionData prediction : predictions) {

            ps.setString(1, prediction.itemId());
            ps.setString(2, prediction.recommendation());
            ps.setDouble(3, prediction.currentPrice());
            ps.setDouble(4, prediction.predictedPrice());
            ps.setDouble(
                    5,
                    prediction.expectedChangePercent()
            );
            ps.setDouble(6, prediction.confidence());
            ps.setInt(7, prediction.horizonMinutes());
            ps.setString(8, prediction.investmentStyle());
            ps.setInt(9, prediction.investmentTokens());
            ps.setInt(10, prediction.horizonMinutes());
            ps.setInt(11, prediction.horizonMinutes());
            ps.addBatch();
        }

        ps.executeBatch();
        conn.commit();

    } catch (Exception e) {

        e.printStackTrace();
    }
}

private void evaluateMaturePredictions() {

    try (
        Connection conn =
                DriverManager.getConnection(DB_URL);

        PreparedStatement pending =
                conn.prepareStatement(
                        """
                        SELECT
                            id,
                            item_id,
                            start_price,
                            predicted_price,
                            expected_change_percent,
                            due_at
                        FROM prediction_history
                        WHERE evaluated_at IS NULL
                          AND due_at <= datetime('now')
                        ORDER BY due_at
                        LIMIT 200
                        """
                );

        PreparedStatement update =
                conn.prepareStatement(
                        """
                        UPDATE prediction_history
                        SET
                            actual_price = ?,
                            actual_change_percent = ?,
                            successful = ?,
                            target_hit = ?,
                            evaluated_at = CURRENT_TIMESTAMP
                        WHERE id = ?
                        """
                )
    ) {

        ResultSet rs =
                pending.executeQuery();

        while (rs.next()) {

            Double actualPrice =
                    priceNearestTo(
                            conn,
                            rs.getString("item_id"),
                            rs.getString("due_at")
                    );

            if (actualPrice == null) {

                continue;
            }

            double startPrice =
                    rs.getDouble("start_price");

            double expectedChange =
                    rs.getDouble("expected_change_percent");

            double actualChange =
                    percentChange(
                            startPrice,
                            actualPrice
                    );

            boolean successful =
                    expectedChange >= 0
                            ? actualChange > 0
                            : actualChange < 0;

            double target =
                    rs.getDouble("predicted_price");

            boolean targetHit =
                    expectedChange >= 0
                            ? actualPrice >= target
                            : actualPrice <= target;

            update.setDouble(1, actualPrice);
            update.setDouble(2, actualChange);
            update.setInt(3, successful ? 1 : 0);
            update.setInt(4, targetHit ? 1 : 0);
            update.setLong(5, rs.getLong("id"));
            update.addBatch();
        }

        update.executeBatch();

    } catch (Exception e) {

        e.printStackTrace();
    }
}

private void prunePredictionHistory() {

    try (
        Connection conn =
                DriverManager.getConnection(DB_URL);

        Statement stmt =
                conn.createStatement()
    ) {

        stmt.executeUpdate(
                """
                DELETE FROM prediction_history
                WHERE evaluated_at IS NOT NULL
                  AND id NOT IN (
                      SELECT id
                      FROM prediction_history
                      WHERE evaluated_at IS NOT NULL
                      ORDER BY evaluated_at DESC, id DESC
                      LIMIT 100
                  )
                """
        );

        stmt.executeUpdate(
                """
                DELETE FROM prediction_history
                WHERE evaluated_at IS NOT NULL
                  AND evaluated_at < datetime('now', '-1 day')
                """
        );

        stmt.executeUpdate(
                """
                DELETE FROM prediction_history
                WHERE evaluated_at IS NULL
                  AND due_at < datetime('now', '-1 day')
                """
        );

    } catch (Exception e) {

        e.printStackTrace();
    }
}

private Double priceNearestTo(
        Connection conn,
        String itemId,
        String dueAt
) throws Exception {

    try (
        PreparedStatement ps =
                conn.prepareStatement(
                        """
                        SELECT sell_price
                        FROM (
                            SELECT timestamp, sell_price
                            FROM bazaar_history
                            WHERE item_id = ?

                            UNION ALL

                            SELECT bucket_start, sell_price
                            FROM bazaar_history_rollup
                            WHERE item_id = ?
                        )
                        WHERE timestamp BETWEEN
                            datetime(?, '-12 hours')
                            AND datetime(?, '+12 hours')
                        ORDER BY ABS(
                            julianday(timestamp) -
                            julianday(?)
                        )
                        LIMIT 1
                        """
                )
    ) {

        ps.setString(1, itemId);
        ps.setString(2, itemId);
        ps.setString(3, dueAt);
        ps.setString(4, dueAt);
        ps.setString(5, dueAt);

        ResultSet rs =
                ps.executeQuery();

        return rs.next()
                ? rs.getDouble("sell_price")
                : null;
    }
}

private PredictionData predictItem(
        String itemId,
        List<MarketObservation> observations,
        int horizonSamples,
        int horizonMinutes,
        LongTermSignal longTerm,
        MayorSignal mayorSignal
) {

    int sampleCount =
            observations.size();

    double meanX =
            (sampleCount - 1) / 2.0;

    double meanY =
            observations.stream()
                    .mapToDouble(MarketObservation::marketPrice)
                    .average()
                    .orElse(0);

    if (meanY <= 0) {

        return null;
    }

    double varianceX = 0;
    double covariance = 0;
    double totalVariance = 0;

    for (int i = 0; i < sampleCount; i++) {

        double xDifference =
                i - meanX;

        double yDifference =
                observations.get(i).marketPrice() - meanY;

        varianceX +=
                xDifference * xDifference;

        covariance +=
                xDifference * yDifference;

        totalVariance +=
                yDifference * yDifference;
    }

    if (varianceX <= 0) {

        return null;
    }

    double slope =
            covariance / varianceX;

    double intercept =
            meanY - slope * meanX;

    double residualVariance = 0;

    for (int i = 0; i < sampleCount; i++) {

        double fitted =
                intercept + slope * i;

        double residual =
                observations.get(i).marketPrice() - fitted;

        residualVariance +=
                residual * residual;
    }

    MarketObservation latest =
            observations.get(sampleCount - 1);

    double currentPrice =
            latest.marketPrice();

    if (currentPrice <= 0) {

        return null;
    }

    double predictedPrice =
            currentPrice + slope * horizonSamples;

    double volatilityPercent =
            Math.sqrt(
                    residualVariance /
                    Math.max(1, sampleCount - 2)
            ) / currentPrice * 100;

    double maximumMove =
            currentPrice *
            Math.max(0.01, volatilityPercent / 100 * 2.5);

    predictedPrice =
            Math.max(
                    currentPrice - maximumMove,
                    Math.min(
                            currentPrice + maximumMove,
                            predictedPrice
                    )
            );

    double shortTermChangePercent =
            (predictedPrice - currentPrice) /
            currentPrice * 100;

    double investmentChangePercent =
            clamp(
                    shortTermChangePercent * 0.25 +
                    longTerm.changePercent() * 0.75 +
                    mayorSignal.impactPercent(),
                    -15,
                    15
            );

    double explainedVariance =
            totalVariance <= 0
                    ? 0
                    : Math.max(
                            0,
                            1 - residualVariance /
                            totalVariance
                    );

    double sampleConfidence =
            Math.min(1, sampleCount / 144.0);

    double confidence =
            sampleConfidence *
            (0.3 + explainedVariance * 0.7) /
            (1 + volatilityPercent / 8.0);

    confidence =
            Math.max(0, Math.min(1, confidence));

    double investmentConfidence =
            Math.max(
                    0,
                    Math.min(
                            1,
                            confidence * 0.45 +
                            longTerm.confidence() * 0.45 +
                            Math.min(
                                    0.18,
                                    mayorSignal.catalystTokens() * 0.035
                            )
                    )
            );

    double hourlyVolume =
            Math.min(
                    latest.buyMovingWeek(),
                    latest.sellMovingWeek()
            ) / 168.0;

    double spreadPercent =
            (
                latest.buyPrice() -
                latest.sellPrice() -
                latest.buyPrice() * 0.0125
            ) / latest.sellPrice() * 100;

    double liquidityWeight =
            Math.log10(Math.max(10, hourlyVolume));

    int discountTokens =
            longTerm.discountPercent() < 0.75
                    ? 0
                    : Math.min(
                            4,
                            1 +
                            (int) Math.floor(
                                    longTerm.discountPercent() / 2.5
                            )
                    );

    int declineTokens =
            longTerm.decliningDays() >= 6
                    ? 3
                    : longTerm.decliningDays() >= 4
                            ? 2
                            : longTerm.decliningDays() >= 2
                                    ? 1
                                    : 0;

    int trendTokens =
            longTerm.persistentGrowth()
                    ? 3
                    : longTerm.changePercent() >= 2
                            ? 2
                    : longTerm.changePercent() >= 1
                            ? 1
                    : 0;

    int riskPenaltyTokens =
            (longTerm.priceDiscovery() ? 4 : 0) +
            (longTerm.flatMarket() ? 2 : 0) +
            (
                longTerm.discountPercent() <= -4 &&
                mayorSignal.catalystTokens() == 0
                        ? 2
                        : 0
            );

    int investmentTokens =
            Math.max(
                    0,
                    Math.min(
                            10,
                    discountTokens +
                    declineTokens +
                    trendTokens +
                    mayorSignal.catalystTokens() -
                    riskPenaltyTokens
                    )
            );

    boolean accumulationOpportunity =
            investmentTokens >= 4 &&
            (
                mayorSignal.catalystTokens() > 0 ||
                longTerm.changePercent() >= 1
            );

    if (accumulationOpportunity) {

        investmentChangePercent =
                Math.max(
                        investmentChangePercent,
                        Math.min(
                                8,
                                investmentTokens * 0.6
                        )
                );
    }

    double downsideRiskPercent =
            Math.max(
                    1,
                    volatilityPercent * 1.5 +
                    Math.min(
                            25,
                            Math.max(0, spreadPercent)
                    ) * 0.15 +
                    (longTerm.priceDiscovery() ? 4 : 0)
            );

    double riskRewardRatio =
            Math.max(0, investmentChangePercent) /
            downsideRiskPercent;

    boolean strongMayorCatalyst =
            mayorSignal.catalystTokens() >= 4;

    String investmentStyle =
            investmentStyle(
                    longTerm,
                    mayorSignal
            );

    String recommendation;
    double score;

    boolean discountedRebound =
            longTerm.discountPercent() >= 1.5 &&
            longTerm.changePercent() >= 0.8;

    boolean miningDipOpportunity =
            MayorMarketAnalyzer.isMiningItem(itemId) &&
            longTerm.discountPercent() >= 1.25 &&
            (
                longTerm.changePercent() >= 0.8 ||
                strongMayorCatalyst
            );

    boolean highQualityInvestment =
            investmentTokens >= (strongMayorCatalyst ? 4 : 5) &&
            investmentConfidence >= (strongMayorCatalyst ? 0.12 : 0.2) &&
            longTerm.samples() >= (strongMayorCatalyst ? 0 : 30) &&
            hourlyVolume >= (strongMayorCatalyst ? 8 : 12) &&
            volatilityPercent <= (strongMayorCatalyst ? 14 : 10) &&
            spreadPercent <= (strongMayorCatalyst ? 25 : 18) &&
            riskRewardRatio >= (strongMayorCatalyst ? 0.45 : 0.85) &&
            !longTerm.priceDiscovery();

    boolean highQualityFlip =
            spreadPercent >= 0.35 &&
            spreadPercent <= 20 &&
            hourlyVolume >= 20 &&
            confidence >= 0.08 &&
            volatilityPercent <= 10 &&
            sampleCount >= 36;

    if (
            (
                investmentChangePercent >= 1.0 ||
                discountedRebound ||
                miningDipOpportunity ||
                accumulationOpportunity
            ) &&
            highQualityInvestment
    ) {

        recommendation = "INVEST";
        score =
                Math.max(
                        0.5,
                        investmentChangePercent +
                        longTerm.discountPercent() * 0.35 +
                investmentTokens * 0.3 +
                mayorSignal.catalystTokens() * 0.25
                ) *
                investmentConfidence *
                liquidityWeight /
                (1 + volatilityPercent);

    } else if (
            highQualityFlip
    ) {

        recommendation = "FLIP";
        score =
                spreadPercent *
                Math.max(0.2, confidence) *
                liquidityWeight /
                (1 + volatilityPercent);

    } else {

        recommendation = "WATCH";
        score = 0;
    }

    double expectedChangePercent =
            recommendation.equals("INVEST")
                    ? investmentChangePercent
                    : shortTermChangePercent;

    if (recommendation.equals("INVEST")) {

        confidence =
                calibratedPredictionConfidence(
                        investmentConfidence,
                        investmentTokens,
                        riskRewardRatio,
                        volatilityPercent,
                        strongMayorCatalyst
                );

        predictedPrice =
                currentPrice *
                (1 + expectedChangePercent / 100);

        horizonMinutes =
                7 * 24 * 60;
    } else if (recommendation.equals("FLIP")) {

        predictedPrice =
                currentPrice *
                (1 + expectedChangePercent / 100);

        confidence =
                calibratedPredictionConfidence(
                        confidence,
                        0,
                        spreadPercent / Math.max(1, volatilityPercent),
                        volatilityPercent,
                        false
                );
    }

    return new PredictionData(
            itemId,
            recommendation,
            currentPrice,
            predictedPrice,
            expectedChangePercent,
            confidence,
            volatilityPercent,
            hourlyVolume,
            spreadPercent,
            score,
            horizonMinutes,
            sampleCount,
            longTerm.changePercent(),
            longTerm.samples(),
            mayorSignal.mayor(),
            mayorSignal.impactPercent(),
            mayorSignal.reason(),
            longTerm.discountPercent(),
            investmentReason(
                    itemId,
                    longTerm,
                    shortTermChangePercent
            ),
            investmentTokens,
            tokenReason(
                    longTerm,
                    mayorSignal,
                    discountTokens,
                    declineTokens,
                    trendTokens,
                    riskPenaltyTokens
            ),
            riskRewardRatio,
            investmentStyle,
            investmentRating(
                    investmentTokens,
                    riskRewardRatio,
                    investmentConfidence
            )
    );
}

private PredictionData fallbackPrediction(
        String itemId,
        List<MarketObservation> observations,
        int horizonMinutes,
        LongTermSignal longTerm,
        MayorSignal mayorSignal
) {

    if (observations.size() < 12) {

        return null;
    }

    MarketObservation latest =
            observations.get(observations.size() - 1);

    double currentPrice =
            latest.marketPrice();

    if (currentPrice <= 0) {

        return null;
    }

    double hourlyVolume =
            Math.min(
                    latest.buyMovingWeek(),
                    latest.sellMovingWeek()
            ) / 168.0;

    double spreadPercent =
            (
                latest.buyPrice() -
                latest.sellPrice() -
                latest.buyPrice() * 0.0125
            ) / latest.sellPrice() * 100;

    double volatilityPercent =
            recentVolatilityPercent(
                    observations,
                    currentPrice
            );

    int catalystTokens =
            mayorSignal.catalystTokens();

    int discountTokens =
            longTerm.discountPercent() >= 1
                    ? Math.min(
                            3,
                            1 +
                            (int) Math.floor(
                                    longTerm.discountPercent() / 3.0
                            )
                    )
                    : 0;

    int investmentTokens =
            Math.max(
                    0,
                    Math.min(
                            10,
                            catalystTokens + discountTokens
                    )
            );

    if (
            spreadPercent >= 0.2 &&
            spreadPercent <= 28 &&
            hourlyVolume >= 8 &&
            volatilityPercent <= 18
    ) {

        double expectedChangePercent =
                Math.min(3.5, spreadPercent * 0.55);

        double confidence =
                calibratedPredictionConfidence(
                        0.12,
                        0,
                        spreadPercent / Math.max(1, volatilityPercent),
                        volatilityPercent,
                        false
                );

        return new PredictionData(
                itemId,
                "FLIP",
                currentPrice,
                currentPrice * (1 + expectedChangePercent / 100),
                expectedChangePercent,
                confidence,
                volatilityPercent,
                hourlyVolume,
                spreadPercent,
                expectedChangePercent *
                        Math.log10(Math.max(10, hourlyVolume)) /
                        (1 + volatilityPercent),
                horizonMinutes,
                observations.size(),
                longTerm.changePercent(),
                longTerm.samples(),
                mayorSignal.mayor(),
                mayorSignal.impactPercent(),
                mayorSignal.reason(),
                longTerm.discountPercent(),
                "Fallback flip signal: enough live spread and liquidity, but not enough clean trend evidence for the strict model",
                investmentTokens,
                tokenReason(
                        longTerm,
                        mayorSignal,
                        discountTokens,
                        0,
                        0,
                        0
                ),
                Math.max(0.1, expectedChangePercent /
                        Math.max(1, volatilityPercent)),
                "SPREAD",
                "CAUTIOUS"
        );
    }

    if (
            investmentTokens >= 3 &&
            hourlyVolume >= 5 &&
            volatilityPercent <= 22
    ) {

        double expectedChangePercent =
                clamp(
                        Math.max(
                                0.8,
                                mayorSignal.impactPercent() +
                                longTerm.discountPercent() * 0.25 +
                                investmentTokens * 0.35
                        ),
                        0.8,
                        7
                );

        double riskRewardRatio =
                expectedChangePercent /
                Math.max(1, volatilityPercent * 1.25);

        double confidence =
                calibratedPredictionConfidence(
                        0.1,
                        investmentTokens,
                        riskRewardRatio,
                        volatilityPercent,
                        catalystTokens >= 4
                );

        return new PredictionData(
                itemId,
                "INVEST",
                currentPrice,
                currentPrice * (1 + expectedChangePercent / 100),
                expectedChangePercent,
                confidence,
                volatilityPercent,
                hourlyVolume,
                spreadPercent,
                expectedChangePercent *
                        Math.max(1, investmentTokens) *
                        Math.log10(Math.max(10, hourlyVolume)) /
                        (1 + volatilityPercent),
                7 * 24 * 60,
                observations.size(),
                longTerm.changePercent(),
                longTerm.samples(),
                mayorSignal.mayor(),
                mayorSignal.impactPercent(),
                mayorSignal.reason(),
                longTerm.discountPercent(),
                "Fallback catalyst signal: mayor or event tokens are present, but long-range history is still thin",
                investmentTokens,
                tokenReason(
                        longTerm,
                        mayorSignal,
                        discountTokens,
                        0,
                        0,
                        0
                ),
                riskRewardRatio,
                investmentStyle(
                        longTerm,
                        mayorSignal
                ),
                "CAUTIOUS"
        );
    }

    return null;
}

private double recentVolatilityPercent(
        List<MarketObservation> observations,
        double currentPrice
) {

    int start =
            Math.max(0, observations.size() - 36);

    double min =
            Double.MAX_VALUE;

    double max =
            0;

    for (int i = start; i < observations.size(); i++) {

        double price =
                observations.get(i).marketPrice();

        if (price <= 0) {

            continue;
        }

        min =
                Math.min(min, price);

        max =
                Math.max(max, price);
    }

    if (min == Double.MAX_VALUE || currentPrice <= 0) {

        return 0;
    }

    return (max - min) / currentPrice * 100;
}

private double calibratedPredictionConfidence(
        double modelConfidence,
        int investmentTokens,
        double riskRewardRatio,
        double volatilityPercent,
        boolean strongMayorCatalyst
) {

    double evidence =
            modelConfidence * 0.55 +
            Math.min(1, investmentTokens / 8.0) * 0.2 +
            Math.min(1, riskRewardRatio / 2.5) * 0.15 +
            (strongMayorCatalyst ? 0.1 : 0);

    double riskPenalty =
            Math.min(0.18, volatilityPercent / 100.0);

    return clamp(
            TARGET_PREDICTION_SUCCESS_RATE +
            evidence * 0.22 -
            riskPenalty,
            TARGET_PREDICTION_SUCCESS_RATE,
            0.94
    );
}

private String investmentStyle(
        LongTermSignal longTerm,
        MayorSignal mayorSignal
) {

    if (
            mayorSignal.catalystTokens() > 0 &&
            longTerm.discountPercent() > 0
    ) {

        return "CATALYST VALUE";
    }

    if (mayorSignal.catalystTokens() > 0) {

        return "CATALYST";
    }

    if (
            longTerm.persistentGrowth() &&
            longTerm.discountPercent() >= -3
    ) {

        return "MOMENTUM";
    }

    if (longTerm.discountPercent() > 0) {

        return "VALUE";
    }

    return longTerm.priceDiscovery()
            ? "SPECULATIVE"
            : "TREND";
}

private String investmentRating(
        int tokens,
        double riskRewardRatio,
        double confidence
) {

    if (
            tokens >= 7 &&
            riskRewardRatio >= 2 &&
            confidence >= 0.35
    ) {

        return "STRONG ACCUMULATE";
    }

    if (
            tokens >= 4 &&
            riskRewardRatio >= 1
    ) {

        return "ACCUMULATE";
    }

    return "CAUTIOUS";
}

private String tokenReason(
        LongTermSignal longTerm,
        MayorSignal mayorSignal,
        int discountTokens,
        int declineTokens,
        int trendTokens,
        int riskPenaltyTokens
) {

    List<String> reasons =
            new ArrayList<>();

    if (discountTokens > 0) {

        reasons.add(
                discountTokens +
                " price-discount token" +
                (discountTokens == 1 ? "" : "s")
        );
    }

    if (declineTokens > 0) {

        reasons.add(
                declineTokens +
                " falling-trend token" +
                (declineTokens == 1 ? "" : "s") +
                " (" +
                longTerm.decliningDays() +
                " declining days)"
        );
    }

    if (mayorSignal.catalystTokens() > 0) {

        reasons.add(
                mayorSignal.catalystTokens() +
                " mayor/event token" +
                (mayorSignal.catalystTokens() == 1 ? "" : "s")
        );
    }

    if (trendTokens > 0) {

        reasons.add(
                trendTokens +
                (
                    longTerm.persistentGrowth()
                            ? " persistent-growth tokens"
                            : " historical-rebound token"
                )
        );
    }

    if (longTerm.priceDiscovery()) {

        reasons.add(
                "-4 new-item price-discovery tokens (" +
                longTerm.ageDays() +
                " days of history, " +
                String.format(
                        java.util.Locale.ROOT,
                        "%.0f%% below its early peak",
                        longTerm.peakDrawdownPercent()
                ) +
                ")"
        );
    }

    if (longTerm.flatMarket()) {

        reasons.add(
                "-2 stale-market tokens; the price has stayed nearly flat"
        );
    }

    if (
            riskPenaltyTokens > 0 &&
            discountTokens + declineTokens +
            trendTokens + mayorSignal.catalystTokens() <=
            riskPenaltyTokens
    ) {

        reasons.add(
                "Risk penalties cancel the apparent buy-low opportunity"
        );
    }

    if (!mayorSignal.catalystReason().isBlank()) {

        reasons.add(mayorSignal.catalystReason());
    }

    return reasons.isEmpty()
            ? "No accumulation tokens"
            : String.join("; ", reasons);
}

private String investmentReason(
        String itemId,
        LongTermSignal longTerm,
        double shortTermChangePercent
) {

    if (
            MayorMarketAnalyzer.isMiningItem(itemId) &&
            longTerm.discountPercent() > 0
    ) {

        return String.format(
                java.util.Locale.ROOT,
                "%.1f%% below its 30-day baseline; mining supply dips can create a seven-day rebound entry",
                longTerm.discountPercent()
        );
    }

    if (longTerm.discountPercent() > 0) {

        return String.format(
                java.util.Locale.ROOT,
                "%.1f%% below its 30-day baseline with a positive seven-day recovery estimate",
                longTerm.discountPercent()
        );
    }

    if (shortTermChangePercent < 0) {

        return "Short-term price is soft, but long-range history favors recovery over seven days";
    }

    return "Short- and long-range trends both favor a seven-day increase";
}

private LongTermSignal getLongTermSignal(String itemId) {

    List<DailyPrice> prices =
            new ArrayList<>();

    try (
        Connection conn =
                DriverManager.getConnection(DB_URL);

        PreparedStatement ps =
                conn.prepareStatement(
                        """
                        SELECT
                            MIN(timestamp) AS timestamp,
                            AVG(sell_price) AS sell_price
                        FROM bazaar_daily_history
                        WHERE item_id = ?
                          AND sell_price > 0
                          AND timestamp >= datetime('now', '-4 years')
                        GROUP BY date(timestamp)
                        ORDER BY timestamp
                        """
                )
    ) {

        ps.setString(1, itemId);

        ResultSet rs =
                ps.executeQuery();

        while (rs.next()) {

            prices.add(
                    new DailyPrice(
                            parseTimestamp(
                                    rs.getString("timestamp")
                            ),
                            rs.getDouble("sell_price")
                    )
            );
        }

    } catch (Exception e) {

        e.printStackTrace();
    }

    if (prices.size() < 30) {

        return LongTermSignal.NONE;
    }

    DailyPrice latest =
            prices.get(prices.size() - 1);

    DailyPrice weekAgo =
            nearestAtOrBefore(
                    prices,
                    latest.timestamp().minusDays(7)
            );

    double sevenDayMomentum =
            percentChange(
                    weekAgo.price(),
                    latest.price()
            );

    DailyPrice monthAgo =
            nearestAtOrBefore(
                    prices,
                    latest.timestamp().minusDays(30)
            );

    double thirtyDayMomentum =
            percentChange(
                    monthAgo.price(),
                    latest.price()
            );

    List<Double> recentPrices =
            prices.stream()
                    .filter(price ->
                            !price.timestamp().isBefore(
                                    latest.timestamp().minusDays(30)
                            )
                    )
                    .map(DailyPrice::price)
                    .sorted()
                    .toList();

    double baseline =
            median(recentPrices);

    double discountPercent =
            baseline <= 0
                    ? 0
                    : (baseline - latest.price()) /
                    baseline * 100;

    int decliningDays =
            consecutiveDecliningDays(prices, 7);

    long ageDays =
            Math.max(
                    0,
                    java.time.Duration.between(
                            prices.get(0).timestamp(),
                            latest.timestamp()
                    ).toDays()
            );

    double earlyPeak =
            prices.stream()
                    .filter(price ->
                            !price.timestamp().isAfter(
                                    prices.get(0).timestamp()
                                            .plusDays(30)
                            )
                    )
                    .mapToDouble(DailyPrice::price)
                    .max()
                    .orElse(latest.price());

    double peakDrawdownPercent =
            earlyPeak <= 0
                    ? 0
                    : Math.max(
                            0,
                            (earlyPeak - latest.price()) /
                            earlyPeak * 100
                    );

    boolean priceDiscovery =
            ageDays < 120 &&
            peakDrawdownPercent >= 25 &&
            thirtyDayMomentum < 0;

    List<Double> recentTwoWeeks =
            prices.stream()
                    .filter(price ->
                            !price.timestamp().isBefore(
                                    latest.timestamp().minusDays(14)
                            )
                    )
                    .map(DailyPrice::price)
                    .toList();

    double recentMinimum =
            recentTwoWeeks.stream()
                    .mapToDouble(Double::doubleValue)
                    .min()
                    .orElse(latest.price());

    double recentMaximum =
            recentTwoWeeks.stream()
                    .mapToDouble(Double::doubleValue)
                    .max()
                    .orElse(latest.price());

    double recentRangePercent =
            recentMinimum <= 0
                    ? 0
                    : (recentMaximum - recentMinimum) /
                    recentMinimum * 100;

    boolean flatMarket =
            recentTwoWeeks.size() >= 10 &&
            recentRangePercent < 1.5 &&
            Math.abs(sevenDayMomentum) < 0.5;

    boolean persistentGrowth =
            sevenDayMomentum >= 1 &&
            thirtyDayMomentum >= 2 &&
            !flatMarket;

    List<Double> seasonalReturns =
            new ArrayList<>();

    for (int year = 1; year <= 3; year++) {

        LocalDateTime start =
                latest.timestamp()
                        .minusYears(year);

        DailyPrice oldStart =
                nearest(prices, start, 7);

        DailyPrice oldEnd =
                nearest(
                        prices,
                        start.plusDays(7),
                        7
                );

        if (oldStart != null && oldEnd != null) {

            seasonalReturns.add(
                    percentChange(
                            oldStart.price(),
                            oldEnd.price()
                    )
            );
        }
    }

    double seasonal =
            seasonalReturns.stream()
                    .mapToDouble(Double::doubleValue)
                    .average()
                    .orElse(sevenDayMomentum);

    double change =
            clamp(
                    sevenDayMomentum * 0.25 +
                    seasonal * 0.25 +
                    Math.max(0, discountPercent) * 0.5,
                    -25,
                    25
            );

    if (priceDiscovery) {

        change =
                Math.min(change, 0);
    }

    if (flatMarket) {

        change *=
                0.25;
    }

    double confidence =
            Math.min(1, prices.size() / (365.0 * 2));

    if (!seasonalReturns.isEmpty()) {

        double disagreement =
                seasonalReturns.stream()
                        .mapToDouble(value ->
                                Math.abs(value - seasonal)
                        )
                        .average()
                        .orElse(0);

        confidence /=
                1 + disagreement / 15.0;
    }

    if (priceDiscovery) {

        confidence *=
                0.35;
    }

    if (flatMarket) {

        confidence *=
                0.6;
    }

    return new LongTermSignal(
            change,
            Math.max(0, Math.min(1, confidence)),
            prices.size(),
            discountPercent,
            decliningDays,
            (int) Math.min(Integer.MAX_VALUE, ageDays),
            peakDrawdownPercent,
            priceDiscovery,
            flatMarket,
            persistentGrowth
    );
}

private int consecutiveDecliningDays(
        List<DailyPrice> prices,
        int maximumDays
) {

    int declines = 0;

    for (
        int i = prices.size() - 1;
        i > 0 && declines < maximumDays;
        i--
    ) {

        if (
                prices.get(i).price() <
                prices.get(i - 1).price()
        ) {

            declines++;

        } else {

            break;
        }
    }

    return declines;
}

private double median(List<Double> values) {

    if (values.isEmpty()) {

        return 0;
    }

    int middle =
            values.size() / 2;

    if (values.size() % 2 == 1) {

        return values.get(middle);
    }

    return (
            values.get(middle - 1) +
            values.get(middle)
    ) / 2.0;
}

private LocalDateTime parseTimestamp(String value) {

    return LocalDateTime.parse(
            value,
            DateTimeFormatter.ISO_LOCAL_DATE_TIME
    );
}

private DailyPrice nearestAtOrBefore(
        List<DailyPrice> prices,
        LocalDateTime target
) {

    DailyPrice result =
            prices.get(0);

    for (DailyPrice price : prices) {

        if (price.timestamp().isAfter(target)) {

            break;
        }

        result = price;
    }

    return result;
}

private DailyPrice nearest(
        List<DailyPrice> prices,
        LocalDateTime target,
        int toleranceDays
) {

    DailyPrice nearest = null;
    long nearestSeconds =
            Long.MAX_VALUE;

    for (DailyPrice price : prices) {

        long seconds =
                Math.abs(
                        java.time.Duration.between(
                                target,
                                price.timestamp()
                        ).toSeconds()
                );

        if (seconds < nearestSeconds) {

            nearest = price;
            nearestSeconds = seconds;
        }
    }

    return nearestSeconds <= toleranceDays * 86400L
            ? nearest
            : null;
}

private double percentChange(
        double oldPrice,
        double newPrice
) {

    return oldPrice <= 0
            ? 0
            : (newPrice - oldPrice) / oldPrice * 100;
}

private double clamp(
        double value,
        double minimum,
        double maximum
) {

    return Math.max(
            minimum,
            Math.min(maximum, value)
    );
}

public CraftRecipeData getCraftRecipe(String itemId) {

    Map<String, double[]> latestPrices =
            getLatestPrices();

    CraftRecipeData bestRecipe = null;

    for (CraftingRecipe recipe : CRAFTING_RECIPES) {

        if (!recipe.outputItemId().equals(itemId)) {

            continue;
        }

        CraftRecipeData pricedRecipe =
                priceCraftRecipe(recipe, latestPrices);

        if (
                pricedRecipe != null &&
                (
                    bestRecipe == null ||
                    pricedRecipe.profit() > bestRecipe.profit()
                )
        ) {

            bestRecipe = pricedRecipe;
        }
    }

    return bestRecipe;
}

private Map<String, double[]> getLatestPrices() {

    Map<String, double[]> prices =
            new HashMap<>();

    try (
        Connection conn =
                DriverManager.getConnection(DB_URL);

        PreparedStatement ps =
                conn.prepareStatement(
                        """
                        SELECT
                            latest.item_id,
                            latest.buy_price,
                            latest.sell_price,
                            latest.buy_moving_week,
                            latest.sell_moving_week,
                            latest.buy_volume
                        FROM bazaar_history latest
                        INNER JOIN (
                            SELECT item_id, MAX(id) AS latest_id
                            FROM bazaar_history
                            GROUP BY item_id
                        ) newest
                            ON latest.id = newest.latest_id
                        """
                )
    ) {

        ResultSet rs =
                ps.executeQuery();

        while (rs.next()) {

            prices.put(
                    rs.getString("item_id"),
                    new double[] {
                            rs.getDouble("buy_price"),
                            rs.getDouble("sell_price"),
                            rs.getDouble("buy_moving_week"),
                            rs.getDouble("sell_moving_week"),
                            rs.getDouble("buy_volume")
                    }
            );
        }

    } catch (Exception e) {

        e.printStackTrace();
    }

    return prices;
}

private Map<String, AuctionPrice> getAuctionPrices() {

    Map<String, Double> lowestListings =
            new HashMap<>();
    Map<String, List<Double>> soldPrices =
            new HashMap<>();

    try (
        Connection conn =
                DriverManager.getConnection(DB_URL);
        Statement stmt =
                conn.createStatement()
    ) {

        ResultSet active =
                stmt.executeQuery(
                        """
                        SELECT item_name, MIN(price) AS lowest_price
                        FROM ah_listings
                        WHERE active = 1
                          AND end_time > unixepoch('now') * 1000
                        GROUP BY LOWER(item_name)
                        """
                );

        while (active.next()) {
            lowestListings.put(
                    active.getString("item_name")
                            .toLowerCase(Locale.ROOT),
                    active.getDouble("lowest_price")
            );
        }

        ResultSet sold =
                stmt.executeQuery(
                        """
                        SELECT item_name, sold_price
                        FROM ah_sold_auctions
                        WHERE sold_at >=
                            (unixepoch('now', '-3 days') * 1000)
                          AND item_name IS NOT NULL
                        """
                );

        while (sold.next()) {
            soldPrices.computeIfAbsent(
                    sold.getString("item_name")
                            .toLowerCase(Locale.ROOT),
                    ignored -> new ArrayList<>()
            ).add(sold.getDouble("sold_price"));
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    Map<String, AuctionPrice> prices =
            new HashMap<>();

    for (Map.Entry<String, List<Double>> entry :
            soldPrices.entrySet()) {

        AuctionSaleStats stats =
                threeDayAuctionAverage(entry.getValue());
        Double lowest =
                lowestListings.get(entry.getKey());

        if (stats == null || lowest == null || lowest <= 0) {
            continue;
        }

        prices.put(
                entry.getKey(),
                new AuctionPrice(
                        lowest,
                        stats.averagePrice(),
                        entry.getValue().size() /
                                (AUCTION_SALE_HISTORY_DAYS * 24.0)
                )
        );
    }

    return prices;
}

private static String auctionName(String itemId) {

    return switch (itemId) {
        case "DRILL_ENGINE" -> "drill motor";
        case "FUEL_TANK" -> "fuel canister";
        case "MITHRIL_DRILL_1" -> "mithril drill sx-r226";
        case "MITHRIL_DRILL_2" -> "mithril drill sx-r326";
        case "GEMSTONE_DRILL_1" -> "ruby drill tx-15";
        case "GEMSTONE_DRILL_2" -> "gemstone drill lt-522";
        default ->
                java.util.Arrays.stream(itemId.split("_"))
                        .map(word ->
                                word.substring(0, 1) +
                                word.substring(1).toLowerCase(Locale.ROOT)
                        )
                        .collect(
                                java.util.stream.Collectors.joining(" ")
                        )
                        .toLowerCase(Locale.ROOT);
    };
}

private void addCraftFlip(
        Map<String, FlipData> bestFlipByItem,
        Map<String, double[]> latestPrices,
        CraftingRecipe recipe
) {

    CraftRecipeData pricedRecipe =
            priceCraftRecipe(recipe, latestPrices);

    if (
            pricedRecipe == null ||
            pricedRecipe.profit() < MINIMUM_CRAFT_FLIP_PROFIT
    ) {

        return;
    }

    FlipData flip =
            craftFlipData(
                    recipe,
                    pricedRecipe,
                    latestPrices
            );

    bestFlipByItem.merge(
            recipe.outputItemId(),
            flip,
            (current, candidate) ->
                    candidate.getProfit() > current.getProfit()
                            ? candidate
                            : current
    );
}

private void addForgeFlip(
        Map<String, FlipData> bestFlipByItem,
        Map<String, double[]> latestPrices,
        Map<String, AuctionPrice> auctionPrices,
        CraftingRecipe recipe
) {

    CraftRecipeData pricedRecipe =
            priceForgeRecipe(
                    recipe,
                    latestPrices,
                    auctionPrices
            );

    if (
            pricedRecipe == null ||
            pricedRecipe.profit() < MINIMUM_CRAFT_FLIP_PROFIT
    ) {
        return;
    }

    FlipData flip =
            forgeFlipData(
                    recipe,
                    pricedRecipe,
                    latestPrices,
                    auctionPrices
            );

    bestFlipByItem.merge(
            recipe.outputItemId(),
            flip,
            (current, candidate) ->
                    candidate.getProfit() > current.getProfit()
                            ? candidate
                            : current
    );
}

private FlipData forgeFlipData(
        CraftingRecipe recipe,
        CraftRecipeData pricedRecipe,
        Map<String, double[]> latestPrices,
        Map<String, AuctionPrice> auctionPrices
) {

    double[] bazaarOutput =
            latestPrices.get(recipe.outputItemId());

    double sellsPerHour;
    double buyVolume;

    if (bazaarOutput != null) {
        sellsPerHour =
                Math.min(bazaarOutput[2], bazaarOutput[3]) /
                        168.0 / recipe.outputCount();
        buyVolume = bazaarOutput[4];
    } else {
        AuctionPrice auctionOutput =
                auctionPrices.get(
                        auctionName(recipe.outputItemId())
                );
        sellsPerHour =
                auctionOutput == null
                        ? 0
                        : auctionOutput.salesPerHour();
        buyVolume = 0;
    }

    return new FlipData(
            recipe.outputItemId(),
            pricedRecipe.craftCost(),
            pricedRecipe.sellPrice(),
            pricedRecipe.profit(),
            pricedRecipe.profit() /
                    pricedRecipe.craftCost() * 100,
            sellsPerHour,
            Math.max(0, pricedRecipe.profit()) * sellsPerHour,
            buyVolume
    );
}

private FlipData craftFlipData(
        CraftingRecipe recipe,
        CraftRecipeData pricedRecipe,
        Map<String, double[]> latestPrices
) {

    double[] outputPrices =
            latestPrices.get(recipe.outputItemId());

    double buyVolume =
            outputPrices == null
                    ? 0
                    : outputPrices[4];

    double sellsPerHour =
            outputPrices == null
                    ? 0
                    : Math.min(
                            outputPrices[2],
                            outputPrices[3]
                    ) / 168.0 / recipe.outputCount();

    double profitPerHour =
            Math.max(0, pricedRecipe.profit()) *
            sellsPerHour;

    return new FlipData(
            recipe.outputItemId(),
            pricedRecipe.craftCost(),
            pricedRecipe.sellPrice(),
            pricedRecipe.profit(),
            pricedRecipe.profit() /
                    pricedRecipe.craftCost() * 100,
            sellsPerHour,
            profitPerHour,
            buyVolume
    );
}

private CraftRecipeData priceForgeRecipe(
        CraftingRecipe recipe,
        Map<String, double[]> latestPrices,
        Map<String, AuctionPrice> auctionPrices
) {

    double[] bazaarOutput =
            latestPrices.get(recipe.outputItemId());

    double sellPrice;

    if (bazaarOutput != null && bazaarOutput[0] > 0) {
        sellPrice =
                bazaarOutput[0] * recipe.outputCount();
    } else {
        AuctionPrice output =
                auctionPrices.get(
                        auctionName(recipe.outputItemId())
                );

        if (output == null || output.sellPrice() <= 0) {
            return null;
        }

        sellPrice =
                (
                    output.sellPrice() -
                    auctionHouseTax(output.sellPrice())
                ) * recipe.outputCount();
    }

    List<CraftIngredientData> ingredients =
            new ArrayList<>();
    double craftCost = 0;

    List<Map.Entry<String, Integer>> recipeIngredients =
            new ArrayList<>(recipe.ingredients().entrySet());
    recipeIngredients.sort(Map.Entry.comparingByKey());

    for (Map.Entry<String, Integer> ingredient :
            recipeIngredients) {

        double unitPrice =
                ingredientUnitPrice(
                        ingredient.getKey(),
                        latestPrices.get(ingredient.getKey()),
                        latestPrices
                );

        if (unitPrice <= 0) {
            AuctionPrice auctionIngredient =
                    auctionPrices.get(
                            auctionName(ingredient.getKey())
                    );
            unitPrice =
                    auctionIngredient == null
                            ? 0
                            : auctionIngredient.buyPrice();
        }

        if (unitPrice <= 0) {
            return null;
        }

        double totalPrice =
                unitPrice * ingredient.getValue();
        craftCost += totalPrice;
        ingredients.add(
                new CraftIngredientData(
                        ingredient.getKey(),
                        ingredient.getValue(),
                        unitPrice,
                        totalPrice
                )
        );
    }

    if (craftCost <= 0 || sellPrice <= 0) {
        return null;
    }

    return new CraftRecipeData(
            recipe.outputItemId(),
            recipe.outputCount(),
            ingredients,
            craftCost,
            sellPrice,
            sellPrice - craftCost
    );
}

private CraftRecipeData priceCraftRecipe(
        CraftingRecipe recipe,
        Map<String, double[]> latestPrices
) {

    double[] outputPrices =
            latestPrices.get(recipe.outputItemId());

    if (outputPrices == null) {

        return null;
    }

    List<CraftIngredientData> ingredients =
            new ArrayList<>();

    double craftCost = 0;

    List<Map.Entry<String, Integer>> recipeIngredients =
            new ArrayList<>(recipe.ingredients().entrySet());

    recipeIngredients.sort(Map.Entry.comparingByKey());

    for (Map.Entry<String, Integer> ingredient :
            recipeIngredients) {

        double[] ingredientPrices =
                latestPrices.get(ingredient.getKey());

        double unitPrice =
                ingredientUnitPrice(
                        ingredient.getKey(),
                        ingredientPrices,
                        latestPrices
                );

        if (unitPrice <= 0) {

            return null;
        }

        double totalPrice =
                unitPrice * ingredient.getValue();

        craftCost += totalPrice;

        ingredients.add(
                new CraftIngredientData(
                        ingredient.getKey(),
                        ingredient.getValue(),
                        unitPrice,
                        totalPrice
                )
        );
    }

    double sellPrice =
            outputPrices[0] *
            recipe.outputCount();

    if (craftCost <= 0 || sellPrice <= 0) {

        return null;
    }

    return new CraftRecipeData(
            recipe.outputItemId(),
            recipe.outputCount(),
            ingredients,
            craftCost,
            sellPrice,
            sellPrice - craftCost
    );
}

private double ingredientUnitPrice(
        String itemId,
        double[] directPrices,
        Map<String, double[]> latestPrices
) {

    if (directPrices != null && directPrices[1] > 0) {

        return directPrices[1];
    }

    if (itemId.equals("PAPER")) {

        double[] sugarCane =
                latestPrices.get("SUGAR_CANE");

        if (sugarCane != null) {

            // Three Sugar Cane craft into three Paper.
            return sugarCane[1];
        }
    }

    return 0;
}

private static boolean isPerfectGemstone(String itemId) {

    return itemId.startsWith("PERFECT_") &&
            itemId.endsWith("_GEM");
}

private static List<CraftingRecipe> loadForgeRecipes() {

    List<CraftingRecipe> recipes =
            new ArrayList<>();

    addRecipe(recipes, "REFINED_DIAMOND", 1, "ENCHANTED_DIAMOND_BLOCK", 2);
    addRecipe(recipes, "REFINED_MITHRIL", 1, "ENCHANTED_MITHRIL", 160);
    addRecipe(recipes, "REFINED_TITANIUM", 1, "ENCHANTED_TITANIUM", 16);
    addRecipe(recipes, "REFINED_UMBER", 1, "ENCHANTED_UMBER", 160);
    addRecipe(recipes, "REFINED_TUNGSTEN", 1, "ENCHANTED_TUNGSTEN", 160);
    addRecipe(recipes, "BEJEWELED_HANDLE", 1, "GLACITE_JEWEL", 3);
    addRecipe(recipes, "FUEL_TANK", 1, "ENCHANTED_COAL_BLOCK", 2);
    addRecipe(recipes, "POWER_CRYSTAL", 1, "STARFALL", 256);

    addRecipe(
            recipes,
            "GEMSTONE_MIXTURE",
            1,
            Map.of(
                    "FINE_JADE_GEM", 4,
                    "FINE_AMBER_GEM", 4,
                    "FINE_AMETHYST_GEM", 4,
                    "FINE_SAPPHIRE_GEM", 4,
                    "SLUDGE_JUICE", 320
            )
    );

    addRecipe(
            recipes,
            "GLACITE_AMALGAMATION",
            1,
            Map.of(
                    "FINE_ONYX_GEM", 4,
                    "FINE_CITRINE_GEM", 4,
                    "FINE_PERIDOT_GEM", 4,
                    "FINE_AQUAMARINE_GEM", 4,
                    "ENCHANTED_GLACITE", 256
            )
    );

    addRecipe(
            recipes,
            "GOLDEN_PLATE",
            1,
            Map.of(
                    "REFINED_DIAMOND", 1,
                    "ENCHANTED_GOLD_BLOCK", 2,
                    "GLACITE_JEWEL", 5
            )
    );

    addRecipe(
            recipes,
            "DRILL_ENGINE",
            1,
            Map.of(
                    "TREASURITE", 10,
                    "ENCHANTED_IRON_BLOCK", 1,
                    "ENCHANTED_REDSTONE_BLOCK", 3,
                    "GOLDEN_PLATE", 1
            )
    );

    addRecipe(
            recipes,
            "MITHRIL_PLATE",
            1,
            Map.of(
                    "REFINED_TITANIUM", 1,
                    "REFINED_MITHRIL", 5,
                    "GOLDEN_PLATE", 1,
                    "ENCHANTED_IRON_BLOCK", 1
            )
    );

    addRecipe(
            recipes,
            "TUNGSTEN_PLATE",
            1,
            Map.of(
                    "REFINED_TUNGSTEN", 4,
                    "GLACITE_AMALGAMATION", 1
            )
    );

    addRecipe(
            recipes,
            "UMBER_PLATE",
            1,
            Map.of(
                    "REFINED_UMBER", 4,
                    "GLACITE_AMALGAMATION", 1
            )
    );

    addRecipe(
            recipes,
            "MITHRIL_DRILL_1",
            1,
            Map.of(
                    "REFINED_MITHRIL", 3,
                    "FUEL_TANK", 1,
                    "DRILL_ENGINE", 1
            )
    );

    addRecipe(
            recipes,
            "MITHRIL_DRILL_2",
            1,
            Map.of(
                    "MITHRIL_DRILL_1", 1,
                    "GOLDEN_PLATE", 1,
                    "MITHRIL_PLATE", 1,
                    "ENCHANTED_IRON_BLOCK", 1
            )
    );

    addRecipe(
            recipes,
            "GEMSTONE_DRILL_1",
            1,
            Map.of(
                    "FINE_RUBY_GEM", 6,
                    "FUEL_TANK", 1,
                    "DRILL_ENGINE", 1
            )
    );

    addRecipe(
            recipes,
            "GEMSTONE_DRILL_2",
            1,
            Map.of(
                    "GEMSTONE_DRILL_1", 1,
                    "GEMSTONE_MIXTURE", 3
            )
    );

    addRecipe(
            recipes,
            "STARFALL_SEASONING",
            1,
            Map.of(
                    "TREASURITE", 16,
                    "STARFALL", 64
            )
    );
    addRecipe(recipes, "GOBLIN_OMELETTE", 1, "GOBLIN_EGG", 96);
    addRecipe(recipes, "DIAMONITE", 1, "REFINED_DIAMOND", 3);
    addRecipe(recipes, "POCKET_ICEBERG", 1, "GLACITE_JEWEL", 5);
    addRecipe(recipes, "PETRIFIED_STARFALL", 1, "STARFALL", 512);
    addRecipe(recipes, "PURE_MITHRIL", 1, "REFINED_MITHRIL", 2);

    String[] gemstones = {
            "AMBER", "AMETHYST", "AQUAMARINE", "CITRINE",
            "JADE", "JASPER", "ONYX", "OPAL", "PERIDOT",
            "RUBY", "SAPPHIRE", "TOPAZ"
    };

    for (String gemstone : gemstones) {
        addRecipe(
                recipes,
                "PERFECT_" + gemstone + "_GEM",
                1,
                "FLAWLESS_" + gemstone + "_GEM",
                5
        );
    }

    return List.copyOf(recipes);
}

private static List<CraftingRecipe> loadCraftingRecipes() {

    try (
        InputStream input =
                DatabaseService.class.getResourceAsStream(
                        "/crafting-recipes.json"
                )
    ) {

        if (input == null) {

            throw new IllegalStateException(
                    "Missing crafting-recipes.json"
            );
        }

        String json =
                new String(
                        input.readAllBytes(),
                        StandardCharsets.UTF_8
                );

        JSONArray recipesJson = new JSONArray(json);

        List<CraftingRecipe> recipes =
                new ArrayList<>();

        for (int i = 0; i < recipesJson.length(); i++) {

            JSONObject recipeJson =
                    recipesJson.getJSONObject(i);

            JSONObject ingredientsJson =
                    recipeJson.getJSONObject("ingredients");

            Map<String, Integer> ingredients =
                    new HashMap<>();

            for (String itemId : ingredientsJson.keySet()) {

                ingredients.put(
                        itemId,
                        ingredientsJson.getInt(itemId)
                );
            }

            recipes.add(
                    new CraftingRecipe(
                            recipeJson.getString("output"),
                            recipeJson.getInt("outputCount"),
                            ingredients
                    )
            );
        }

        addGeneratedCompressionRecipes(recipes);

        return List.copyOf(recipes);

    } catch (Exception e) {

        throw new IllegalStateException(
                "Failed to load crafting recipes",
                e
        );
    }
}

private static List<FusionRecipe> loadCompactFusionRecipes(
        JSONObject root
) {

    JSONObject shards = root.getJSONObject("shards");
    JSONObject recipesByOutput =
            root.getJSONObject("recipes");

    Map<String, FusionShardDefinition> shardByKey =
            new HashMap<>();

    for (String shardKey : shards.keySet()) {

        JSONObject shard = shards.getJSONObject(shardKey);

        shardByKey.put(
                shardKey,
                new FusionShardDefinition(
                        shard.getString("internal_id"),
                        shard.optInt("fuse_amount", 5)
                )
        );
    }

    List<FusionRecipe> recipes = new ArrayList<>();

    for (String outputKey : recipesByOutput.keySet()) {

        FusionShardDefinition output =
                shardByKey.get(outputKey);

        if (output == null) {
            continue;
        }

        JSONObject recipesByYield =
                recipesByOutput.getJSONObject(outputKey);

        for (String outputCountKey : recipesByYield.keySet()) {

            int outputCount =
                    Integer.parseInt(outputCountKey);

            JSONArray inputPairs =
                    recipesByYield.getJSONArray(outputCountKey);

            for (int i = 0; i < inputPairs.length(); i++) {

                JSONArray inputPair =
                        inputPairs.getJSONArray(i);

                if (inputPair.length() != 2) {
                    continue;
                }

                FusionShardDefinition first =
                        shardByKey.get(inputPair.getString(0));

                FusionShardDefinition second =
                        shardByKey.get(inputPair.getString(1));

                if (first == null || second == null) {
                    continue;
                }

                recipes.add(
                        new FusionRecipe(
                                first.itemId(),
                                first.fuseAmount(),
                                second.itemId(),
                                second.fuseAmount(),
                                output.itemId(),
                                outputCount
                        )
                );
            }
        }
    }

    return List.copyOf(recipes);
}

private static List<FusionRecipe> loadFusionRecipes() {

    try (
        InputStream input =
                DatabaseService.class.getResourceAsStream(
                        "/fusion-recipes.json"
                )
    ) {

        if (input == null) {

            return List.of();
        }

        String json =
                new String(
                        input.readAllBytes(),
                        StandardCharsets.UTF_8
                );

        if (json.stripLeading().startsWith("{")) {

            return loadCompactFusionRecipes(
                    new JSONObject(json)
            );
        }

        JSONArray recipesJson =
                new JSONArray(json);

        List<FusionRecipe> recipes =
                new ArrayList<>();

        for (int i = 0; i < recipesJson.length(); i++) {

            JSONObject recipeJson =
                    recipesJson.getJSONObject(i);

            JSONArray inputs =
                    recipeJson.getJSONArray("inputs");

            if (inputs.length() != 2) {

                continue;
            }

            JSONArray inputCounts =
                    recipeJson.optJSONArray("inputCounts");

            recipes.add(
                    new FusionRecipe(
                            inputs.getString(0),
                            inputCounts == null
                                    ? 1
                                    : inputCounts.optInt(0, 1),
                            inputs.getString(1),
                            inputCounts == null
                                    ? 1
                                    : inputCounts.optInt(1, 1),
                            recipeJson.getString("output"),
                            recipeJson.optInt("outputCount", 1)
                    )
            );
        }

        return List.copyOf(recipes);

    } catch (Exception e) {

        throw new IllegalStateException(
                "Failed to load fusion recipes",
                e
        );
    }
}

private static void addGeneratedCompressionRecipes(
        List<CraftingRecipe> recipes
) {

    addGemstoneCompressionRecipes(recipes);
    addEnchantedMaterialRecipes(recipes);
    addEnchantedBlockRecipes(recipes);
    addKnownTieredBazaarRecipes(recipes);
}

private static void addGemstoneCompressionRecipes(
        List<CraftingRecipe> recipes
) {

    String[] gemstones = {
            "AMBER",
            "AMETHYST",
            "AQUAMARINE",
            "CITRINE",
            "JADE",
            "JASPER",
            "ONYX",
            "OPAL",
            "PERIDOT",
            "RUBY",
            "SAPPHIRE",
            "TOPAZ"
    };

    for (String gemstone : gemstones) {

        addRecipe(
                recipes,
                "FLAWED_" + gemstone + "_GEM",
                1,
                "ROUGH_" + gemstone + "_GEM",
                80
        );
        addRecipe(
                recipes,
                "FINE_" + gemstone + "_GEM",
                1,
                "FLAWED_" + gemstone + "_GEM",
                80
        );
        addRecipe(
                recipes,
                "FLAWLESS_" + gemstone + "_GEM",
                1,
                "FINE_" + gemstone + "_GEM",
                80
        );
        addRecipe(
                recipes,
                "PERFECT_" + gemstone + "_GEM",
                1,
                "FLAWLESS_" + gemstone + "_GEM",
                5
        );
    }
}

private static void addEnchantedMaterialRecipes(
        List<CraftingRecipe> recipes
) {

    Map<String, String> standardRecipes =
            new LinkedHashMap<>();

    standardRecipes.put("ENCHANTED_ACACIA_LOG", "LOG_2");
    standardRecipes.put("ENCHANTED_ANCIENT_CLAW", "ANCIENT_CLAW");
    standardRecipes.put("ENCHANTED_BIRCH_LOG", "LOG:2");
    standardRecipes.put("ENCHANTED_BLAZE_POWDER", "BLAZE_ROD");
    standardRecipes.put("ENCHANTED_BONE", "BONE");
    standardRecipes.put("ENCHANTED_BROWN_MUSHROOM", "BROWN_MUSHROOM");
    standardRecipes.put("ENCHANTED_CACTUS", "CACTUS");
    standardRecipes.put("ENCHANTED_CARROT", "CARROT_ITEM");
    standardRecipes.put("ENCHANTED_CLAY_BALL", "CLAY_BALL");
    standardRecipes.put("ENCHANTED_CLOWNFISH", "RAW_FISH:2");
    standardRecipes.put("ENCHANTED_COAL", "COAL");
    standardRecipes.put("ENCHANTED_COBBLESTONE", "COBBLESTONE");
    standardRecipes.put("ENCHANTED_COCOA", "INK_SACK:3");
    standardRecipes.put("ENCHANTED_DANDELION", "YELLOW_FLOWER");
    standardRecipes.put("ENCHANTED_DARK_OAK_LOG", "LOG_2:1");
    standardRecipes.put("ENCHANTED_DIAMOND", "DIAMOND");
    standardRecipes.put("ENCHANTED_EGG", "EGG");
    standardRecipes.put("ENCHANTED_EMERALD", "EMERALD");
    standardRecipes.put("ENCHANTED_ENDER_PEARL", "ENDER_PEARL");
    standardRecipes.put("ENCHANTED_ENDSTONE", "ENDER_STONE");
    standardRecipes.put("ENCHANTED_FEATHER", "FEATHER");
    standardRecipes.put("ENCHANTED_FIG_LOG", "FIG_LOG");
    standardRecipes.put("ENCHANTED_FLINT", "FLINT");
    standardRecipes.put("ENCHANTED_GHAST_TEAR", "GHAST_TEAR");
    standardRecipes.put("ENCHANTED_GLACITE", "GLACITE");
    standardRecipes.put("ENCHANTED_GLOWSTONE_DUST", "GLOWSTONE_DUST");
    standardRecipes.put("ENCHANTED_GOLD", "GOLD_INGOT");
    standardRecipes.put("ENCHANTED_GUNPOWDER", "SULPHUR");
    standardRecipes.put("ENCHANTED_HARD_STONE", "HARD_STONE");
    standardRecipes.put("ENCHANTED_ICE", "ICE");
    standardRecipes.put("ENCHANTED_INK_SACK", "INK_SACK");
    standardRecipes.put("ENCHANTED_IRON", "IRON_INGOT");
    standardRecipes.put("ENCHANTED_JUNGLE_LOG", "LOG:3");
    standardRecipes.put("ENCHANTED_LAPIS_LAZULI", "INK_SACK:4");
    standardRecipes.put("ENCHANTED_LUSH_BERBERIS", "LUSH_BERBERIS");
    standardRecipes.put("ENCHANTED_MAGMA_CREAM", "MAGMA_CREAM");
    standardRecipes.put("ENCHANTED_MANGROVE_LOG", "MANGROVE_LOG");
    standardRecipes.put("ENCHANTED_MELON", "MELON");
    standardRecipes.put("ENCHANTED_MITHRIL", "MITHRIL_ORE");
    standardRecipes.put("ENCHANTED_MUTTON", "MUTTON");
    standardRecipes.put("ENCHANTED_MYCELIUM", "MYCEL");
    standardRecipes.put("ENCHANTED_NETHERRACK", "NETHERRACK");
    standardRecipes.put("ENCHANTED_NETHER_STALK", "NETHER_STALK");
    standardRecipes.put("ENCHANTED_OAK_LOG", "LOG");
    standardRecipes.put("ENCHANTED_OBSIDIAN", "OBSIDIAN");
    standardRecipes.put("ENCHANTED_POISONOUS_POTATO", "POISONOUS_POTATO");
    standardRecipes.put("ENCHANTED_POPPY", "RED_ROSE");
    standardRecipes.put("ENCHANTED_PORK", "PORK");
    standardRecipes.put("ENCHANTED_POTATO", "POTATO_ITEM");
    standardRecipes.put("ENCHANTED_PRISMARINE_CRYSTALS", "PRISMARINE_CRYSTALS");
    standardRecipes.put("ENCHANTED_PRISMARINE_SHARD", "PRISMARINE_SHARD");
    standardRecipes.put("ENCHANTED_PUFFERFISH", "RAW_FISH:3");
    standardRecipes.put("ENCHANTED_PUMPKIN", "PUMPKIN");
    standardRecipes.put("ENCHANTED_QUARTZ", "QUARTZ");
    standardRecipes.put("ENCHANTED_RABBIT", "RABBIT");
    standardRecipes.put("ENCHANTED_RABBIT_FOOT", "RABBIT_FOOT");
    standardRecipes.put("ENCHANTED_RABBIT_HIDE", "RABBIT_HIDE");
    standardRecipes.put("ENCHANTED_RAW_BEEF", "RAW_BEEF");
    standardRecipes.put("ENCHANTED_RAW_CHICKEN", "RAW_CHICKEN");
    standardRecipes.put("ENCHANTED_RAW_FISH", "RAW_FISH");
    standardRecipes.put("ENCHANTED_RAW_SALMON", "RAW_FISH:1");
    standardRecipes.put("ENCHANTED_REDSTONE", "REDSTONE");
    standardRecipes.put("ENCHANTED_RED_MUSHROOM", "RED_MUSHROOM");
    standardRecipes.put("ENCHANTED_RED_SAND", "SAND:1");
    standardRecipes.put("ENCHANTED_ROTTEN_FLESH", "ROTTEN_FLESH");
    standardRecipes.put("ENCHANTED_SAND", "SAND");
    standardRecipes.put("ENCHANTED_SEEDS", "SEEDS");
    standardRecipes.put("ENCHANTED_SHARK_FIN", "SHARK_FIN");
    standardRecipes.put("ENCHANTED_SLIME_BALL", "SLIME_BALL");
    standardRecipes.put("ENCHANTED_SNOW_BLOCK", "SNOW_BALL");
    standardRecipes.put("ENCHANTED_SPIDER_EYE", "SPIDER_EYE");
    standardRecipes.put("ENCHANTED_SPONGE", "SPONGE");
    standardRecipes.put("ENCHANTED_SUGAR", "SUGAR_CANE");
    standardRecipes.put("ENCHANTED_SULPHUR", "SULPHUR_ORE");
    standardRecipes.put("ENCHANTED_TENDER_WOOD", "TENDER_WOOD");
    standardRecipes.put("ENCHANTED_TITANIUM", "TITANIUM_ORE");
    standardRecipes.put("ENCHANTED_TUNGSTEN", "TUNGSTEN");
    standardRecipes.put("ENCHANTED_UMBER", "UMBER");
    standardRecipes.put("ENCHANTED_WHEAT", "WHEAT");
    standardRecipes.put("ENCHANTED_WOOL", "WOOL");

    for (Map.Entry<String, String> recipe : standardRecipes.entrySet()) {

        addRecipe(
                recipes,
                recipe.getKey(),
                1,
                recipe.getValue(),
                160
        );
    }

    addRecipe(recipes, "ENCHANTED_STRING", 1, "STRING", 192);
    addRecipe(recipes, "ENCHANTED_LEATHER", 1, "LEATHER", 576);
}

private static void addEnchantedBlockRecipes(
        List<CraftingRecipe> recipes
) {

    addRecipe(recipes, "ENCHANTED_BAKED_POTATO", 1, "ENCHANTED_POTATO", 160);
    addRecipe(recipes, "ENCHANTED_BLAZE_ROD", 1, "ENCHANTED_BLAZE_POWDER", 160);
    addRecipe(recipes, "ENCHANTED_BONE_BLOCK", 1, "ENCHANTED_BONE", 160);
    addRecipe(recipes, "ENCHANTED_CAKE", 1, "ENCHANTED_EGG", 1);
    addRecipe(recipes, "ENCHANTED_CHARCOAL", 1, "COAL", 128);
    addRecipe(recipes, "ENCHANTED_CLAY_BLOCK", 1, "ENCHANTED_CLAY_BALL", 160);
    addRecipe(recipes, "ENCHANTED_COAL_BLOCK", 1, "ENCHANTED_COAL", 160);
    addRecipe(recipes, "ENCHANTED_COOKED_FISH", 1, "ENCHANTED_RAW_FISH", 160);
    addRecipe(recipes, "ENCHANTED_COOKED_MUTTON", 1, "ENCHANTED_MUTTON", 160);
    addRecipe(recipes, "ENCHANTED_COOKED_RABBIT", 1, "ENCHANTED_RABBIT", 160);
    addRecipe(recipes, "ENCHANTED_COOKED_SALMON", 1, "ENCHANTED_RAW_SALMON", 160);
    addRecipe(recipes, "ENCHANTED_DIAMOND_BLOCK", 1, "ENCHANTED_DIAMOND", 160);
    addRecipe(recipes, "ENCHANTED_EMERALD_BLOCK", 1, "ENCHANTED_EMERALD", 160);
    addRecipe(recipes, "ENCHANTED_GLISTERING_MELON", 1, "ENCHANTED_MELON", 160);
    addRecipe(recipes, "ENCHANTED_GLOWSTONE", 1, "ENCHANTED_GLOWSTONE_DUST", 160);
    addRecipe(recipes, "ENCHANTED_GOLD_BLOCK", 1, "ENCHANTED_GOLD", 160);
    addRecipe(recipes, "ENCHANTED_GRILLED_PORK", 1, "ENCHANTED_PORK", 160);
    addRecipe(recipes, "ENCHANTED_HAY_BALE", 1, "ENCHANTED_WHEAT", 144);
    addRecipe(recipes, "ENCHANTED_HAY_BLOCK", 1, "HAY_BLOCK", 144);
    addRecipe(recipes, "ENCHANTED_HUGE_MUSHROOM_1", 1, "HUGE_MUSHROOM_1", 160);
    addRecipe(recipes, "ENCHANTED_HUGE_MUSHROOM_2", 1, "HUGE_MUSHROOM_2", 160);
    addRecipe(recipes, "ENCHANTED_IRON_BLOCK", 1, "ENCHANTED_IRON", 160);
    addRecipe(recipes, "ENCHANTED_LAPIS_LAZULI_BLOCK", 1, "ENCHANTED_LAPIS_LAZULI", 160);
    addRecipe(recipes, "ENCHANTED_MAGMA_BLOCK", 1, "ENCHANTED_MAGMA_CREAM", 160);
    addRecipe(recipes, "ENCHANTED_MELON_BLOCK", 1, "ENCHANTED_MELON", 160);
    addRecipe(recipes, "ENCHANTED_MYCELIUM_CUBE", 1, "ENCHANTED_MYCELIUM", 160);
    addRecipe(recipes, "ENCHANTED_PACKED_ICE", 1, "ENCHANTED_ICE", 160);
    addRecipe(recipes, "ENCHANTED_PAPER", 1, "PAPER", 160);
    addRecipe(recipes, "ENCHANTED_QUARTZ_BLOCK", 1, "ENCHANTED_QUARTZ", 160);
    addRecipe(recipes, "ENCHANTED_REDSTONE_BLOCK", 1, "ENCHANTED_REDSTONE", 160);
    addRecipe(recipes, "ENCHANTED_REDSTONE_LAMP", 1, "ENCHANTED_REDSTONE_BLOCK", 1);
    addRecipe(recipes, "ENCHANTED_RED_SAND_CUBE", 1, "ENCHANTED_RED_SAND", 160);
    addRecipe(recipes, "ENCHANTED_SLIME_BLOCK", 1, "ENCHANTED_SLIME_BALL", 160);
    addRecipe(recipes, "ENCHANTED_SPONGE", 1, "SPONGE", 40);
    addRecipe(recipes, "ENCHANTED_SUGAR_CANE", 1, "ENCHANTED_SUGAR", 160);
    addRecipe(recipes, "ENCHANTED_SULPHUR_CUBE", 1, "ENCHANTED_SULPHUR", 160);
    addRecipe(recipes, "ENCHANTED_WET_SPONGE", 1, "ENCHANTED_SPONGE", 40);
    addRecipe(recipes, "MUTANT_NETHER_STALK", 1, "ENCHANTED_NETHER_STALK", 160);
    addRecipe(recipes, "POLISHED_PUMPKIN", 1, "ENCHANTED_PUMPKIN", 160);
}

private static void addKnownTieredBazaarRecipes(
        List<CraftingRecipe> recipes
) {

    addRecipe(
            recipes,
            "REVENANT_VISCERA",
            1,
            Map.of(
                    "ENCHANTED_STRING",
                    32,
                    "REVENANT_FLESH",
                    128
            )
    );
    addRecipe(
            recipes,
            "TARANTULA_SILK",
            1,
            Map.of(
                    "ENCHANTED_FLINT",
                    32,
                    "TARANTULA_WEB",
                    128
            )
    );
}

private static void addRecipe(
        List<CraftingRecipe> recipes,
        String output,
        int outputCount,
        String ingredient,
        int amount
) {

    addRecipe(
            recipes,
            output,
            outputCount,
            Map.of(ingredient, amount)
    );
}

private static void addRecipe(
        List<CraftingRecipe> recipes,
        String output,
        int outputCount,
        Map<String, Integer> ingredients
) {

    recipes.add(
            new CraftingRecipe(
                    output,
                    outputCount,
                    ingredients
            )
    );
}

private record CraftingRecipe(
        String outputItemId,
        int outputCount,
        Map<String, Integer> ingredients
) {
}

private record FusionRecipe(
        String firstItemId,
        int firstCount,
        String secondItemId,
        int secondCount,
        String outputItemId,
        int outputCount
) {
}

private record FusionShardDefinition(
        String itemId,
        int fuseAmount
) {
}

private record FusionRoute(
        String outputItemId,
        List<FusionStepData> steps,
        double inputCost,
        double profit,
        int levels,
        FusionFlipData data
) {
}

public record AuctionListing(
        String auctionUuid,
        String itemKey,
        String itemName,
        String tier,
        String category,
        double price,
        long startTime,
        long endTime
) {
}

public record SoldAuction(
        String auctionUuid,
        long soldAt,
        double soldPrice
) {
}

private record AuctionSaleStats(
        double averagePrice,
        int sampleSize
) {
}

private record AuctionPrice(
        double buyPrice,
        double sellPrice,
        double salesPerHour
) {
}

private record MarketObservation(
        double buyPrice,
        double sellPrice,
        double buyMovingWeek,
        double sellMovingWeek
) {

    private double marketPrice() {

        return sellPrice;
    }
}

public record HistoricalObservation(
        String itemId,
        double buyPrice,
        double sellPrice,
        double buyVolume,
        double sellVolume,
        double buyMovingWeek,
        double sellMovingWeek,
        String timestamp,
        String source
) {
}

private record DailyPrice(
        LocalDateTime timestamp,
        double price
) {
}

private record LongTermSignal(
        double changePercent,
        double confidence,
        int samples,
        double discountPercent,
        int decliningDays,
        int ageDays,
        double peakDrawdownPercent,
        boolean priceDiscovery,
        boolean flatMarket,
        boolean persistentGrowth
) {

    private static final LongTermSignal NONE =
            new LongTermSignal(
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    false,
                    false,
                    false
            );
}

private record HistoryRange(
        String sqliteModifier,
        String granularity
) {

    private static HistoryRange from(String value) {

        if (value == null) {

            return new HistoryRange("-1 day", "raw");
        }

        return switch (value.toLowerCase()) {
            case "1w" ->
                    new HistoryRange("-7 days", "hour");
            case "1m" ->
                    new HistoryRange("-30 days", "day");
            case "1y", "all" ->
                    new HistoryRange("-1 year", "week");
            default ->
                    new HistoryRange("-1 day", "raw");
        };
    }
}


}
