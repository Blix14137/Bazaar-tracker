package com.bazaartracker.service;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.bazaartracker.model.MayorData;

class MayorMarketAnalyzerTest {

    @Test
    void projectedDianaBoostsEnchantedGoldBlocks() {

        MayorMarketAnalyzer.MayorSignal signal =
                MayorMarketAnalyzer.analyze(
                        "ENCHANTED_GOLD_BLOCK",
                        mayorWithLeader("Paul", "Diana")
                );

        assertTrue(signal.catalystTokens() >= 4);
        assertTrue(signal.catalystReason().contains("Diana"));
        assertTrue(signal.catalystReason().contains("Enchanted Gold Blocks"));
    }

    @Test
    void activeFoxyBoostsPartyGifts() {

        MayorMarketAnalyzer.MayorSignal signal =
                MayorMarketAnalyzer.analyze(
                        "PARTY_GIFT",
                        mayor("Foxy")
                );

        assertTrue(signal.catalystTokens() >= 4);
        assertTrue(signal.catalystReason().contains("Party Gifts"));
    }

    @Test
    void activeMarinaBoostsWhiteSharkTeeth() {

        MayorMarketAnalyzer.MayorSignal signal =
                MayorMarketAnalyzer.analyze(
                        "GREAT_WHITE_SHARK_TOOTH",
                        mayor("Marina")
                );

        assertTrue(signal.catalystTokens() >= 4);
        assertTrue(signal.catalystReason().contains("White Shark Teeth"));
    }

    @Test
    void activeJerryCoversMarinaColeAndDianaStyleMarkets() {

        MayorMarketAnalyzer.MayorSignal signal =
                MayorMarketAnalyzer.analyze(
                        "GREAT_WHITE_SHARK_TOOTH",
                        mayor("Jerry")
                );

        assertTrue(signal.catalystTokens() >= 3);
        assertTrue(signal.catalystReason().contains("Marina"));
        assertTrue(signal.catalystReason().contains("Cole"));
        assertTrue(signal.catalystReason().contains("Diana"));
    }

    private static MayorData mayor(String name) {

        return new MayorData(
                name,
                List.of(),
                null,
                null,
                List.of(),
                500,
                List.of(),
                0
        );
    }

    private static MayorData mayorWithLeader(
            String currentMayor,
            String leader
    ) {

        MayorData.CandidateData leadingCandidate =
                new MayorData.CandidateData(
                        leader,
                        List.of(),
                        800,
                        0.8,
                        null
                );

        MayorData.CandidateData secondCandidate =
                new MayorData.CandidateData(
                        "Cole",
                        List.of(),
                        200,
                        0.2,
                        null
                );

        return new MayorData(
                currentMayor,
                List.of(),
                null,
                leadingCandidate,
                List.of(
                        leadingCandidate,
                        secondCandidate
                ),
                500,
                List.of(),
                0
        );
    }
}
