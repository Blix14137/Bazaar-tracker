package com.bazaartracker.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.lang.reflect.Method;
import java.util.List;

import org.junit.jupiter.api.Test;

class DatabaseServiceFusionRecipeTest {

    @Test
    void loadsCompleteFusionRecipeDataset() throws Exception {

        Method loader =
                DatabaseService.class.getDeclaredMethod(
                        "loadFusionRecipes"
                );

        loader.setAccessible(true);

        List<?> recipes = (List<?>) loader.invoke(null);

        assertEquals(87_585, recipes.size());
    }
}
