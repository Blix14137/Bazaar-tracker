// Live Server hosts the frontend separately from Spring Boot. Route only
// local development API calls to port 8080; production stays same-origin
// so Nginx can proxy /api without exposing the backend.
const isLocalFrontend =
    (window.location.protocol === "file:" ||
        window.location.hostname === "localhost" ||
        window.location.hostname === "127.0.0.1") &&
    window.location.port !== "8080" &&
    window.location.port !== "8088";

if (isLocalFrontend) {
    const browserFetch = window.fetch.bind(window);

    window.fetch = (input, options) => {
        if (typeof input === "string" && input.startsWith("/api")) {
            input = `http://localhost:8080${input}`;
        }

        return browserFetch(input, options);
    };
}

async function loadCurrentMayor() {

    const mayorName =
        document.getElementById("mayorName");

    const mayorPerks =
        document.getElementById("mayorPerks");

    const mayorYear =
        document.getElementById("mayorYear");

    if (!mayorName || !mayorPerks) {
        return;
    }

    try {

        const response =
            await fetch("/api/mayor");

        if (!response.ok) {
            throw new Error("Could not load mayor");
        }

        const mayor =
            await response.json();

        mayorName.textContent =
            mayor.name;

        mayorPerks.textContent =
            mayor.perks
                .map(perk => perk.name)
                .join(" | ");

        if (mayorYear && mayor.currentYear) {
            mayorYear.textContent =
                mayor.currentYear;
        }

    } catch (error) {

        console.error(error);
        mayorName.textContent = "Unavailable";
        mayorPerks.textContent =
            "Could not load the current mayor.";
    }
}

loadCurrentMayor();
