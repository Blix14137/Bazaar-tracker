
const params = new URLSearchParams(window.location.search);
const itemId = params.get("item");
const hasSelectedItem = Boolean(itemId);
let chart = null;
let chartTimestamps = [];
let chartMayorContexts = [];
let currentMayorName = "";
let currentHistoryRange = "1d";
const MAX_CHART_POINTS = 20;
const HISTORY_SAMPLE_INTERVAL_MS = 60 * 60 * 1000;
const CHART_REFRESH_INTERVAL_MS = 5 * 60 * 1000;
const DOWNTIME_GAP_MS = HISTORY_SAMPLE_INTERVAL_MS * 3;

function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll("\"", "&quot;")
        .replaceAll("'", "&#039;");
}

const mayorBoundaryPlugin = {
    id: "mayorBoundaries",

    afterDatasetsDraw(chartInstance) {

        return;

        if (
            chartTimestamps.length < 2 ||
            chartMayorContexts.length === 0
        ) {
            return;
        }

        const chartArea =
            chartInstance.chartArea;

        const startMs =
            chartTimestamps[0].getTime();

        const endMs =
            chartTimestamps[
                chartTimestamps.length - 1
            ].getTime();

        if (endMs <= startMs) {
            return;
        }

        const boundaries = [];

        chartMayorContexts.forEach(context => {
            boundaries.push({
                time: new Date(context.start).getTime(),
                label: `${context.mayor} term starts`,
                type: "start"
            });

            boundaries.push({
                time: new Date(context.end).getTime(),
                label: `${context.mayor} term ends`,
                type: "end"
            });
        });

        const uniqueBoundaries =
            boundaries.filter(
                (boundary, index, values) =>
                    boundary.time >= startMs &&
                    boundary.time <= endMs &&
                    values.findIndex(value =>
                        value.time === boundary.time &&
                        value.label === boundary.label
                    ) === index
            );

        const context =
            chartInstance.ctx;

        const drawRoundedRect = (
            x,
            y,
            width,
            height,
            radius
        ) => {
            const corner =
                Math.min(
                    radius,
                    width / 2,
                    height / 2
                );

            context.beginPath();
            context.moveTo(x + corner, y);
            context.lineTo(x + width - corner, y);
            context.quadraticCurveTo(
                x + width,
                y,
                x + width,
                y + corner
            );
            context.lineTo(x + width, y + height - corner);
            context.quadraticCurveTo(
                x + width,
                y + height,
                x + width - corner,
                y + height
            );
            context.lineTo(x + corner, y + height);
            context.quadraticCurveTo(
                x,
                y + height,
                x,
                y + height - corner
            );
            context.lineTo(x, y + corner);
            context.quadraticCurveTo(
                x,
                y,
                x + corner,
                y
            );
            context.closePath();
        };

        const fitLabel = (
            label,
            maxWidth
        ) => {
            if (context.measureText(label).width <= maxWidth) {
                return label;
            }

            const ellipsis = "...";
            let trimmed = label;

            while (
                trimmed.length > 0 &&
                context.measureText(`${trimmed}${ellipsis}`).width > maxWidth
            ) {
                trimmed = trimmed.slice(0, -1);
            }

            return `${trimmed}${ellipsis}`;
        };

        const sortedBoundaries =
            uniqueBoundaries.sort(
                (first, second) =>
                    first.time - second.time ||
                    first.type.localeCompare(second.type)
            );

        const labelLanes = [];
        const maxLabelLanes = 3;

        context.save();

        sortedBoundaries.forEach(boundary => {
            const x =
                chartInstance.scales.x.getPixelForValue(
                    boundary.time
                );

            context.beginPath();
            context.setLineDash(
                boundary.type === "start"
                    ? [6, 4]
                    : [2, 4]
            );
            context.strokeStyle =
                boundary.type === "start"
                    ? "rgba(99, 230, 190, 0.9)"
                    : "rgba(255, 133, 133, 0.85)";
            context.lineWidth = 1.5;
            context.moveTo(x, chartArea.top);
            context.lineTo(x, chartArea.bottom);
            context.stroke();

            context.setLineDash([]);
            context.fillStyle =
                boundary.type === "start"
                    ? "#8ff0ca"
                    : "#ff9d9d";
            context.font =
                "11px sans-serif";
            context.textAlign =
                "left";
            context.textBaseline =
                "middle";

            const labelPaddingX = 7;
            const labelHeight = 20;
            const labelGap = 6;
            const labelMaxWidth =
                Math.max(
                    48,
                    Math.min(
                        130,
                        chartArea.right - chartArea.left - 12
                    )
                );
            const label =
                fitLabel(
                    boundary.label,
                    labelMaxWidth
                );
            const labelWidth =
                Math.ceil(context.measureText(label).width) +
                labelPaddingX * 2;
            const preferredX =
                boundary.type === "end"
                    ? x - labelGap - labelWidth
                    : x + labelGap;
            const labelX =
                Math.min(
                    Math.max(preferredX, chartArea.left + 4),
                    chartArea.right - labelWidth - 4
                );

            let labelLane =
                labelLanes.findIndex(lastEnd =>
                    labelX > lastEnd + 8
                );

            if (labelLane === -1) {
                labelLane =
                    labelLanes.length < maxLabelLanes
                        ? labelLanes.length
                        : 0;
            }

            labelLanes[labelLane] =
                labelX + labelWidth;

            const labelY =
                Math.max(
                    4,
                    chartArea.top -
                        maxLabelLanes *
                            (labelHeight + 4) -
                        2
                ) +
                labelLane *
                    (labelHeight + 4);

            context.fillStyle =
                "rgba(9, 12, 18, 0.82)";
            drawRoundedRect(
                labelX,
                labelY,
                labelWidth,
                labelHeight,
                5
            );
            context.fill();

            context.fillStyle =
                boundary.type === "start"
                    ? "#8ff0ca"
                    : "#ff9d9d";
            context.fillText(
                label,
                labelX + labelPaddingX,
                labelY + labelHeight / 2
            );
        });

        context.restore();
    }
};

Chart.register(mayorBoundaryPlugin);

Chart.Tooltip.positioners.clampedAverage = function (
    elements,
    eventPosition
) {
    const position =
        Chart.Tooltip.positioners.average.call(
            this,
            elements,
            eventPosition
        );

    if (!position) {
        return false;
    }

    const chartArea =
        this.chart.chartArea;
    const width =
        this.width || 120;
    const height =
        this.height || 56;
    const padding =
        8;

    return {
        x: Math.min(
            Math.max(
                position.x,
                chartArea.left + width / 2 + padding
            ),
            chartArea.right - width / 2 - padding
        ),
        y: Math.min(
            Math.max(
                position.y,
                chartArea.top + height / 2 + padding
            ),
            chartArea.bottom - height / 2 - padding
        )
    };
};

function alignMarketContextTimeline() {
    const context =
        document.querySelector(".market-context");

    if (
        !context ||
        !chart ||
        !chart.chartArea
    ) {
        return;
    }

    context.style.setProperty(
        "--context-left-offset",
        `${Math.max(0, chart.chartArea.left)}px`
    );
    context.style.setProperty(
        "--context-right-offset",
        `${Math.max(0, chart.width - chart.chartArea.right)}px`
    );
}

async function loadCurrentMayorForChart() {

    try {

        const response =
            await fetch("/api/mayor");

        if (!response.ok) {
            throw new Error("Could not load current mayor");
        }

        const mayor =
            await response.json();

        currentMayorName =
            mayor.name || "";

        if (chart) {
            chart.draw();
        }

    } catch (error) {

        console.error(error);

        const sidebarMayor =
            document.getElementById("mayorName")?.textContent?.trim();

        currentMayorName =
            sidebarMayor && sidebarMayor !== "Loading..."
                ? sidebarMayor
                : "";
    }
}

function parseUtcTimestamp(timestamp) {

    const normalized =
        timestamp.includes("T")
            ? timestamp
            : timestamp.includes(" ")
                ? timestamp.replace(" ", "T")
                : `${timestamp}T00:00:00`;

    const hasTimezone =
        /(?:Z|[+-]\d{2}:\d{2})$/.test(normalized);

    return new Date(
        hasTimezone
            ? normalized
            : `${normalized}Z`
    );
}

function formatChartTimestamp(date, range) {

    const options = range === "1d"
        ? {
            hour: "numeric",
            minute: "2-digit"
        }
        : range === "1w"
            ? {
                weekday: "short",
                hour: "numeric"
            }
            : {
                month: "short",
                day: "numeric",
                year: range === "1y"
                    ? "2-digit"
                    : undefined
            };

    return new Intl.DateTimeFormat(
        undefined,
        options
    ).format(date);
}

function displayName(id) {
    return id
        .replace(/^ENCHANTED_HUGE_MUSHROOM_1$/, "ENCHANTED_RED_MUSHROOM")
        .replace(/^ENCHANTED_HUGE_MUSHROOM_2$/, "ENCHANTED_BROWN_MUSHROOM")
        .replaceAll("_", " ")
        .toLowerCase()
        .replace(/\b\w/g, letter => letter.toUpperCase());
}

function formatCoins(value) {
    return Math.round(value).toLocaleString();
}

function formatPrice(value) {
    return value.toLocaleString(undefined, {
        minimumFractionDigits: 1,
        maximumFractionDigits: 1
    });
}

function thinChartPoints(
    timestamps,
    buyPrices,
    sellPrices,
    maxPoints = MAX_CHART_POINTS
) {

    if (timestamps.length <= maxPoints) {
        return {
            timestamps,
            buyPrices,
            sellPrices
        };
    }

    const lastIndex =
        timestamps.length - 1;

    const selectedIndexes =
        new Set();

    for (let index = 0; index < maxPoints; index++) {
        selectedIndexes.add(
            Math.round(
                index * lastIndex / (maxPoints - 1)
            )
        );
    }

    const indexes =
        [...selectedIndexes].sort(
            (first, second) =>
                first - second
        );

    return {
        timestamps: indexes.map(index => timestamps[index]),
        buyPrices: indexes.map(index => buyPrices[index]),
        sellPrices: indexes.map(index => sellPrices[index])
    };
}

function latestContinuousHistory(
    timestamps,
    buyPrices,
    sellPrices
) {

    if (timestamps.length < 2) {
        return {
            timestamps,
            buyPrices,
            sellPrices
        };
    }

    let startIndex = 0;

    for (let index = timestamps.length - 1; index > 0; index--) {
        const gap =
            timestamps[index].getTime() -
            timestamps[index - 1].getTime();

        if (gap > DOWNTIME_GAP_MS) {
            startIndex = index;
            break;
        }
    }

    return {
        timestamps: timestamps.slice(startIndex),
        buyPrices: buyPrices.slice(startIndex),
        sellPrices: sellPrices.slice(startIndex)
    };
}

const bzCentralLanding =
    document.getElementById("bzCentralLanding");
const itemDetail =
    document.getElementById("itemDetail");
const itemName =
    document.getElementById("itemName");
const itemImage =
    document.getElementById("itemImage");

if (bzCentralLanding && itemDetail) {
    bzCentralLanding.hidden =
        hasSelectedItem;
    itemDetail.hidden =
        !hasSelectedItem;
}

if (hasSelectedItem && itemName && itemImage) {
    itemName.textContent = displayName(itemId);
    itemImage.src =
        `https://sky.coflnet.com/static/icon/${encodeURIComponent(itemId)}`;
    itemImage.alt = displayName(itemId);
    itemImage.addEventListener("error", () => {
        itemImage.style.display = "none";
    });
}

// --------------------
// Load Graph History
// --------------------

async function loadHistory(range = "1d") {

    try {

        currentHistoryRange = range;

        document.querySelectorAll(".buttons [data-range]")
            .forEach(button => {
                button.classList.toggle(
                    "active",
                    button.dataset.range === range
                );
            });

        const response = await fetch(
            `/api/history/${encodeURIComponent(itemId)}?range=${encodeURIComponent(range)}`
        );

        if (!response.ok) {
            throw new Error("Failed to fetch history");
        }

        const history = await response.json();

        const timestamps = [];
        const buyPrices = [];
        const sellPrices = [];

        history.forEach(point => {

            const timestamp =
                parseUtcTimestamp(point.timestamp);

            timestamps.push(timestamp);
            buyPrices.push(point.buyPrice);
            sellPrices.push(point.sellPrice);

        });

        const visibleChart =
            thinChartPoints(
                timestamps,
                buyPrices,
                sellPrices
            );

        drawChart(
            visibleChart.timestamps,
            visibleChart.buyPrices,
            visibleChart.sellPrices
        );
        chartTimestamps =
            timestamps;
        loadMarketContext(timestamps);

        if (history.length > 0) {

            const latest = history[history.length - 1];

            document.getElementById("buyPrice").textContent =
                formatPrice(latest.buyPrice);

            document.getElementById("sellPrice").textContent =
                formatPrice(latest.sellPrice);
        }

    } catch (error) {

        console.error(error);

        alert("Failed to load history from backend.");
    }
}

async function loadMarketContext(timestamps) {

    const timeline =
        document.getElementById("marketContextTimeline");

    const timezone =
        document.getElementById("chartTimezone");

    if (timestamps.length === 0) {
        return;
    }

    if (timezone) {
        timezone.textContent =
            `Times shown in ${Intl.DateTimeFormat().resolvedOptions().timeZone}`;
    }

    const from =
        timestamps[0];

    const to =
        timestamps[timestamps.length - 1];

    try {

        const response = await fetch(
            `/api/market-context?from=${encodeURIComponent(from.toISOString())}&to=${encodeURIComponent(to.toISOString())}`
        );

        if (!response.ok) {
            throw new Error("Could not load mayor timeline");
        }

        const contexts =
            await response.json();

        chartMayorContexts =
            contexts;

        if (chart) {
            chart.draw();
            alignMarketContextTimeline();
        }

        if (timeline) {
            renderMarketContext(
                timeline,
                contexts,
                from,
                to
            );
        }

    } catch (error) {

        console.error(error);
        if (timeline) {
            timeline.innerHTML =
                "<div class=\"empty-state\">Mayor history is temporarily unavailable.</div>";
        }
    }
}

function renderMarketContext(
    timeline,
    contexts,
    rangeStart,
    rangeEnd
) {

    const startMs =
        rangeStart.getTime();

    const endMs =
        Math.max(
            startMs + 1,
            rangeEnd.getTime()
        );

    const visible =
        contexts
            .map(context => {
                const start =
                    Math.max(
                        startMs,
                        new Date(context.start).getTime()
                    );

                const end =
                    Math.min(
                        endMs,
                        new Date(context.end).getTime()
                    );

                return {
                    ...context,
                    visibleStart: start,
                    visibleEnd: end
                };
            })
            .filter(context =>
                context.visibleEnd > context.visibleStart
            )
            .sort((first, second) =>
                first.visibleStart - second.visibleStart
            );

    if (visible.length === 0) {

        timeline.innerHTML =
            "<div class=\"empty-state\">No mayor period overlaps this chart range.</div>";
        return;
    }

    const blocks = [];
    let cursor =
            startMs;

    visible.forEach(context => {
        if (context.visibleStart > cursor) {
            blocks.push({
                type: "gap",
                visibleStart: cursor,
                visibleEnd: context.visibleStart
            });
        }

        blocks.push({
            ...context,
            type: "mayor"
        });

        cursor =
                Math.max(
                    cursor,
                    context.visibleEnd
                );
    });

    if (cursor < endMs) {
        blocks.push({
            type: "gap",
            visibleStart: cursor,
            visibleEnd: endMs
        });
    }

    timeline.innerHTML =
        blocks.map(context => {
            const left =
                (
                    (context.visibleStart - startMs) /
                    (endMs - startMs) *
                    100
                ).toFixed(3);

            const width =
                (
                    (context.visibleEnd - context.visibleStart) /
                    (endMs - startMs) *
                    100
                ).toFixed(3);

            if (context.type === "gap") {
                return `
                    <div
                        class="market-context-segment market-context-gap"
                        style="left:${left}%; width:${width}%"
                        title="Election period"
                    >
                        <strong>Election</strong>
                        <span>Break period</span>
                    </div>
                `;
            }

            const details = [
                ...context.perks,
                context.minister
                    ? `Minister: ${context.minister}`
                    : null
            ].filter(Boolean);

            const hue =
                [...context.mayor]
                    .reduce(
                        (sum, character) =>
                            sum + character.charCodeAt(0),
                        0
                    ) % 360;

            return `
                <div
                    class="market-context-segment"
                    style="left:${left}%; width:${width}%; --segment-hue:${hue}"
                    title="${escapeHtml(details.join(" | "))}"
                >
                    <strong>${escapeHtml(context.mayor)}</strong>
                    <span>
                        ${escapeHtml(context.event || context.perks[0] || "Mayor term")}
                    </span>
                </div>
            `;
        }).join("");
}

// --------------------
// Load Craft Recipe
// --------------------

async function loadCraftRecipe() {

    const craftSection =
        document.getElementById("craftSection");

    const craftOutput =
        document.getElementById("craftOutput");

    const craftIngredients =
        document.getElementById("craftIngredients");

    const craftSummary =
        document.getElementById("craftSummary");

    try {

        const response = await fetch(
            `/api/craft/${encodeURIComponent(itemId)}`
        );

        if (!response.ok) {
            throw new Error("Failed to fetch recipe");
        }

        const text = await response.text();

        if (!text) {

            craftSection.style.display = "none";
            return;
        }

        const recipe = JSON.parse(text);

        craftOutput.textContent =
            recipe.outputCount > 1
                ? `${recipe.outputCount}× ${displayName(recipe.outputItemId)}`
                : displayName(recipe.outputItemId);

        craftIngredients.innerHTML = "";

        recipe.ingredients.forEach(ingredient => {

            const row = document.createElement("div");

            row.className = "craft-ingredient";

            row.innerHTML = `
                <img
                    src="https://sky.coflnet.com/static/icon/${encodeURIComponent(ingredient.itemId)}"
                    alt=""
                >
                <span>
                    <strong>${ingredient.amount.toLocaleString()}× ${escapeHtml(displayName(ingredient.itemId))}</strong>
                    <small>${formatCoins(ingredient.unitPrice)} coins each</small>
                </span>
                <b>${formatCoins(ingredient.totalPrice)} coins</b>
            `;

            row.querySelector("img").addEventListener("error", event => {
                event.currentTarget.style.visibility = "hidden";
            });

            craftIngredients.appendChild(row);
        });

        craftSummary.innerHTML = `
            <span>Craft cost <strong>${formatCoins(recipe.craftCost)} coins</strong></span>
            <span>Sell value <strong>${formatCoins(recipe.sellPrice)} coins</strong></span>
            <span class="${recipe.profit >= 0 ? "profit" : "loss"}">
                Profit <strong>${recipe.profit >= 0 ? "+" : ""}${formatCoins(recipe.profit)} coins</strong>
            </span>
        `;

    } catch (error) {

        console.error(error);

        craftIngredients.innerHTML =
            "<div class=\"empty-state\">Could not load this recipe.</div>";
    }
}

// --------------------
// Draw Chart
// --------------------

function drawChart(
    timestamps,
    buyPrices,
    sellPrices
) {

    const ctx = document.getElementById("priceChart");

    if (chart) {
        chart.destroy();
    }

    chart = new Chart(ctx, {

        type: "line",

        data: {

            labels: timestamps.map(timestamp =>
                formatChartTimestamp(
                    timestamp,
                    currentHistoryRange
                )
            ),

            datasets: [

                {
                    label: "Buy Price",
                    data: buyPrices,
                    borderColor: "#ff6384",
                    backgroundColor: "#ff6384",
                    pointBackgroundColor: "#ff6384",
                    pointBorderColor: "#ff6384",
                    pointRadius: 3,
                    pointHoverRadius: 4,
                    borderWidth: 3,
                    tension: 0,
                    fill: false
                },

                {
                    label: "Sell Price",
                    data: sellPrices,
                    borderColor: "#36A2EB",
                    backgroundColor: "#36A2EB",
                    pointBackgroundColor: "#36A2EB",
                    pointBorderColor: "#36A2EB",
                    pointRadius: 3,
                    pointHoverRadius: 4,
                    borderWidth: 3,
                    tension: 0,
                    fill: false
                }

            ]

        },

        options: {

            responsive: true,

            interaction: {

                mode: "index",
                intersect: false

            },

            plugins: {

                tooltip: {
                    position: "clampedAverage",
                    callbacks: {
                        title(items) {
                            return items[0]?.label || "";
                        },
                        afterBody() {
                            return currentMayorName
                                    ? `Mayor: ${currentMayorName}`
                                    : "";
                        }
                    }
                },

                legend: {
                    labels: {
                        boxWidth: 42,
                        boxHeight: 3,
                        padding: 18,
                        usePointStyle: false
                    }
                }

            },

            layout: {
                padding: {
                    top: 68,
                    right: 8
                }
            },

            scales: {
                x: {
                    grid: {
                        color: "rgba(255, 255, 255, 0.035)"
                    },
                    ticks: {
                        maxRotation: 45,
                        minRotation: 45,
                        autoSkipPadding: 18
                    }
                },
                y: {
                    grid: {
                        color: "rgba(255, 255, 255, 0.04)"
                    }
                }
            },

            animation: {
                onComplete: alignMarketContextTimeline
            }

        }

    });

    alignMarketContextTimeline();

}

// --------------------
// Search Autocomplete
// --------------------

const searchBox = document.getElementById("searchBox");
const suggestions = document.getElementById("suggestions");
const detailSearchBox =
    document.getElementById("detailSearchBox");
const detailSuggestions =
    document.getElementById("detailSuggestions");

let allItems = [];

async function loadItems() {

    try {

        const response = await fetch(
            "/api/items"
        );

        allItems = await response.json();

        console.log("Loaded", allItems.length, "items.");

    } catch (error) {

        console.error(error);

    }

}

loadItems();

function setupSearch(input, results) {

    if (!input || !results) {
        return;
    }

    input.addEventListener("input", () => {

        const query =
            input.value
                .trim()
                .toUpperCase();

        results.innerHTML = "";

        if (query.length < 2) {

            results.style.display = "none";

            return;

        }

        const matches = allItems
            .filter(item =>
                item.replaceAll("_", " ").includes(query)
            )
            .slice(0, 15);

        matches.forEach(item => {

            const div = document.createElement("div");
            const image = document.createElement("img");
            const name = document.createElement("span");

            div.className = "suggestion";

            image.className = "suggestion-icon";
            image.src =
                `https://sky.coflnet.com/static/icon/${encodeURIComponent(item)}`;
            image.alt = "";
            image.setAttribute("aria-hidden", "true");
            image.addEventListener("error", () => {
                image.style.visibility = "hidden";
            });

            name.textContent = displayName(item);

            div.append(image, name);
            div.onclick = () => {

                window.location.href =
                    `item.html?item=${encodeURIComponent(item)}`;

            };

            results.appendChild(div);

        });

        results.style.display =
            matches.length > 0
                ? "block"
                : "none";

    });

}

setupSearch(searchBox, suggestions);
setupSearch(detailSearchBox, detailSuggestions);

window.addEventListener(
    "resize",
    alignMarketContextTimeline
);

if (hasSelectedItem) {
    setInterval(
        () => loadHistory(currentHistoryRange),
        CHART_REFRESH_INTERVAL_MS
    );
}

// --------------------
// Initial Load
// --------------------

if (hasSelectedItem) {
    loadCurrentMayorForChart();
    loadHistory("1d");
    loadCraftRecipe();
} else if (searchBox) {
    searchBox.focus();
}
