# Mayor Images

Drop mayor portrait images in this folder using these filenames:

- `aatrox.webp`
- `cole.webp`
- `derpy.webp`
- `diana.webp`
- `diaz.webp`
- `finnegan.webp`
- `foxy.webp`
- `jerry.png`
- `marina.jpg`
- `paul.jpg`
- `scorpius.webp`

Use the real image extension for each file. Tall portraits work best,
ideally at least 180px high.

The mayor page checks this folder first. If a local image is missing, it falls
back to the Hypixel Wiki image for that mayor.
